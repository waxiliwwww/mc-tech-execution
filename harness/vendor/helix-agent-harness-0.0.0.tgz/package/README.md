# Agent Harness

**这个包提供独立智能体会话及可替换的运行循环。独立应用通过 `@helix/agent-harness/standalone` 传入模型、工具和 MCP 配置即可运行；需要控制各阶段的宿主继续使用包根的 `runHarness`。** Helix 普通聊天、工作流等业务通过适配器接入同一循环，包本身不依赖 Server、数据库或 Helix 私有协议。

当前为仓库内的 **`@helix/agent-harness@0.0.0` 私有包**，使用 Node.js 22 和 ESM。底层核心不导入第三方运行时；独立默认装配使用固定版本的 MCP SDK、Zod、Ajv 和 ajv-formats。接口仍在演进，尚未发布为稳定 SDK。

## 直接创建独立会话

安装本地打出的包后，直接使用同包的 `./standalone` 入口。省略模型参数时自动读取当前进程的 `HARNESS_MODEL_URL`、`HARNESS_MODEL`、`HARNESS_MODEL_API_KEY`，不搜索或创建配置文件；无鉴权服务显式设置空密钥。URL 支持根地址、以 `/v1` 结尾的 API 基础地址或完整请求端点。

```js
import { createHarness } from "@helix/agent-harness/standalone";

const agent = await createHarness({
  // 可显式传 model: { url, model, apiKey, protocol } 覆盖环境配置
  cwd: process.cwd(),
  stream: true,
  reasoning: "auto",
  builtinTools: ["read", "bash", "edit", "write"],
  mcpServers: [],
});
try {
  for await (const event of agent.run("读取 README.md，说明这个项目怎样运行")) {
    if (event.kind === "message.delta") process.stdout.write(event.content.delta);
    if (event.kind === "reasoning.delta") process.stdout.write(event.content.delta);
    if (event.kind === "turn.failed") console.error(event.content.message);
  }
} finally {
  await agent.close();
}
```

`createHarness` 负责会话历史、模型驱动、预检、执行及继续循环。`run` 返回异步事件流，`callTool(name, input, {signal})` 可直接测试工具；`tools` 返回当前定义，`history` 返回会话快照，`clear()` 清空当前内存会话，`close()` 取消活动任务并断开 MCP。模型缺项在运行普通消息时报告，工具发现和直接调用无需模型。交互补填属于终端界面：调用 `loadHarnessConfig()` 取得配置后补填，再传给工厂即可。

| 参数 | 默认及含义 |
| --- | --- |
| `model` | 显式字段优先，其余从 `HARNESS_MODEL_*` 取得；`protocol` 支持 `chat_completions` / `responses` |
| `stream` | `true`；`false` 请求完整响应。环境变量 `HARNESS_STREAM=true/false` |
| `reasoning` | `auto`：透传服务实际返回的推理文本或摘要；`off` 隐藏。环境变量 `HARNESS_REASONING`。不保证模型会返回推理；关闭显示仍保留实际返回且供后续协议回传使用的原始字段 |
| `model.thinkingBody` | 可选供应商思考参数对象；环境变量 `HARNESS_MODEL_THINKING_BODY` 为 JSON。它决定请求内容，与推理显示分开 |
| `builtinTools` | 默认 `read/bash/edit/write`；`[]` 禁用基础工具，可选子集。环境变量 `HARNESS_BUILTIN_TOOLS=read,bash,edit,write` 或 `none` |
| `cwd` | 默认当前进程目录；基础工具的相对路径与 Bash 工作目录 |
| `mcpServers` | 默认读取 `HARNESS_MCP_SERVERS` JSON 数组，未配置不连接；显式 `[]` 禁用 |
| `customTools` / `executor` | 自定义工具或替换基础工具执行器；平台可接自己的授权和远端执行逻辑 |

基础工具中，`read` 读取文本（可传从 1 开始的 `offset` 与行数 `limit`），`bash` 执行命令（可传秒数 `timeout`），`edit` 用 `oldText/newText` 精确替换唯一匹配，`write` 写入 `path/content`。读取和命令输出限量；Bash 超时或取消会终止进程组。工具选择同时约束模型可见列表与执行入口。纯聊天须 `builtinTools: []` 且 `mcpServers: []`，不添加自定义工具；只读可仅选 `read`。**Bash 能修改文件；`cwd` 是工作目录，不是沙箱。**

MCP 通过配置连接，工具名映射为 `服务名__原名`（必要时生成唯一别名）：

```js
const mcpServers = [
  { name: "local", transport: "stdio", command: "node", args: ["/path/to/server.mjs"] },
  { name: "remote", transport: "streamable-http", url: "https://example.com/mcp",
    headers: { Authorization: "Bearer ${MCP_TOKEN}" }, tools: ["search"] },
];
```

`tools` 是该 MCP 服务的原始工具名允许列表。`env`、`headers` 等字符串支持 `${环境变量名}`；不把密钥写入代码。连接、发现、调用与关闭由包处理。连接建立后若返回状态未知，会停止本轮，不自动重复可能产生副作用的调用。CLI、HTTP 服务与网页可以消费同一事件流；包不会自行启动服务或在 SDK 中询问终端输入。

## 先运行，再接入

在已安装依赖的 Helix 仓库根目录执行：

```sh
pnpm check:harness-package
```

这个命令会构建并打包，随后在仓库外**离线安装真实 tarball**，检查 JavaScript 和声明文件的依赖，运行独立示例及严格类型检查。示例使用本地模型流、假 HTTP 响应和真实算术计算，不启动 Server、不访问模型服务。离线验证需要已有公开示例依赖缓存；缺少缓存会明确失败。

| 从哪里开始 | 能看到什么 |
| --- | --- |
| [examples/runner.mjs](examples/runner.mjs) | 完整的 `runHarness` 接入：模型提出调用 → 预检 → 调用者执行并保存 → 下一轮回答；还展示替换工具、模式材料和会话实现。 |
| [examples/standalone.mjs](examples/standalone.mjs) | 可执行验证入口，会调用上述 runner，并使用真实模型驱动配假 fetch，验证工具结果、上下文、压缩和等待接口。 |
| [examples/consumer.ts](examples/consumer.ts) | TypeScript 接入合同和必须被编译器拒绝的错误用法；只做类型检查，不作为运行脚本。 |
| [examples/consumer-package.json](examples/consumer-package.json) | 示例所需的公开依赖及固定版本；底层示例演示调用方自带校验器；默认装配已提供校验器。 |

脱离仓库使用时，在一个 ESM 项目中安装本地构建产物：

```sh
pnpm add /absolute/path/to/helix-agent-harness-0.0.0.tgz
```

产物由上面的检查命令生成，输出会给出保存位置；这不是从 registry 下载已发布 SDK。默认装配从 `@helix/agent-harness/standalone` 导入；底层能力从 `@helix/agent-harness` 导入。要复现完整示例，将包内 `examples` 的四个 `.mjs`/`.ts` 文件复制到自己的项目目录，合并 `consumer-package.json` 中的依赖和版本约束，再运行 `node standalone.mjs`。`runner.mjs` 导出的 `runRunnerExamples` 由该入口调用，单独运行它不会启动演示。

## 怎样接入运行循环

`runHarness(ports, signal)` 返回异步事件流。调用者消费事件，同时通过 `ports.prepareStep` 为当前步骤提供材料和回调。完整回调装配见 [runner.mjs](examples/runner.mjs)，类型入口见 [dist/index.d.ts](dist/index.d.ts)。它不是只接收一个模型和工具列表就能安全执行的应用服务。

一次步骤的顺序是：**准备材料 → 模型采样 → 校验候选 → 接收本轮历史 → 执行工具或处理回答 → 继续、等待或结束。** 核心控制循环和每轮最多一次候选修复；实际权限、执行、保存和业务完成条件由调用者提供。

| 接入点 / 公开入口 | 包负责什么 | 调用者必须提供什么 |
| --- | --- | --- |
| `HarnessRunPorts.prepareStep`、`HarnessStepPorts` | 调用各阶段并处理继续、停止、等待；可配置让出调度的步数。 | 当前步骤材料、模型调用参数、失败和完成处理、事件格式；若要持久调度，还要实现保存及重新进入循环。 |
| `sampleModelWithRetry`、`OpenAiModelDriver.stream` | 采样流、响应解析及 Chat Completions / Responses 编解码。 | 模型配置、凭据、连接、JSON 参数解析、结构化输出校验和诊断观察器。驱动的 `prepared` 必须同步返回连接参数，时点是编码完成后、HTTP 发送前。 |
| `preflightToolCandidates`、`validateProposal` | 校验候选并返回预检结果；不派发工具。 | 工具查找、真实 schema 校验、业务预检与失败解析。通过预检仍不是执行授权。 |
| `acceptProposal`、`executeTools`、`coordinateToolBatch`、`executeToolWithWait` | 保持批次顺序、并行屏障和等待协调。 | `acceptProposal` 同步更新历史与用量；执行方在派发前重新核对当前权限和条件，保存原回执，处理特殊动作及迟到结果。 |
| `projectToolResultViews`、`persistedModelResult` | 从原结果构建模型、事件、审计等视图及可保存的模型结果。 | 选择投影规则、真正保存并关联数据；这些函数自身不写数据库。 |
| `selectAgentContextWithinBudget`、`deduplicateReadEvidence`、`coordinateContextCompaction` | 预算选材、按指定规则去重，以及已有压缩控制和编解码。 | 提供材料、预算与模型能力、摘要调用、连续性材料、诊断及保存动作；不是自动长期记忆服务。 |
| `HarnessSessionStore`、`MemoryHarnessSessionStore`、历史/恢复选择函数 | 保存接口、历史重建、定位相关检查点和审批记录。 | 选择存储实现；恢复前验证身份、权限和已保存状态。选中记录不代表获得恢复执行权。 |
| 委派深度/容量/范围与 `settleDelegation` 等辅助函数 | 根据传入规则收窄子任务能力，并区分等待、取消和完成。 | 创建及运行子任务、保存父子关联、获取当前权限、核实原操作回执；不提供进程管理或任务队列。 |

Helix 中的装配位于仓库 `apps/server/src/agents/helix-adapter/createHarness.ts`，由 `runtime.ts` 注册。它保留聊天与工作流业务、模型凭据、授权、数据库和网页事件接线。独立调用者无需导入这个平台工厂。

## 怎样扩展

- **换工具：** 提供工具定义、输入校验及执行实现，接到预检和执行回调。示例将乘法换成求和。接 MCP、设备或插件时，同样由适配器负责协议连接、当前权限和副作用核对，不能把工具描述当执行授权。
- **换模式：** 在 `prepareStep` 中选择提示材料、可用工具和完成规则。示例切换 `chat` / `analysis` 材料；Helix 的 Workflow 状态机仍属于平台业务，包没有内置工作流引擎。
- **换会话存储：** 实现 `HarnessSessionStore`。内存实现注入 ID、时间和状态摘要生成函数即可使用；[callerSession.mjs](examples/callerSession.mjs) 展示调用者自己的实现。两者都只是进程内存储，换成数据库还需定义真实保存确认和恢复校验。

## 存储记录怎样成为模型历史

存储接口允许应用自己的事件名和内容；这不表示历史算法理解所有事件。调用者在读取边界将相关记录显式投影成 `HarnessHistoryEntry`：`turn.context` 提供代次，`input` 提供 `items`，其余三类为 `model.response`、`tool.result` 与 `compaction`。无关业务事件继续留在存储。可保存的应用记录与可重建的模型历史使用不同合同，原有数据库格式不因此改变。

恢复合同公开选择器读取的 batch、index、checkpoint 和版本字段。兼容选择器仍接受原始应用记录，返回原记录；`SessionRecoveryRecord`、`SessionResumeRequest` 和 `SessionResumeCheckpoint` 描述标准读取视图。调用者仍须验证状态完整性、权限和原操作，选择器不会把“找到回执”判为“已经成功”。类型及必须拒绝的错配见 [consumer.ts](examples/consumer.ts)。

## 取消、等待和保存意味着什么

| 情况 | 可以依赖的行为与边界 |
| --- | --- |
| 取消 | 核心检查 `AbortSignal` 并传给模型采样；调用者还须将取消传给实际执行器。取消或超时不能证明远端工作已经停止，也不能据此重发有副作用的操作。 |
| 等待 | 工具批次返回 `waiting` 后，当前循环退出。需要恢复时，由应用保存必要状态、接收继续信号、重新校验并重入；包不会自行启动后台调度器。 |
| 同步追加历史 | `appendRollout` 只表示当前存储实现接收记录，**不是落盘确认**。`listRollout` 也不承诺每次重新读取数据库。 |
| 保存检查点 | 等待 `saveCheckpoint` 完成，再发布依赖该状态的等待或完成事件。持久实现必须确认必要的目标记录写入，保存失败应向上传播；不能把内存终态当成已经保存。 |
| 内存会话 | 实例内可保存和读回历史、检查点，读写对象会复制。实例销毁或进程退出后数据消失；不提供跨进程恢复、审批、租约或“恰好执行一次”保证。 |
| 工具结果未知 | 调用者必须区分“尚未确认”与“已失败”，按原操作身份查询已有回执。核心没有将未知副作用自动重试的通行规则。 |

本地等待资源由创建它的最小作用域持有：`executeToolWithWait` 的 deadline timer／abort listener、批次的进度 timer／wake，以及采样重试的退避 timer／listener，都在成功或异常退出时清理。退避可以取消，每次采样前重新检查 signal。任务记录保存业务状态和操作身份；删除该记录不会自动调用 `clearTimeout`，运行取消必须显式传递到活动作用域。进程内 timer handle 不进入检查点。

持久检查点本身也不证明任务成功。非结构化回答、业务验证结果和执行回执怎样共同决定完成，仍需应用给出规则。

## 验证与性能

以下命令均在仓库根执行：

```sh
pnpm --filter @helix/agent-harness test
pnpm --filter @helix/agent-harness typecheck
pnpm check:harness-boundaries
pnpm check:harness-package
```

前两项检查包内行为和类型；边界检查与真实产物消费检查用于发现 Server、私有协议或仓库路径的依赖泄漏。根 `pnpm test` 还包括 Helix 各应用回归，独立示例通过不能替代平台验收。

需要比较两个固定构建的框架开销时：

```sh
pnpm bench:harness --old-module OLD.js --new-module NEW.js --output-dir /tmp/harness-timing
```

两个模块应指向各自构建的 `apps/server/dist/agents/harness/helixHarnessBackend.js`。默认每组预热 50 次、采样 1000 次，使用确定性本地模型和工具，保留原始计时、输入和调用计数；先确认行为与调用计数差异，再解释延迟。它不测真实服务商首字时间、数据库延迟或浏览器体验，也不替代这些验收。

## 版本与内部入口

新接入使用 `./standalone` 默认装配或包根的底层导出。`package.json` 中有限的精确 `internal/*`、`models/*` 子路径供 Helix 内部适配调用，目的是保持错误类与流处理对象的同一身份；它们不是插件扩展目录，也不承诺稳定。当前 `private: true`、版本 `0.0.0`，升级时应核对公开类型和消费测试；本包未作 SDK 发布承诺。
