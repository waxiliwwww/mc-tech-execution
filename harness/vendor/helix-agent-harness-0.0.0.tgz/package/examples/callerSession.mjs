// @ts-check
import { createHash } from "node:crypto";

/** @typedef {import("@helix/agent-harness").HarnessSessionStore} HarnessSessionStore */

/**
 * Caller-owned Map implementation of the public session contract.
 * Records are copied and returned in insertion order. This is process-local
 * example storage; accepting a checkpoint does not promise disk persistence.
 *
 * @implements {HarnessSessionStore}
 */
export class CallerMapSession {
  /** @type {Map<string, import("@helix/agent-harness").SessionHistoryRecord>} */
  #history = new Map();
  /** @type {Map<string, import("@helix/agent-harness").SessionCheckpointRecord>} */
  #checkpoints = new Map();
  #nextId = 0;
  /** @type {Error | undefined} */
  #saveFailure;

  /** @param {{ saveFailure?: Error }} [options] Local failure injection for the example's save-error check. */
  constructor(options = {}) {
    this.#saveFailure = options.saveFailure;
  }

  /** @param {import("@helix/agent-harness").SessionHistoryAppend} input */
  appendRollout(input) {
    const sequence = this.listRollout(input.chatId, input.turnId).length + 1;
    const entry = {
      ...structuredClone(input),
      id: `map-entry-${++this.#nextId}`,
      sequence,
      createdAt: "2026-09-30T00:00:00.000Z",
    };
    this.#history.set(entry.id, entry);
    return structuredClone(entry);
  }

  /**
   * @param {string} chatId
   * @param {string} [turnId]
   */
  listRollout(chatId, turnId) {
    return structuredClone(
      [...this.#history.values()].filter(
        (entry) => entry.chatId === chatId && (turnId === undefined || entry.turnId === turnId),
      ),
    );
  }

  /** @param {string} id */
  getCheckpoint(id) {
    const checkpoint = this.#checkpoints.get(id);
    return checkpoint === undefined ? undefined : structuredClone(checkpoint);
  }

  /** @param {import("@helix/agent-harness").SessionCheckpointSave} input */
  async saveCheckpoint(input) {
    if (this.#saveFailure) throw this.#saveFailure;
    const checkpoint = {
      ...structuredClone(input),
      id: `map-checkpoint-${++this.#nextId}`,
      createdAt: "2026-09-30T00:00:00.000Z",
      stateDigest: createHash("sha256").update(JSON.stringify(input.state)).digest("hex"),
    };
    this.#checkpoints.set(checkpoint.id, checkpoint);
    return structuredClone(checkpoint);
  }
}
