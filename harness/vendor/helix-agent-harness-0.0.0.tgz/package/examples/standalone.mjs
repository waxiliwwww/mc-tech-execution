import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  assertNativeCompactionOutput,
  compactionTranscript,
  compactionUsage,
  coordinateContextCompaction,
  coordinateToolBatch,
  deduplicateReadEvidence,
  encodeNativeCompactionRequest,
  estimateAgentTokens,
  estimateContextPressure,
  estimateHarnessTokens,
  executeToolWithWait,
  MemoryHarnessSessionStore,
  nativeCompactionMessages,
  OpenAiModelDriver,
  persistedModelResult,
  preflightToolCandidates,
  projectToolResultViews,
  sampleModelWithRetry,
  selectAgentContextWithinBudget,
} from "@helix/agent-harness";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";
import { runRunnerExamples } from "./runner.mjs";

// This consumer owns its validator. Standard JSON Schema 2020-12 is sufficient
// for this example; Helix-specific keywords and failure encodings are not used.
const ajv = new Ajv2020({
  allErrors: true,
  allowUnionTypes: true,
  coerceTypes: false,
  removeAdditional: false,
  useDefaults: true,
  strict: true,
  strictTuples: false,
  strictRequired: false,
  strictTypes: false,
  validateFormats: true,
});
addFormats(ajv);

/** Validate a cloned input so defaults cannot mutate the model's raw evidence. */
function validateInput(schema, input) {
  const value = structuredClone(input);
  const validate = ajv.compile(schema);
  return validate(value)
    ? { valid: true, value, diagnostics: [] }
    : {
        valid: false,
        diagnostics: validate.errors.map((error) => ({
          code: `json_schema_${error.keyword}`,
          path: error.instancePath || "/",
          message: error.message || "Invalid input",
        })),
      };
}

/** Parse plain JSON objects; the caller selects any additional wire-size policy. */
function parseJsonObjectText(source) {
  try {
    const value = JSON.parse(source);
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return { valid: true, value, diagnostics: [] };
    }
  } catch {
    // Parsing failure remains an untrusted proposal, never an executable call.
  }
  return { valid: false, diagnostics: [{ code: "invalid_json_object", path: "/", message: "Expected a JSON object" }] };
}

const definition = {
  name: "multiply",
  description: "Multiply a value by a positive integer.",
  inputSchema: {
    type: "object",
    properties: { value: { type: "number" }, factor: { type: "integer", minimum: 1, default: 2 } },
    required: ["value"],
    additionalProperties: false,
  },
};
const signal = new AbortController().signal;
const events = [];
let providerCalls = 0;
let preparations = 0;
let executions = 0;
const ports = {
  async *sample(request, receivedSignal) {
    assert.equal(receivedSignal, signal);
    providerCalls += 1;
    if (providerCalls === 1) {
      assert.deepEqual(request.messages, [{ role: "user", content: "Double 42 with multiply." }]);
      yield { type: "tool_call_delta", index: 0, id: "call-1", name: "multiply", argumentsDelta: '{"value":42}' };
      yield { type: "completed", finishReason: "tool_calls" };
    } else {
      assert.equal(providerCalls, 2);
      assert.equal(request.messages.at(-1).content, '{"value":84}');
      assert.equal(request.messages.at(-1).toolCallId, "call-1");
      yield { type: "text_delta", delta: "The result is 84." };
      yield { type: "completed", finishReason: "stop" };
    }
  },
  createEvent: (kind, content, options) => ({ kind, content, ...options }),
  parseJsonObjectText,
  restoreStructuredOutput: (schema, value) => {
    const result = validateInput(schema, value);
    assert.equal(result.valid, true);
    return result.value;
  },
  recordRetry: () => assert.fail("This deterministic example must not retry"),
};
const request = {
  turnId: "turn-1",
  stepId: "step-1",
  messages: [{ role: "user", content: "Double 42 with multiply." }],
  tools: [definition],
  maxOutputTokens: 256,
};

/** Consume streaming events while retaining the generator's completed sample. */
async function sample(input) {
  const stream = sampleModelWithRetry({ diagnosticContext: {}, supportsStrictJsonSchema: false }, ports, input, signal);
  while (true) {
    const item = await stream.next();
    if (item.done) return item.value;
    events.push(item.value);
  }
}

const proposal = await sample(request);
assert.equal(proposal.toolCalls.length, 1);
const preflightPorts = {
  validateInput,
  // This consumer does not expose structured domain failures. Unknown objects
  // are rejected rather than cast into the core's failure contract.
  parseOperationFailure: () => undefined,
  lookup: (name) =>
    name === definition.name
      ? { status: "found", definition }
      : { status: "unavailable", allowedNames: [definition.name] },
  normalizeInput: (_tool, input) => input,
  prepareExecution: async (_tool, call) => {
    preparations += 1;
    return {
      status: "accepted",
      input: call.input,
      precondition: { preconditionDigest: "example-v1", worldStateDigest: "example-v1" },
    };
  },
};
const accepted = await preflightToolCandidates(proposal.toolCalls, preflightPorts, signal);
assert.equal(accepted.rejected.length, 0);
assert.equal(accepted.calls.length, 1);
assert.deepEqual(accepted.calls[0].input, { value: 42, factor: 2 });
assert.deepEqual(proposal.toolCalls[0].input, { value: 42 });
assert.equal(executions, 0);

// Actual tool execution is the caller's responsibility, after any authorization
// it requires. This pure arithmetic tool has no external effect or paid call.
const call = accepted.calls[0];
const outcomes = new Map();
const batch = coordinateToolBatch(accepted.calls, {
  selectSpecial: () => undefined,
  isParallel: () => true,
  waitsForCompletion: () => false,
  execute: (item) =>
    executeToolWithWait(
      {
        execute: async () => {
          executions += 1;
          return { value: item.input.value * item.input.factor };
        },
        waitForCompletion: () => false,
        timeoutMs: () => 1_000,
        timeoutResult: () => assert.fail("Local arithmetic must settle before its timeout"),
        abortResult: () => assert.fail("Local arithmetic is not a long wait"),
        lateResult: () => assert.fail("Local arithmetic has no late receipt"),
        selectRetry: () => undefined,
        settle: (result, timedOut) => {
          assert.equal(timedOut, false);
          return result;
        },
      },
      signal,
    ),
  executeSpecial: async function* () {
    yield* [];
    assert.fail("This example has no special actions");
  },
  acceptOutcome: (item, output) => outcomes.set(item.id, output),
  progressEvent: () => assert.fail("This example has no long-running actions"),
});
while (true) {
  const next = await batch.next();
  if (next.done) {
    assert.equal(next.value.stopped, false);
    break;
  }
  events.push(next.value);
}
const result = outcomes.get(call.id);
const completed = await sample({
  ...request,
  stepId: "step-2",
  messages: [
    ...request.messages,
    { role: "assistant", content: "", toolCalls: accepted.calls },
    { role: "tool", content: JSON.stringify(result), toolCallId: call.id, name: call.name },
  ],
});
assert.equal(completed.text, "The result is 84.");
assert.equal(executions, 1);
assert.ok(events.some((event) => event.kind === "message.delta"));

// Reject wrong types, extra properties and invalid minimums before preparation.
for (const input of [{ value: "42" }, { value: 42, extra: true }, { value: 42, factor: 0 }]) {
  const rawArguments = JSON.stringify(input);
  const rejected = await preflightToolCandidates(
    [
      {
        id: "invalid",
        name: "multiply",
        input,
        diagnostics: [],
        rawArguments,
        rawArgumentsBytes: Buffer.byteLength(rawArguments),
        rawArgumentsDigest: createHash("sha256").update(rawArguments).digest("hex"),
      },
    ],
    preflightPorts,
    signal,
  );
  assert.equal(rejected.calls.length, 0);
  assert.equal(rejected.rejected.length, 1);
}
assert.equal(preparations, 1);
assert.equal(executions, 1);
assert.equal(
  validateInput(
    {
      type: "object",
      properties: { email: { type: "string", format: "email" } },
      required: ["email"],
      additionalProperties: false,
    },
    { email: "invalid" },
  ).valid,
  false,
);
assert.equal(
  validateInput(
    {
      type: "object",
      properties: { mode: { type: "string", enum: ["safe"] } },
      required: ["mode"],
      additionalProperties: false,
    },
    { mode: "other" },
  ).valid,
  false,
);
// A second, independent example consumes the public request-encoding/HTTP/SSE entry.
// The caller owns schema/material projection and supplies a fake fetch; no network is used.
const driverRequest = {
  messages: [{ role: "user", content: "Show a streamed answer." }],
  tools: [definition],
  maxOutputTokens: 64,
  streamingEnabled: true,
};
const driverConnection = {
  url: "https://provider.invalid/v1/chat/completions",
  apiKey: "synthetic-no-network-key",
  requestTimeoutMs: 1_000,
  stepId: "driver-example",
  maxOutputTokens: driverRequest.maxOutputTokens,
};
const expectedDriverBody = {
  model: "synthetic-driver-model",
  messages: driverRequest.messages,
  tools: [
    {
      type: "function",
      function: {
        name: definition.name,
        description: definition.description,
        parameters: definition.inputSchema,
        strict: false,
      },
    },
  ],
  max_tokens: 64,
  tool_choice: "auto",
  parallel_tool_calls: false,
  stream: true,
  stream_options: { include_usage: true },
};
let encodedPreparations = 0;
const requestEncoding = {
  strictSchema: () => false,
  defaultStreamingEnabled: () => true,
  jsonSchemaEnabled: () => false,
  parallelToolsEnabled: () => false,
  modelId: () => "synthetic-driver-model",
  thinkingBody: () => undefined,
  content: async (content) => {
    assert.equal(typeof content, "string", "This example supports text only");
    return content;
  },
  tools: (tools, strict) =>
    tools.map((tool) => {
      assert.equal(strict, false, "This example does not implement strict Provider schema translation");
      ajv.compile(tool.inputSchema);
      return { name: tool.name, description: tool.description, parameters: structuredClone(tool.inputSchema), strict };
    }),
  outputSchema: (schema, strict) => {
    assert.equal(strict, false, "This example does not implement strict Provider schema translation");
    ajv.compile(schema);
    return { parameters: structuredClone(schema), diagnostics: [] };
  },
  historicalInput: (tool, input) => {
    assert.ok(tool, "Historical tool calls need an explicit tool definition");
    const result = validateInput(tool.inputSchema, input);
    assert.equal(result.valid, true);
    return result.value;
  },
  prepared: (prepared) => {
    encodedPreparations += 1;
    assert.equal(prepared.wireProtocol, "chat_completions");
    assert.equal(prepared.strictSchema, false);
    assert.equal(prepared.streamingEnabled, true);
    assert.deepEqual(
      prepared.modelTools.map((tool) => tool.name),
      ["multiply"],
    );
    assert.deepEqual(prepared.body, expectedDriverBody);
    return driverConnection;
  },
};
const driverEvents = [
  { id: "driver-response", choices: [{ index: 0, delta: { content: "Driver " } }] },
  {
    id: "driver-response",
    choices: [{ index: 0, delta: { content: "works." }, finish_reason: "stop" }],
    usage: { prompt_tokens: 4, completion_tokens: 2, total_tokens: 6 },
  },
];
const wire = new TextEncoder().encode(
  `${driverEvents.map((event) => `data: ${JSON.stringify(event)}\n\n`).join("")}data: [DONE]\n\n`,
);
let driverFetches = 0;
const driver = new OpenAiModelDriver(64 * 1024, async (url, init) => {
  driverFetches += 1;
  assert.equal(String(url), driverConnection.url);
  assert.equal(init.method, "POST");
  assert.equal(init.body, JSON.stringify(expectedDriverBody));
  assert.equal(new Headers(init.headers).get("authorization"), `Bearer ${driverConnection.apiKey}`);
  assert.equal(new Headers(init.headers).get("accept"), "text/event-stream");
  return new Response(
    new ReadableStream({
      start(controller) {
        // Deliberately split a frame across packets; the real parser must reassemble it.
        controller.enqueue(wire.subarray(0, 13));
        controller.enqueue(wire.subarray(13));
        controller.close();
      },
    }),
    { headers: { "content-type": "text/event-stream" } },
  );
});
const driverPhases = [];
let observedFrames = 0;
const receivedDriverBytes = [];
let sawTerminator = false;
let streamExhausted = false;
const observation = {
  // Production callers redact authorization before persisting request data.
  // This example records phase names only and keeps wire-body capture disabled.
  record: (phase) => driverPhases.push(phase),
  captureWire: () => false,
  startStream: () => ({
    received: (bytes, receivedAt) => {
      assert.ok(bytes instanceof Uint8Array);
      assert.ok(Number.isFinite(Date.parse(receivedAt)));
      receivedDriverBytes.push(Buffer.from(bytes));
    },
    observe: (_value, bytes) => {
      assert.ok(bytes > 0);
      observedFrames += 1;
    },
    unparsed: () => assert.fail("The valid synthetic stream must parse"),
    terminator: () => {
      sawTerminator = true;
    },
    finish: (exhausted) => {
      streamExhausted = exhausted;
    },
  }),
};
const driverChunks = [];
for await (const chunk of driver.stream("chat_completions", driverRequest, requestEncoding, signal, observation))
  driverChunks.push(chunk);
const driverAnswer = driverChunks
  .filter((chunk) => chunk.type === "text_delta")
  .map((chunk) => chunk.delta)
  .join("");
assert.equal(driverAnswer, "Driver works.");
assert.equal(driverFetches, 1);
assert.equal(encodedPreparations, 1);
assert.equal(driverChunks.at(-1).type, "response_completed");
assert.deepEqual(
  driverChunks.filter((chunk) => chunk.type === "usage"),
  [{ type: "usage", inputTokens: 4, outputTokens: 2, totalTokens: 6, inputTokensIncludeCache: true }],
);
assert.deepEqual(driverPhases.slice(0, 2), ["request", "response_headers"]);
assert.equal(observedFrames, 2);
assert.deepEqual(Buffer.concat(receivedDriverBytes), Buffer.from(wire));
assert.equal(sawTerminator, true);
assert.equal(streamExhausted, true);

// The caller selects its model view; full audit/event views retain the source receipt.
const sourceReceipt = {
  answer: 42,
  error: "verification_failed",
  internalNote: "caller-owned",
  text: "x".repeat(80_000),
};
const sourceJson = JSON.stringify(sourceReceipt);
let modelProjections = 0;
const projectedViews = projectToolResultViews(sourceReceipt, { outputTokenLimit: 128 }, (value) => {
  modelProjections += 1;
  return { answer: value.answer, error: value.error };
});
assert.equal(modelProjections, 1);
assert.equal(projectedViews.audit.json, sourceJson);
assert.equal(projectedViews.event.json, sourceJson);
assert.deepEqual(projectedViews.model.value, { answer: 42, error: "verification_failed" });
assert.equal(projectedViews.model.sha256, createHash("sha256").update(sourceJson).digest("hex"));
assert.equal(projectedViews.model.originalBytes, Buffer.byteLength(sourceJson));
const storedProjection = persistedModelResult(projectedViews.model);
assert.equal(storedProjection.json, projectedViews.model.json);
assert.equal(storedProjection.sha256, projectedViews.audit.sha256);
assert.equal(JSON.stringify(sourceReceipt), sourceJson);

// Context preparation uses caller-owned tool policy and leaves original receipts unchanged.
const repeatedReceipt = "x".repeat(4096);
const contextMessages = [
  { role: "tool", name: "read_sample", toolCallId: "read-1", content: repeatedReceipt },
  { role: "tool", name: "read_sample", toolCallId: "read-2", content: repeatedReceipt },
];
const contextProjection = deduplicateReadEvidence(contextMessages, (name) => name === "read_sample");
assert.equal(contextProjection[0], contextMessages[0]);
assert.equal(JSON.parse(contextProjection[1].content).originalToolCallId, "read-1");
assert.equal(contextMessages[1].content, repeatedReceipt);
assert.equal(estimateAgentTokens("hello"), 2);
const materials = [{ text: "x".repeat(100) }, { x: 1 }];
const selection = selectAgentContextWithinBudget(materials, 2, () => 0);
assert.deepEqual(selection.selected, [materials[1]]);
assert.equal(selection.selected[0], materials[1]);
assert.equal(selection.tokens, 2);
assert.equal(selection.omitted, 1);

// Native compaction uses the same package transport with a caller-owned deadline.
const transcript = compactionTranscript(
  [{ role: "user", content: [{ type: "text", text: "keep constraint" }] }],
  1000,
  (part) => part.text,
);
assert.deepEqual(JSON.parse(transcript), [{ role: "user", content: "keep constraint" }]);
const nativeBody = encodeNativeCompactionRequest("example-model", [{ role: "user", content: "history" }]);
let compactionFetches = 0;
const nativeDriver = new OpenAiModelDriver(64 * 1024, async (url, init) => {
  compactionFetches += 1;
  assert.equal(String(url), "https://example.invalid/responses/compact");
  assert.equal(init.body, JSON.stringify(nativeBody));
  return new Response(
    JSON.stringify({
      output: [{ type: "compaction", encrypted_content: "opaque" }],
      usage: { input_tokens: 8, output_tokens: 2, total_tokens: 10 },
    }),
    { headers: { "content-type": "application/json" } },
  );
});
const nativeResponse = await nativeDriver.readCompaction(
  { url: "https://example.invalid/responses/compact", apiKey: "example-only", body: nativeBody },
  signal,
  {},
);
assertNativeCompactionOutput(nativeResponse);
const compactedMessages = nativeCompactionMessages(nativeResponse.output);
assert.equal(compactedMessages[0].providerItem, nativeResponse.output[0]);
assert.deepEqual(compactionUsage(nativeResponse.usage, true), {
  inputTokens: 8,
  outputTokens: 2,
  totalTokens: 10,
  inputTokensIncludeCache: true,
});
assert.equal(compactionFetches, 1);

// A standalone caller can retain history and a continuation point in this
// process. This deliberately does not imply disk storage or restart recovery.
let sessionRecord = 0;
const sessionStore = new MemoryHarnessSessionStore({
  rollout: () => ({ id: `entry-${++sessionRecord}`, createdAt: new Date().toISOString() }),
  checkpoint: (state) => ({
    id: `checkpoint-${++sessionRecord}`,
    createdAt: new Date().toISOString(),
    stateDigest: createHash("sha256").update(JSON.stringify(state)).digest("hex"),
  }),
});
sessionStore.appendRollout({
  chatId: "standalone",
  turnId: "turn-1",
  kind: "input",
  content: { items: [{ type: "text", text: "Double 42" }] },
});
sessionStore.appendRollout({
  chatId: "standalone",
  turnId: "turn-1",
  kind: "model.response",
  content: { text: completed.text },
});
const sessionCheckpoint = await sessionStore.saveCheckpoint({
  chatId: "standalone",
  turnId: "turn-1",
  reason: "step",
  rolloutSequence: 2,
  stateVersion: 1,
  state: { phase: "completed" },
});
assert.equal(sessionStore.listRollout("standalone").length, 2);
assert.deepEqual(sessionStore.listRollout("another-session"), []);
assert.equal(sessionStore.getCheckpoint(sessionCheckpoint.id)?.state.phase, "completed");

// Control policy can use a real compact response with caller-owned metadata and storage.
const pressuredMessages = [{ role: "assistant", content: "old observation ".repeat(1000) }];
const pressure = estimateContextPressure({
  localMessageEstimate: estimateHarnessTokens(pressuredMessages),
  reservedInputTokens: 100,
  maxInputTokens: 5000,
  providerContextTokens: 4800,
  providerReservedTokens: 100,
  providerLocalBaseline: estimateHarnessTokens(pressuredMessages),
});
assert.equal(pressure.requiresCompaction, true);
let acceptedContext;
const controlEvents = [];
const control = coordinateContextCompaction(
  {
    messages: pressuredMessages,
    estimatedMessages: pressure.estimatedMessages,
    reservedInputTokens: 100,
    maxInputTokens: 5000,
    finalizing: false,
    remoteCompactionFailed: false,
  },
  {
    begin() {},
    summarize: () => "Retain the requested objective and completed receipts.",
    observe() {},
    remoteCandidate: async () => ({ method: "remote", replacementMessages: compactedMessages }),
    remoteFailure() {},
    isAborted: () => false,
    disableRemote: (_error, recoverable) => ({ kind: "warning", recoverable }),
    continuity: () => [{ role: "user", content: "Current objective: double 42." }],
    async waitForCapacity() {
      const checkpoint = await sessionStore.saveCheckpoint({
        chatId: "standalone",
        turnId: "turn-1",
        reason: "long_task",
        rolloutSequence: 2,
        stateVersion: 2,
        state: { phase: "context_compaction" },
      });
      return { kind: "waiting", checkpointId: checkpoint.id };
    },
    accept: (_candidate, messages) => {
      acceptedContext = messages;
      return { kind: "compacted" };
    },
  },
);
for (;;) {
  const item = await control.next();
  if (item.done) {
    if (item.value.event) controlEvents.push(item.value.event);
    break;
  }
  controlEvents.push(item.value);
}
assert.deepEqual(controlEvents, [{ kind: "compacted" }]);
assert.equal(acceptedContext[0].providerItem, compactedMessages[0].providerItem);
assert.equal(acceptedContext.at(-1).content, "Current objective: double 42.");

const independentRunner = await runRunnerExamples({ validateInput, parseJsonObjectText });

console.log(
  JSON.stringify({
    status: "passed",
    independentRunner,
    contextControl: controlEvents.map((event) => event.kind),
    sessionEntries: sessionStore.listRollout("standalone").length,
    checkpointSavedInMemory: true,
    providerCalls,
    preparations,
    executions,
    answer: completed.text,
    eventCount: events.length,
    driverFetches,
    driverAnswer,
    observedFrames,
    receivedDriverByteCount: Buffer.concat(receivedDriverBytes).byteLength,
    compactionFetches,
    modelProjections,
  }),
);

/** 2026-09-30: Standalone consumer assertion to merge into the existing installed-tarball example. */
import {
  isDelegationCapacityAvailable,
  isDelegationCompletionOutcome,
  isDelegationDepthAllowed,
  narrowDelegationTools,
  settleDelegation,
} from "@helix/agent-harness";

assert.equal(isDelegationDepthAllowed(1, 3), true);
assert.equal(isDelegationDepthAllowed(4, 3), false);
const delegationHistory = [{ status: "started" }];
assert.equal(isDelegationCapacityAvailable(delegationHistory, false, 1), false);
assert.equal(isDelegationCapacityAvailable(delegationHistory, true, 1), true);
assert.deepEqual(
  narrowDelegationTools([{ name: "read" }, { name: "write" }, { name: "delegate" }], {
    excludedNames: ["delegate"],
    requestedNames: ["read", "write", "missing"],
    assignedNames: ["read"],
    normalizeName: (name) => name,
  }),
  ["read"],
);
const childDisposition = settleDelegation(
  { cancelled: false, waiting: true, completed: isDelegationCompletionOutcome("incomplete"), hasOutput: true },
  () => assert.fail("waiting must not read a later cancellation point"),
);
assert.deepEqual(childDisposition, { kind: "waiting" });

// The default assembly is consumed from the installed tarball, without host ports.
{
  const { createHarness } = await import("@helix/agent-harness/standalone");
  const { mkdtemp, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const cwd = await mkdtemp(join(tmpdir(), "harness-standalone-tools-"));
  const agent = await createHarness({
    cwd,
    mcpServers: [],
    sample: async function* (request) {
      if (!request.messages.some((message) => message.role === "tool")) {
        yield {
          type: "tool_call_delta",
          index: 0,
          id: "write-1",
          name: "write",
          argumentsDelta: JSON.stringify({ path: "answer.txt", content: "42\n" }),
        };
        yield { type: "completed", finishReason: "tool_calls" };
      } else {
        yield { type: "reasoning_delta", delta: "The write receipt confirms completion." };
        yield { type: "text_delta", delta: "Saved 42." };
        yield { type: "completed", finishReason: "stop" };
      }
    },
  });
  try {
    assert.deepEqual(
      agent.tools.map((tool) => tool.name),
      ["read", "bash", "edit", "write"],
    );
    const events = [];
    for await (const event of agent.run("Save 42 in answer.txt")) events.push(event);
    assert.ok(events.some((event) => event.kind === "tool.result"));
    assert.ok(events.some((event) => event.kind === "turn.completed"));
    assert.equal(await readFile(join(cwd, "answer.txt"), "utf8"), "42\n");
    const edited = await agent.callTool("edit", { path: "answer.txt", oldText: "42", newText: "43" });
    assert.ok(!edited.isError);
    const read = await agent.callTool("read", { path: "answer.txt" });
    assert.ok(JSON.stringify(read).includes("43"));
    const bash = await agent.callTool("bash", { command: "pwd" });
    assert.ok(JSON.stringify(bash).includes(cwd));
    await assert.rejects(agent.callTool("not-enabled", {}));
    console.log("Installed default assembly: model/tool loop and read/bash/edit/write passed");
  } finally {
    await agent.close();
    await rm(cwd, { recursive: true, force: true });
  }
  const chat = await createHarness({ builtinTools: [], mcpServers: [] });
  try {
    assert.equal(chat.tools.length, 0);
    await assert.rejects(chat.callTool("write", { path: "never", content: "no" }));
  } finally {
    await chat.close();
  }
}
