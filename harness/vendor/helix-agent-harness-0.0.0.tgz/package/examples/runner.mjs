import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { MemoryHarnessSessionStore, preflightToolCandidates, runHarness } from "@helix/agent-harness";
import { CallerMapSession } from "./callerSession.mjs";

/** Build caller-owned, process-local state; no disk or restart guarantee is implied. */
function memorySession() {
  let sequence = 0;
  return new MemoryHarnessSessionStore({
    rollout: () => ({ id: `message-${++sequence}`, createdAt: "2026-09-30T00:00:00.000Z" }),
    checkpoint: (state) => ({
      id: `checkpoint-${++sequence}`,
      createdAt: "2026-09-30T00:00:00.000Z",
      stateDigest: createHash("sha256").update(JSON.stringify(state)).digest("hex"),
    }),
  });
}

const multiply = {
  implementationVersion: 1,
  definition: {
    name: "multiply",
    description: "Multiply two numbers without external effects.",
    inputSchema: {
      type: "object",
      properties: { value: { type: "number" }, factor: { type: "number", default: 2 } },
      required: ["value"],
      additionalProperties: false,
    },
  },
  input: { value: 42 },
  execute: ({ value, factor }) => ({ value: value * factor }),
};
const sum = {
  implementationVersion: 1,
  definition: {
    name: "sum",
    description: "Add numbers without external effects.",
    inputSchema: {
      type: "object",
      properties: { values: { type: "array", items: { type: "number" }, minItems: 1 } },
      required: ["values"],
      additionalProperties: false,
    },
  },
  input: { values: [20, 22] },
  execute: ({ values }) => ({ value: values.reduce((total, value) => total + value, 0) }),
};
const modes = {
  chat: "Answer the user's question from the tool result.",
  analysis: "Analyse the tool result and explicitly cite its receipt.",
};

/** Fingerprint the exact normalized input, schema and pure executor configuration. */
function executionPrecondition(tool, input) {
  const digest = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
  return {
    preconditionDigest: digest({ name: tool.definition.name, schema: tool.definition.inputSchema, input }),
    worldStateDigest: digest({
      executor: tool.definition.name,
      implementationVersion: tool.implementationVersion,
      nodeVersion: process.versions.node,
      externalState: false,
    }),
  };
}

/**
 * Bind one application run to the same public loop Helix uses.
 * The provider is a local scripted stream; tools perform real pure arithmetic.
 * Storage, mode materials and tool definitions are caller configuration, not loop edits.
 */
async function runExample({
  tool,
  mode,
  session,
  chatId,
  validateInput,
  parseJsonObjectText,
  control = "complete",
  observedEvents = [],
}) {
  const signalController = new AbortController();
  const turnId = "example-turn";
  const events = observedEvents;
  const requests = [];
  const trace = [];
  let toolCalls = 0;
  const appendMessage = (message) => session.appendRollout({ chatId, turnId, kind: "message", content: { message } });
  const history = () =>
    session
      .listRollout(chatId)
      .filter((entry) => entry.kind === "message")
      .map((entry) => entry.content.message);
  appendMessage({ role: "user", content: `Use ${tool.definition.name} for the requested calculation.` });
  if (control === "cancel-before") signalController.abort();
  const signal = signalController.signal;
  /** @type {import("@helix/agent-harness").ToolCandidatePreflightPorts<import("@helix/agent-harness").CandidateToolDefinition>} */
  const preflightPorts = {
    validateInput,
    parseOperationFailure: () => undefined,
    lookup: (name) =>
      name === tool.definition.name
        ? { status: "found", definition: tool.definition }
        : { status: "unavailable", allowedNames: [tool.definition.name] },
    normalizeInput: (_definition, input) => input,
    prepareExecution: async (_definition, call) => ({
      status: "accepted",
      input: call.input,
      precondition: executionPrecondition(tool, call.input),
    }),
  };
  const ports = {
    cancelled: () => ({ kind: "run.cancelled", content: {} }),
    async *schedulerYield() {
      yield { kind: "run.waiting", content: { reason: "scheduler" } };
    },
    async *prepareStep(index) {
      trace.push(`prepare:${index}`);
      const invocation = {
        context: { diagnosticContext: {}, supportsStrictJsonSchema: false },
        input: {
          turnId,
          stepId: `step-${index}`,
          messages: [{ role: "system", content: modes[mode] }, ...history()],
          tools: [tool.definition],
          maxOutputTokens: 256,
        },
        ports: {
          createEvent: (kind, content, options) => ({ kind, content, ...options }),
          parseJsonObjectText,
          restoreStructuredOutput: (schema, value) => {
            const result = validateInput(schema, value);
            assert.equal(result.valid, true);
            return result.value;
          },
          recordRetry: () => assert.fail("The local provider must not retry"),
          async *sample(request, receivedSignal) {
            assert.equal(receivedSignal, signal);
            requests.push(structuredClone(request));
            assert.ok(requests.length <= 2, "The loop must stop after its final answer");
            if (control === "model-failure") throw new Error("example_model_failed");
            if (requests.length === 1) {
              yield {
                type: "tool_call_delta",
                index: 0,
                id: "arithmetic-call",
                name: tool.definition.name,
                argumentsDelta: JSON.stringify(tool.input),
              };
              yield { type: "completed", finishReason: "tool_calls" };
            } else {
              const receipt = request.messages.at(-1);
              assert.equal(receipt.role, "tool");
              assert.equal(receipt.toolCallId, "arithmetic-call");
              const { value } = JSON.parse(receipt.content);
              yield { type: "text_delta", delta: `${mode}: ${value}` };
              yield { type: "completed", finishReason: "stop" };
            }
          },
        },
      };
      return {
        toolsEnabled: true,
        model: () => invocation,
        async *modelFailed(error) {
          yield { kind: "run.failed", content: { error: error instanceof Error ? error.message : String(error) } };
          return { kind: "stop" };
        },
        async *validateProposal(sample) {
          yield* [];
          const preflight = await preflightToolCandidates(sample.toolCalls, preflightPorts, signal);
          assert.equal(preflight.rejected.length, 0, "Only fully validated proposals can dispatch");
          return { kind: "accepted", sample, preflight };
        },
        acceptProposal({ sample, preflight }) {
          trace.push(`accept:${index}`);
          appendMessage({
            role: "assistant",
            content: sample.rawText,
            ...(preflight.calls.length ? { toolCalls: preflight.calls } : {}),
          });
        },
        async *resolveAnswer(sample) {
          yield { kind: "run.completed", content: { answer: sample.text } };
          return { kind: "stop" };
        },
        async *resolveDisabledTools() {
          yield* [];
          assert.fail("These configurations leave their pure tools enabled");
        },
        async *executeTools(proposal) {
          const preconditionsByCallId = proposal.preflight.preconditions;
          assert.equal(preconditionsByCallId.size, proposal.preflight.calls.length);
          for (const call of proposal.preflight.calls) {
            const prepared = preconditionsByCallId.get(call.id);
            assert.ok(prepared, "Every accepted call must retain its own preparation identity");
            assert.deepEqual(
              prepared,
              executionPrecondition(tool, call.input),
              "Recheck current input and executor state before execution",
            );
          }
          if (control === "wait") {
            // A caller-defined pause with a process-local continuation record.
            // No claim is made about approval, remote dispatch or durable resume.
            const checkpoint = await session.saveCheckpoint({
              chatId,
              turnId,
              reason: "example_pause",
              rolloutSequence: session.listRollout(chatId).at(-1).sequence,
              state: { phase: "waiting", calls: proposal.preflight.calls, preconditions: [...preconditionsByCallId] },
            });
            yield { kind: "run.waiting", content: { reason: "example_external_input", checkpointId: checkpoint.id } };
            return { waiting: true, maxDeterministicFailureCount: 0 };
          }
          for (const call of proposal.preflight.calls) {
            trace.push(`tool:${index}`);
            const precondition = preconditionsByCallId.get(call.id);
            // Only the per-call identity checked above is attached to this execution receipt.
            const output = tool.execute(call.input);
            toolCalls++;
            appendMessage({ role: "tool", name: call.name, toolCallId: call.id, content: JSON.stringify(output) });
            yield { kind: "tool.completed", content: { toolCallId: call.id, output, ...precondition } };
          }
          if (control === "cancel-after-tool") signalController.abort();
          return { waiting: false, maxDeterministicFailureCount: 0 };
        },
        async *resolveToolResult() {
          yield* [];
          return { kind: "continue" };
        },
      };
    },
  };
  for await (const event of runHarness(ports, signal)) events.push(event);
  return { events, requests, trace, toolCalls, history: history() };
}

/** Exercise the public runner using caller replacements, not a duplicate agent loop. */
export async function runRunnerExamples({ validateInput, parseJsonObjectText }) {
  const execute = (options) => runExample({ validateInput, parseJsonObjectText, ...options });
  const session = memorySession();
  const initial = await execute({ tool: multiply, mode: "chat", session, chatId: "arithmetic" });
  assert.equal(initial.events.at(-1).content.answer, "chat: 84");
  assert.equal(initial.requests.length, 2);
  assert.equal(initial.toolCalls, 1);
  assert.deepEqual(initial.requests[1].messages.at(-1), {
    role: "tool",
    name: "multiply",
    toolCallId: "arithmetic-call",
    content: '{"value":84}',
  });
  assert.ok(initial.trace.indexOf("accept:0") < initial.trace.indexOf("tool:0"));
  assert.deepEqual(toolInput(initial), { value: 42, factor: 2 });
  const executionReceipt = initial.events.find((event) => event.kind === "tool.completed");
  assert.equal(executionReceipt.content.toolCallId, "arithmetic-call");
  assert.deepEqual(
    {
      preconditionDigest: executionReceipt.content.preconditionDigest,
      worldStateDigest: executionReceipt.content.worldStateDigest,
    },
    executionPrecondition(multiply, { value: 42, factor: 2 }),
  );
  assert.deepEqual(multiply.input, { value: 42 }, "Validation defaults must not mutate raw tool input");

  const replacedTool = await execute({ tool: sum, mode: "chat", session, chatId: "other-tool" });
  assert.equal(replacedTool.events.at(-1).content.answer, "chat: 42");
  assert.equal(replacedTool.requests[0].tools[0].name, "sum");
  assert.equal(replacedTool.toolCalls, 1);
  assert.equal(
    replacedTool.requests[0].messages.some((message) => message.role === "tool"),
    false,
    "Sessions must not share receipts",
  );

  const analysis = await execute({ tool: multiply, mode: "analysis", session, chatId: "analysis" });
  assert.equal(analysis.events.at(-1).content.answer, "analysis: 84");
  assert.equal(analysis.requests[0].messages[0].content, modes.analysis);
  assert.notEqual(analysis.requests[0].messages[0].content, initial.requests[0].messages[0].content);

  const replacement = memorySession();
  replacement.appendRollout({
    chatId: "fresh-memory",
    turnId: "earlier",
    kind: "message",
    content: { message: { role: "user", content: "Keep experiment LYRA." } },
  });
  const independent = await execute({ tool: multiply, mode: "chat", session: replacement, chatId: "fresh-memory" });
  assert.equal(independent.requests[0].messages[1].content, "Keep experiment LYRA.");
  assert.equal(independent.events.at(-1).content.answer, "chat: 84");
  assert.deepEqual(session.listRollout("fresh-memory"), []);
  assert.deepEqual(replacement.listRollout("arithmetic"), []);

  const waiting = await execute({ tool: multiply, mode: "chat", session, chatId: "waiting", control: "wait" });
  assert.equal(waiting.requests.length, 1);
  assert.equal(waiting.toolCalls, 0);
  assert.equal(waiting.events.at(-1).kind, "run.waiting");
  assert.equal(session.getCheckpoint(waiting.events.at(-1).content.checkpointId).state.phase, "waiting");
  assert.equal(
    waiting.events.some((event) => event.kind === "run.completed"),
    false,
  );

  for (const control of ["cancel-before", "cancel-after-tool"]) {
    const cancelled = await execute({ tool: multiply, mode: "chat", session, chatId: control, control });
    assert.equal(cancelled.events.at(-1).kind, "run.cancelled");
    assert.equal(cancelled.requests.length, control === "cancel-before" ? 0 : 1);
    assert.equal(cancelled.toolCalls, control === "cancel-before" ? 0 : 1);
    assert.equal(
      cancelled.events.some((event) => event.kind === "run.completed"),
      false,
    );
  }
  const mappedSession = new CallerMapSession();
  const mapped = await execute({ tool: multiply, mode: "chat", session: mappedSession, chatId: "mapped" });
  assert.equal(mapped.events.at(-1).content.answer, "chat: 84");
  assert.equal(mapped.requests.length, 2);
  assert.equal(mapped.toolCalls, 1);
  assert.equal(
    mappedSession.listRollout("mapped").some((entry) => entry.content.message.role === "tool"),
    true,
  );
  assert.deepEqual(mappedSession.listRollout("unrelated"), []);
  const mappedCopy = mappedSession.listRollout("mapped");
  mappedCopy[0].content.message.content = "mutated caller view";
  assert.notEqual(mappedSession.listRollout("mapped")[0].content.message.content, "mutated caller view");

  const saveFailure = new Error("example_checkpoint_save_failed");
  const failingSession = new CallerMapSession({ saveFailure });
  const failedSaveEvents = [];
  await assert.rejects(
    execute({
      tool: multiply,
      mode: "chat",
      session: failingSession,
      chatId: "save-failure",
      control: "wait",
      observedEvents: failedSaveEvents,
    }),
    (error) => error === saveFailure,
  );
  assert.equal(
    failedSaveEvents.some((event) => ["run.waiting", "run.completed", "tool.completed"].includes(event.kind)),
    false,
  );
  assert.equal(failingSession.getCheckpoint("map-checkpoint-3"), undefined);

  const failedModel = await execute({
    tool: multiply,
    mode: "chat",
    session,
    chatId: "model-failure",
    control: "model-failure",
  });
  assert.equal(failedModel.requests.length, 1);
  assert.equal(failedModel.toolCalls, 0);
  assert.deepEqual(failedModel.events.at(-1), { kind: "run.failed", content: { error: "example_model_failed" } });
  assert.equal(
    failedModel.events.some((event) => event.kind === "run.completed"),
    false,
  );

  return {
    entrypoint: "runHarness",
    scenarios: 10,
    answer: initial.events.at(-1).content.answer,
    replacedTool: "sum",
    modes: ["chat", "analysis"],
    waiting: true,
    cancellation: true,
    processLocalSessionOnly: true,
    sessionImplementations: ["MemoryHarnessSessionStore", "CallerMapSession"],
    failedSavePropagated: true,
    modelFailureVisible: true,
  };
}

function toolInput(result) {
  return result.history.find((message) => message.role === "assistant" && message.toolCalls?.length).toolCalls[0].input;
}
