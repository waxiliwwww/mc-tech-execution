import {
  assertNativeCompactionOutput,
  type CandidateToolDefinition,
  type CompletionAssessment,
  type ContextCompactionPorts,
  type ContractValidationResult,
  compactionTranscript,
  coordinateContextCompaction,
  coordinateToolBatch,
  deduplicateReadEvidence,
  encodeSummaryCompactionRequest,
  estimateAgentTokens,
  estimateContextPressure,
  executeToolWithWait,
  type HarnessHistoryEntry,
  type HarnessRunDirective,
  type HarnessRunPorts,
  type HarnessSessionStore,
  type HarnessStepPorts,
  MemoryHarnessSessionStore,
  type ModelChunk,
  type ModelMessage,
  type ModelRequest,
  type ModelSamplingPorts,
  nativeCompactionMessages,
  type OpenAiCallObservation,
  OpenAiModelDriver,
  type OpenAiRequestEncodingPorts,
  type OpenAiStreamObservation,
  type PreparedOpenAiCompactionCall,
  persistedModelResult,
  preflightToolCandidates,
  projectCompletedCodeArguments,
  projectToolResultViews,
  runHarness,
  type SamplingEvent,
  type SessionCheckpointRecord,
  type SessionRecoveryRecord,
  type SessionResumeCheckpoint,
  type SessionResumeRequest,
  sampleModelWithRetry,
  selectAgentContextWithinBudget,
  type ToolBatchCoordinatorPorts,
  type ToolCandidatePreflightPorts,
  type ToolExecutionWaitPorts,
  type ToolResultModelProjector,
  type ToolResultProjection,
} from "@helix/agent-harness";
import { CallerMapSession } from "./callerSession.mjs";

type ImagePart = { type: "image"; url: string };
type Tool = CandidateToolDefinition & { description: string; localId: string };
type Trace = { modelCallId?: string; externalTrace: string };
declare const samplingPorts: ModelSamplingPorts<ImagePart, Tool, Trace, SamplingEvent>;
declare const request: ModelRequest<ImagePart, Tool, Trace>;
declare const toolPorts: ToolCandidatePreflightPorts<Tool>;
declare const signal: AbortSignal;

const stream = sampleModelWithRetry(
  { diagnosticContext: { externalTrace: "consumer" }, supportsStrictJsonSchema: false },
  samplingPorts,
  request,
  signal,
);
const step = await stream.next();
if (step.done) {
  const trace: string | undefined = step.value.diagnosticContext?.externalTrace;
  const calls = await preflightToolCandidates(step.value.toolCalls, toolPorts, signal);
  const id: string | undefined = calls.calls[0]?.id;
  void trace;
  void id;
} else {
  const event: SamplingEvent = step.value;
  void event;
}

// These negative checks fail compilation if required adapters become optional.
declare const withoutParser: Omit<typeof samplingPorts, "parseJsonObjectText">;
// @ts-expect-error Parsing untrusted provider arguments requires an adapter.
const unsafeSampler: typeof samplingPorts = withoutParser;
declare const withoutValidator: Omit<typeof toolPorts, "validateInput">;
// @ts-expect-error Tool input validation must never be optional.
const unsafePreflight: typeof toolPorts = withoutValidator;
// @ts-expect-error A successful validator must provide the normalized value.
const missingValue: ContractValidationResult<Record<string, unknown>> = { valid: true, diagnostics: [] };
// @ts-expect-error Provider chunks do not expose arbitrary Helix Turn fields.
const platformChunk: ModelChunk = { type: "platform_turn", chatId: "chat" };
void [unsafeSampler, unsafePreflight, missingValue, platformChunk];

// The installed declarations expose one public request-encoding entry with mandatory caller ports.
declare const requestEncoding: OpenAiRequestEncodingPorts<ImagePart, Tool, NonNullable<typeof request.outputSchema>>;
declare const preparedCompaction: PreparedOpenAiCompactionCall;
const streamObservation: OpenAiStreamObservation = {
  received: (bytes, receivedAt) => {
    const payload: Uint8Array = bytes;
    const timestamp: string = receivedAt;
    void [payload, timestamp];
  },
  observe: (_value, bytes) => {
    const size: number = bytes;
    void size;
  },
  unparsed: (payload, reason) => {
    const text: string = payload + reason;
    void text;
  },
  terminator: () => {},
  finish: (exhausted) => {
    const finished: boolean = exhausted;
    void finished;
  },
};
const observation: OpenAiCallObservation = {
  record: (phase, data, status, gaps) => {
    const name: string = phase;
    const fields: Record<string, unknown> = data;
    const outcome: "failed" | "cancelled" | undefined = status;
    const missing: string[] | undefined = gaps;
    void [name, fields, outcome, missing];
  },
  captureWire: () => false,
  startStream: () => streamObservation,
};
const driver = new OpenAiModelDriver(64 * 1024);
const driverStream: AsyncIterable<ModelChunk> = driver.stream(
  "chat_completions",
  request,
  requestEncoding,
  signal,
  observation,
);
const compactionBody: Promise<unknown> = driver.readCompaction(preparedCompaction, signal, observation);
// These checks fail if prepared becomes optional, asynchronous, or incorrectly typed.
declare const withoutPrepared: Omit<typeof requestEncoding, "prepared">;
// @ts-expect-error The synchronous prepared callback is mandatory before any HTTP request.
const missingPrepared: typeof requestEncoding = withoutPrepared;
declare const connection: ReturnType<typeof requestEncoding.prepared>;
// @ts-expect-error Prepared must return a connection synchronously, not a Promise.
const asyncPrepared: typeof requestEncoding.prepared = async () => connection;
// @ts-expect-error Connection timeout must be a number, not a serialized UI value.
const invalidConnection: ReturnType<typeof requestEncoding.prepared> = { ...connection, requestTimeoutMs: "1000" };
// @ts-expect-error Prepared cannot return a connection without the required API key.
const incompletePrepared: typeof requestEncoding.prepared = () => ({
  url: "https://provider.invalid",
  requestTimeoutMs: 1000,
  stepId: "step",
  maxOutputTokens: 64,
});
// @ts-expect-error The public driver selects one of the two implemented wire protocols.
const unsupportedWire: Parameters<typeof driver.stream>[0] = "platform_private_protocol";
// @ts-expect-error Per-call observation is not a host/session container.
const hostObservation: OpenAiCallObservation = { chatId: "chat-from-platform" };
// @ts-expect-error Received protocol bytes must retain their binary representation.
streamObservation.received?.("serialized text", "2026-10-10T00:00:00.000Z");
// @ts-expect-error Successful exhaustion is a boolean, not a domain status string.
streamObservation.finish("completed");
void [
  driverStream,
  compactionBody,
  unsupportedWire,
  hostObservation,
  missingPrepared,
  asyncPrepared,
  invalidConnection,
  incompletePrepared,
];

// Caller-defined model projection is synchronous and cannot replace the full audit source.
const projectionPolicy: ToolResultModelProjector = (result) => ({ answer: result.answer });
const resultViews = projectToolResultViews({ answer: 42 }, { outputTokenLimit: 128 }, projectionPolicy);
const modelProjection: ToolResultProjection = resultViews.model;
const persistedProjection: Record<string, unknown> = persistedModelResult(modelProjection);
// @ts-expect-error Projection callbacks return a record synchronously.
const asynchronousProjection: ToolResultModelProjector = async (result) => result;
// @ts-expect-error Numeric budgets must not accept serialized configuration strings.
projectToolResultViews({ answer: 42 }, { outputTokenLimit: "128" });
void [persistedProjection, asynchronousProjection];

const contextHistory: ModelMessage<ImagePart>[] = [{ role: "user", content: [{ type: "image", url: "local" }] }];
const preparedHistory: ModelMessage<ImagePart>[] = deduplicateReadEvidence(
  contextHistory,
  (name) => name === "read_sample",
);
const receiptHistory: ModelMessage<ImagePart>[] = projectCompletedCodeArguments(preparedHistory, "Saved receipts: ");
const tokens: number = estimateAgentTokens(receiptHistory);
const selectedMaterials = selectAgentContextWithinBudget([{ label: "sample" }], tokens, (item) => item.label.length);
const selectedLabel: string | undefined = selectedMaterials.selected[0]?.label;
// @ts-expect-error The caller must supply its tool policy.
deduplicateReadEvidence(contextHistory);
// @ts-expect-error The caller must supply its receipt explanation.
projectCompletedCodeArguments(contextHistory);
void selectedLabel;

const continuationTranscript: string = compactionTranscript(contextHistory, 1000, (part) => `[image:${part.url}]`);
const summaryBody: Record<string, unknown> = encodeSummaryCompactionRequest(
  true,
  "example",
  "instructions",
  continuationTranscript,
  100,
  {},
);
declare const opaqueCompaction: unknown;
assertNativeCompactionOutput(opaqueCompaction);
const nativeHistory: ModelMessage<ImagePart>[] = nativeCompactionMessages(opaqueCompaction.output);
// @ts-expect-error Historical attachments need a caller-owned renderer.
compactionTranscript(contextHistory, 1000);
declare const unvalidatedOutput: unknown;
// @ts-expect-error Provider input remains unknown until validation establishes records.
nativeCompactionMessages(unvalidatedOutput);
void [summaryBody, nativeHistory];

// The session implementation is independent of platform storage and types.
const memorySession: HarnessSessionStore<"input" | "terminal", "step"> = new MemoryHarnessSessionStore({
  rollout: () => ({ id: "entry", createdAt: "2026-09-30T00:00:00Z" }),
  checkpoint: () => ({ id: "checkpoint", createdAt: "2026-09-30T00:00:00Z", stateDigest: "caller-digest" }),
});
const sessionInput = { chatId: "independent", turnId: "turn", kind: "input" as const, content: { text: "hello" } };
const accepted = memorySession.appendRollout(sessionInput);
const sequence: number = accepted.sequence;
const checkpointInput = {
  chatId: "independent",
  turnId: "turn",
  reason: "step" as const,
  rolloutSequence: sequence,
  state: { phase: "ready" },
};
const savedCheckpoint: SessionCheckpointRecord<"step"> = await memorySession.saveCheckpoint(checkpointInput);
// @ts-expect-error Synchronous append is not a durable-save Promise.
const falseAppendAck: Promise<unknown> = accepted;
// @ts-expect-error Saving a checkpoint must be awaited before using its record.
const falseCheckpointAck: SessionCheckpointRecord<"step"> = memorySession.saveCheckpoint(checkpointInput);
// @ts-expect-error The application narrowed its own event vocabulary.
memorySession.appendRollout({ ...sessionInput, kind: "platform_private_event" });
// @ts-expect-error A caller must supply identity, time and digest generation.
const missingMetadata = new MemoryHarnessSessionStore();
void [savedCheckpoint, falseAppendAck, falseCheckpointAck, missingMetadata];

// Stored application events must be explicitly projected before model reconstruction.
const historyContext: HarnessHistoryEntry = {
  id: "context",
  turnId: "turn",
  kind: "turn.context",
  generation: 1,
  content: {},
};
const historyInput: HarnessHistoryEntry = {
  id: accepted.id,
  turnId: accepted.turnId,
  kind: "input",
  content: { items: ["hello"] },
};
// @ts-expect-error Stored input content is opaque and is not already normalized model history.
const rawInputAsHistory: HarnessHistoryEntry = accepted;
// @ts-expect-error A context boundary must specify its generation.
const contextWithoutGeneration: HarnessHistoryEntry = {
  id: "context",
  turnId: "turn",
  kind: "turn.context",
  content: {},
};
const mismatchedHistory: HarnessHistoryEntry = {
  id: "input",
  turnId: "turn",
  kind: "input",
  // @ts-expect-error Input history requires items, not another event's content.
  content: { summary: "wrong" },
};
const recoveryCall: SessionRecoveryRecord = {
  kind: "tool.call",
  toolCallId: "call",
  content: { batchId: "batch", index: "2" },
};
const resumeRequest: SessionResumeRequest = {
  kind: "approval_batch",
  checkpointId: "checkpoint",
  approvalBatchId: "batch",
};
const resumeCheckpoint: SessionResumeCheckpoint = {
  turnId: "turn",
  reason: "approval",
  stateVersion: 2,
  state: { batchId: "batch" },
};
void [
  historyContext,
  historyInput,
  rawInputAsHistory,
  contextWithoutGeneration,
  mismatchedHistory,
  recoveryCall,
  resumeRequest,
  resumeCheckpoint,
];

// Batch coordination needs only caller-defined item, outcome and event types.
const batchPorts: ToolBatchCoordinatorPorts<{ id: string }, number, { phase: string }> = {
  selectSpecial: () => undefined,
  isParallel: () => true,
  waitsForCompletion: () => false,
  execute: async () => 84,
  executeSpecial: async function* () {
    yield* [];
    return { kind: "continue" };
  },
  acceptOutcome: (_item, result) => {
    const numeric: number = result;
    void numeric;
  },
  progressEvent: (_item, value) => ({ phase: value.phase }),
};
const batch: AsyncGenerator<{ phase: string }, { stopped: boolean }, void> = coordinateToolBatch(
  [{ id: "call" }],
  batchPorts,
);
void batch;

const consumerPressure = estimateContextPressure({
  localMessageEstimate: 800,
  reservedInputTokens: 100,
  maxInputTokens: 1000,
  providerLocalBaseline: 800,
});
declare const consumerCompactionPorts: ContextCompactionPorts<{ type: "text"; text: string }, { kind: string }>;
const consumerCompaction: AsyncGenerator<{ kind: string }, { waiting: boolean; event?: { kind: string } }> =
  coordinateContextCompaction(
    {
      messages: [{ role: "user", content: [{ type: "text", text: "keep" }] }],
      estimatedMessages: consumerPressure.estimatedMessages,
      reservedInputTokens: 100,
      maxInputTokens: 1000,
      finalizing: false,
      remoteCompactionFailed: false,
    },
    consumerCompactionPorts,
  );
void consumerCompaction;

const completionAssessment: CompletionAssessment = { complete: false, missingEvidence: ["validation"] };
const executionWaitPorts: ToolExecutionWaitPorts<{ value: number }, number> = {
  execute: async () => ({ value: 84 }),
  waitForCompletion: () => false,
  timeoutMs: () => 1,
  timeoutResult: () => ({ value: 0 }),
  abortResult: () => ({ value: -1 }),
  lateResult() {},
  selectRetry: () => undefined,
  settle: (result, _timedOut) => result.value,
};
const executionSettlement: Promise<number> = executeToolWithWait(executionWaitPorts, new AbortController().signal);
void completionAssessment;
void executionSettlement;

// The installed loop keeps application-specific input/tool/trace/event types.
declare const runPorts: HarnessRunPorts<ImagePart, Tool, Trace, SamplingEvent>;
const portableRun: AsyncGenerator<SamplingEvent, void, void> = runHarness(runPorts, signal);
type ConsumerStep = HarnessStepPorts<ImagePart, Tool, Trace, SamplingEvent>;
const synchronousAccept: ConsumerStep["acceptProposal"] = (_proposal) => undefined;
// @ts-expect-error History acceptance must finish synchronously before any next stage.
const asynchronousAccept: ConsumerStep["acceptProposal"] = async (_proposal) => {};
declare const withoutStepPreparation: Omit<typeof runPorts, "prepareStep">;
// @ts-expect-error A loop needs caller-bound step material and effect ports.
const missingStepPreparation: typeof runPorts = withoutStepPreparation;
// @ts-expect-error A policy must explicitly choose continue or stop.
const ambiguousAction: HarnessRunDirective = { kind: "finished_maybe" };
void [portableRun, synchronousAccept, asynchronousAccept, missingStepPreparation, ambiguousAction];

// Accepted preparation must carry the exact identities the executor rechecks.
type AcceptedPreparation = Extract<Awaited<ReturnType<typeof toolPorts.prepareExecution>>, { status: "accepted" }>;
const preparedExecution: AcceptedPreparation = {
  status: "accepted",
  input: { value: 42 },
  precondition: { preconditionDigest: "normalized-input-and-schema", worldStateDigest: "executor-state" },
};
// @ts-expect-error Accepted input alone cannot establish execution preconditions.
const withoutExecutionPrecondition: AcceptedPreparation = { status: "accepted", input: { value: 42 } };
// @ts-expect-error Both current input and executor-state identities are required.
const withoutWorldState: AcceptedPreparation["precondition"] = { preconditionDigest: "normalized-input-and-schema" };
void [preparedExecution, withoutExecutionPrecondition, withoutWorldState];

// Consume the actual @ts-check JavaScript adapter, not a lookalike declaration.
const callerMapSession: HarnessSessionStore = new CallerMapSession();
const callerMapCheckpoint: Promise<SessionCheckpointRecord> = callerMapSession.saveCheckpoint({
  chatId: "map-consumer",
  turnId: "turn",
  reason: "example_pause",
  rolloutSequence: 0,
  state: { phase: "waiting" },
});
// @ts-expect-error A caller-owned adapter must provide checkpoint saving as well as history methods.
const incompleteMapAdapter: HarnessSessionStore = {
  appendRollout: callerMapSession.appendRollout,
  listRollout: callerMapSession.listRollout,
  getCheckpoint: callerMapSession.getCheckpoint,
};
void [callerMapCheckpoint, incompleteMapAdapter];

/** Strict consumer fragment; merge into the existing real tarball consumer. */
import {
  type DelegationCompletionState,
  type DelegationDisposition,
  type DelegationToolScope,
  settleDelegation,
} from "@helix/agent-harness";

const delegationState: DelegationCompletionState = {
  cancelled: false,
  waiting: true,
  completed: false,
  hasOutput: true,
};
const delegationScope: DelegationToolScope = { excludedNames: ["delegate"], normalizeName: (name) => name };
const delegationDisposition: DelegationDisposition = settleDelegation(delegationState, () => false);
// @ts-expect-error Cancellation observation is synchronous; it may not defer the decision.
settleDelegation(delegationState, async () => false);
// @ts-expect-error An explicitly cancelled child must indicate whether its event is already reported.
const incompleteCancellation: DelegationDisposition = { kind: "cancelled" };
void [delegationScope, delegationDisposition, incompleteCancellation];

// High-level entrypoint types must also resolve outside the monorepo.
import { createHarness as createStandaloneHarness } from "@helix/agent-harness/standalone";

async function consumeStandalone() {
  const agent = await createStandaloneHarness({
    stream: true,
    reasoning: "auto",
    builtinTools: ["read"],
    mcpServers: [],
  });
  try {
    for await (const event of agent.run("Explain the workspace")) {
      const kind: string = event.kind;
      void kind;
    }
    await agent.callTool("read", { path: "README.md" });
  } finally {
    await agent.close();
  }
}
void consumeStandalone;
// @ts-expect-error unknown builtin names must be rejected
void createStandaloneHarness({ builtinTools: ["imaginary"] });
// @ts-expect-error stream is a boolean option
void createStandaloneHarness({ stream: "true" });
