#!/usr/bin/env bash
# start.sh, 2026-10-13: start source or extracted MCP service; usage: ./start.sh
# Edit service.config.json for runtime settings; src/tools.ts / business.ts for tools.
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_root"
export MCP_CONFIG_FILE="${MCP_CONFIG_FILE:-$project_root/service.config.json}"
if [[ -f server.mjs ]]; then
  exec node server.mjs "$@"
fi
if [[ ! -f node_modules/typescript/bin/tsc || ! -f node_modules/@modelcontextprotocol/sdk/package.json ]]; then
  corepack pnpm@10.23.0 install --frozen-lockfile --ignore-scripts >&2
fi
# Compile editable TypeScript before every source start; only the service prints stdout.
node node_modules/typescript/bin/tsc -p tsconfig.json
exec node lib/server.mjs "$@"
