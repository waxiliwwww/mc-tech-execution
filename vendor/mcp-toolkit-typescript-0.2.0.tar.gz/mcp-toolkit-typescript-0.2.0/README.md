# MCP 工具包 · TypeScript

把 TypeScript 函数、现有可执行程序或普通 HTTP JSON API 接成可独立运行的 MCP 服务。使用官方 `@modelcontextprotocol/sdk` 1.32.1、Streamable HTTP，不依赖 Helix 源码。默认包含 `add`（TypeScript 函数）和 `add_program`（真实外部程序）两个工具，20 + 23 均返回 43。

本目录是工具包源码；`package.sh` 生成只需 Node.js 22 即可运行的独立部署包。已有标准 MCP URL 可直接注册给 Harness，无需再包装；普通业务 API 才使用本文 HTTP 适配方式。

## 1. 启动与找到服务信息

源码运行需要 Node.js 22 和 Corepack/pnpm：

```bash
cd /home/zhangbolun/services/mcp-toolkit/typescript
./start.sh
```

`start.sh` 首次补齐锁定依赖，每次先编译 TypeScript，再运行服务。可在任意目录调用该脚本；它会切换到本包目录。运行配置统一放在 `service.config.json`，默认内容：

```json
{"host":"127.0.0.1","port":8765,"path":"/mcp"}
```

正常启动只显示三行：服务名称及鉴权状态、地址及工具名、JSONL 日志路径。成功或失败调用均在同一行显示工具名、状态和调用参数；参数同时写入 JSONL。每 5 分钟只输出本地时间和运行时长，不额外显示“心跳”字样。Ctrl+C 停止。日志失败只告警，不改变工具计算结果。

默认启动后在本包目录写 `connection.json`，供客户端读取；用 `MCP_CONNECTION_FILE` 指定其他路径。该文件记录连接信息，不代表服务仍在线。真实可用性及工具发现以 MCP 初始化和 `tools/list` 为准。

```bash
curl http://127.0.0.1:8765/health
curl http://127.0.0.1:8765/info
```

`/info` 返回 `schemaVersion`、服务名/版本、MCP URL、鉴权模式、连接配置以及工具的描述、输入/输出 JSON Schema 和 annotations。它是供人和集成读取的说明接口；工具发现仍以官方 MCP `tools/list` 为准。两者由同一工具注册表生成，测试对照其 schema。

可选配置项：`name`（MCP 服务名）、`version`（MCP 服务版本）、`clientName`（客户端连接名称，默认 `calculator`）、`publicUrl`（客户端实际可访问的完整 MCP URL）。省略名称/版本时使用 `package.json` 的 `mcp-toolkit-typescript` / `0.2.0`。

环境覆盖：`MCP_CONFIG_FILE`、`MCP_HOST`、`MCP_PORT`、`MCP_PATH`、`MCP_PUBLIC_URL`。其中 path 是服务实际监听路径，publicUrl 可以是反向代理映射后的客户端路径。`/health` 和 `/info` 是保留路径。修改配置后重启；部署包中改配置无需重新打包。

## 2. 只改哪些文件

| 目的 | 修改位置 |
| --- | --- |
| 改业务函数 | `src/business.ts` |
| 改工具名、说明、参数、输出和调用函数 | `src/tools.ts` |
| 接原始程序 | 把程序放到 `programs/`，在 `src/tools.ts` 调用 `runJsonProgram` |
| 接普通 HTTP JSON API | 在 `src/tools.ts` 调用 `postJson`，凭据用环境变量 |
| 改服务名、连接名、监听地址、端口、路径 | `service.config.json` |
| 更换鉴权机制 | `src/auth.mjs`，同时覆盖 `/info` 和 MCP |

无需逐工具修改 `src/server.mjs`。`defineTool` 是一个保留 TypeScript 参数/输出类型推导的小函数，协议、schema 验证和 HTTP MCP 处理仍由官方 SDK 完成。源码编译产物在 `lib/`，不要手工改编译文件。

### 直接调用 TypeScript 函数

```ts
// src/business.ts
export function multiply(a: number, b: number): number {
  return a * b;
}
```

在 `src/tools.ts` 导入函数，并向 `tools` 数组新增定义：

```ts
defineTool({
  name: 'multiply', description: '计算两个数的乘积。',
  inputSchema: { a: z.number(), b: z.number() },
  outputSchema: { product: z.number() },
  annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  execute: async ({ a, b }) => ({ product: multiply(a, b) }),
})
```

注解要按实际业务填写：写文件、提交计算或修改远程资源时，不要沿用加法工具的只读注解。服务端和 SDK 检查输入、输出，不把错误输出包装为成功。添加不同参数/结果的定义仍使用同一注册表；不要在通用 server 中追加分支。

### 接入可调用程序

默认 `add_program` 实际启动随包 `programs/add.mjs`：MCP 参数转成一份 JSON 写入程序 stdin；程序向 stdout 输出一份 JSON；执行日志可写 stderr。程序退出非零、输出非 JSON、超过上限或超时会返回工具错误。

```ts
execute: async input => z.object(outputSchema).parse(await runJsonProgram({
  command: process.execPath,
  args: [resolve('programs/add.mjs')],
  timeoutMs: 5_000,
  maxOutputBytes: 1_048_576,
}, input))
```

替换为 Python 脚本时使用 `command: 'python3'` 和独立的参数数组；二进制程序同理。命令由开发者固定配置，不让模型传入任意命令；使用 `execFile`、`shell:false`，shell 字符不会执行。默认超时 30 秒、stdout/stderr 各 1 MiB 上限；超时终止直接子进程。该适配器不管理子进程树或 HPC 作业，长计算应由业务接口返回任务标识并提供查询/取消，不能当成后台调度服务。

独立包会包含 `programs/` 内文件，但不自动安装其 Python 包、系统程序、核数据或其他依赖。自带程序先能独立运行，再接 MCP。stdout 必须只输出结果 JSON；示例错误不会回传 stderr 内容，以免外部程序打印的凭据进入响应。业务出错需在业务自身可控日志中排查。

### 接入普通 HTTP JSON API

`src/adapters.ts` 提供 `postJson`，在工具定义中固定 URL、输入输出 schema、超时和凭据环境变量：

```ts
import { postJson } from './adapters.js';
// execute 中：
const data = await postJson({
  url: 'https://your-api.example/add',
  bearerTokenEnv: 'BUSINESS_API_TOKEN',
  timeoutMs: 5_000,
  maxOutputBytes: 1_048_576,
}, input);
return z.object(outputSchema).parse(data);
```

这是普通 JSON POST 适配，不是 MCP 代理。URL 由开发者选定，不作为模型输入参数；设置凭据环境变量后再启动。HTTP 非 2xx、超时、非 JSON、超限及 schema 不匹配应作为工具错误；不自动重试或跟随重定向，避免重复业务操作或转发凭据到其他地址。适配器默认只接受 JSON 对象结果，返回数组的业务可在业务接口或自定义适配函数中明确转换。

## 3. 部署到另一台服务器

编辑 `service.config.json`，例如：

```json
{
  "host": "0.0.0.0",
  "port": 8765,
  "path": "/mcp",
  "publicUrl": "https://tools.example.com/mcp",
  "name": "my-business-tools",
  "version": "1.0.0",
  "clientName": "business"
}
```

通过服务器环境提供 `MCP_AUTH_TOKEN`，再启动。非本机监听（`0.0.0.0`、`::` 或局域网 IP）要求显式 publicUrl 和非空 token；服务拒绝把通配地址或带凭据的 URL 写进连接信息。`publicUrl` 是客户端可访问地址，必须真实配置 DNS/网络/反向代理；填写该项不会自动建立这些设施。

`/info` 与所有 MCP 请求使用同一 Bearer 鉴权；`/health` 公开但仍受 Host 校验。HTTPS 由现有反向代理终止，本进程保持 HTTP；代理转发 MCP 与 `/info` 路径，并保留 Authorization 及合适的 Host。公网接入使用 HTTPS；此工具包不配置系统代理、开放防火墙或提供账户管理/OAuth。

启用鉴权后的 `connection.json` 形如：

```json
[{
  "name": "business",
  "transport": "streamable-http",
  "url": "https://tools.example.com/mcp",
  "headers": {"Authorization": "Bearer ${MCP_AUTH_TOKEN}"}
}]
```

占位符不是密钥。把配置给 Harness 后，由客户端环境设置同名变量，Harness 现有配置展开机制再发送请求。真实 token 不进入 `/info`、连接文件、结构化日志或发布包。服务端当前是共享 Bearer token，不是用户级权限系统。

第三方给出的地址若已是标准 Streamable HTTP MCP，只需把其 URL 和对方要求的鉴权头放入 Harness 连接配置，直接调用其 `tools/list`；无需将它重新包装到本服务中。

## 4. 验证与独立打包

```bash
corepack pnpm install --frozen-lockfile --ignore-scripts
corepack pnpm test
corepack pnpm test:package
./package.sh
```

测试包含实际 MCP 初始化/发现/调用、参数和输出错误、外部程序与 HTTP API 适配、超时和输出限制、配置/鉴权、默认连接文件、三行输出、心跳、日志故障与停止清理。心跳测试观察真实 300000ms 配置后用测试专用定时器加速，不声称已等待 5 分钟或完成 72 小时稳定性测试。测试使用本地假 API 与程序，不调用付费模型。

工具包旁存在 `../harness` 时会同时验证 Harness 直连和注册表；也可指定 `HARNESS_TERMINAL_DIR=/path/to/harness`。没有该目录时只跳过 Harness 专项，SDK/HTTP 服务测试仍执行。Harness 测试仅运行 `/tools` 与 `/call`，不调用模型。

`test:package` 会构建、解压到临时目录，校验哈希并验证独立包实际运行；如有 Harness，还验证 Bearer 占位符连接和真实程序调用。

产物：`dist/mcp-toolkit-typescript-0.2.0.tar.gz`，另有归档 SHA256。解压后：

```bash
tar -xzf mcp-toolkit-typescript-0.2.0.tar.gz
cd mcp-toolkit-typescript-0.2.0
sha256sum -c SHA256SUMS
./start.sh
```

部署包包含已打包的 server、启动脚本、可编辑配置、业务程序、本文、`BUILD.json`（版本、构建时间、依赖与源码哈希）和 `SHA256SUMS`。Node.js 22 之外无需 pnpm、TypeScript 编译器或源码仓库即可启动；外部业务程序自己的运行依赖仍需提供。修改 TypeScript 工具定义后在源码目录重新测试、打包；部署包可直接改服务配置和随包业务程序后重启，但这些修改会使原始文件哈希校验不再通过。

本包验证接口集成，不包含蒙卡软件、模型、核数据、HPC 或专业正确性证据。收到真实业务脚本后需替换示例，再用专业样例完成业务联调。
