#!/usr/bin/env node
// Example business program. Input: one JSON object on stdin. Output: one JSON object.
let text = '';
for await (const chunk of process.stdin) text += chunk;
try {
  const { a, b } = JSON.parse(text);
  if (![a, b].every(value => typeof value === 'number' && Number.isFinite(value))) throw new Error('a and b must be finite numbers.');
  const sum = a + b;
  if (!Number.isFinite(sum)) throw new Error('The sum is outside the finite number range.');
  process.stdout.write(JSON.stringify({ sum }) + '\n');
} catch (error) {
  process.stderr.write(error.message + '\n');
  process.exitCode = 1;
}
