# 纯净 Harness：按注册表连接 MCP

先启动 MCP 服务，再运行 `./run.sh`。脚本默认读取本目录的 `mcp-servers.json`，实际连接每个服务并发现工具，全部成功后进入终端聊天。聊天中直接输入自然语言，不再填写 MCP 参数。

## 修改 MCP 注册表

默认文件：`mcp-servers.json`。

```json
[
  {
    "name": "calculator",
    "transport": "streamable-http",
    "url": "http://127.0.0.1:8765/mcp"
  }
]
```

服务改端口后，在这里同步改 `url`。接入新的服务就在数组里增加一个条目；服务可在其他节点，只需填写本机能访问的 HTTP/HTTPS MCP 地址，不需要访问服务端文件。`name` 用于区分不同连接，工具在 agent 中的名称为 `连接名__原始工具名`。

默认省略 `tools`，让 Harness 自动发现服务的全部工具及参数定义。只有希望限制工具时才添加，例如 `"tools": ["add"]`。注册表填 `[]` 表示不接 MCP。

## 启动与聊天

需要 Node.js 22。本目录的 `terminal.mjs` 已包含运行依赖，无需安装。

```bash
cd "$HOME/services/helix-harness"
./run.sh
```

启动先进行 MCP 初始化和工具发现；这就是连通性校验，不额外重复请求一遍。全部连接成功后，只显示一行模型、工具数量与输出模式，以及本次事件日志位置。无效或缺失的注册表、任一服务连接失败都会停止启动并返回非零退出码，修正配置或启动服务后重新运行。

```text
正在初始化…
Harness · deepseek-v4.1-flash · MCP 工具 1 · 流式 · /help
事件日志：/home/zhangbolun/services/helix-harness/logs/<本次会话>.jsonl

你>
```

出现 `你>` 后输入：

```text
请用加法工具帮我算一下 20 加 23
```

agent 根据工具说明选择工具、生成参数，拿到回执后回答。用户输入、推理、回答和工具回执之间留一个空行；同一个 Chat Completions 流包同时含推理和正文时，先显示推理，再显示正文。默认关闭 read、bash、edit、write 四个基础工具，只接入注册表中的 MCP；每次进程新建会话，无需 Helix Server、数据库或 Workflow。

模型地址、模型名和密钥沿用当前 shell 的 `HARNESS_MODEL_URL`、`HARNESS_MODEL`、`HARNESS_MODEL_API_KEY`。模型配置缺少时仍在启动阶段补填；MCP 参数始终来自注册表或显式覆盖，不弹出 MCP 设置问答。

## 配置覆盖与排错

日常只编辑 `mcp-servers.json`。已有显式配置仍可覆盖默认注册表，优先级为 `HARNESS_MCP_SERVERS`、`MCP_CONNECTION_FILE`、`MCP_URL`、包内注册表。`MCP_CONNECTION_FILE` 读取同样格式的 JSON 数组；`MCP_URL` 以 `calculator` 为连接名自动发现服务全部工具。

不需要模型的连接检查：

```bash
./run.sh --prompt '/tools'
```

`/call 名称 {JSON}` 仅用于直接测试回执；日常使用自然语言。`/tool 名称` 查看 schema，`/clear` 清空会话，`/logs` 查看本次日志，`/exit` 退出。配置改变后重新启动。

`logs/*.jsonl` 保留实际工具参数、回执和模型事件；配置凭据会脱敏。`--cwd` 是工作目录，不是文件权限沙箱；显式 `--tools` 可以改变基础工具选择。其他参数见 `./run.sh --help`。

## 包来源

本目录复用 `$HOME/projects/helix-analysis/mywork/helix-agent/harness-terminal` 的已构建 `terminal.mjs` 与原始 tarball，底层为 `@helix/agent-harness/standalone`。终端展示在参考目录源码中修改并重建后同步到这里；核心包来自 `refactor/harness-extraction` 分支。`SOURCE.json` 记录来源与复制哈希，`BUILD.json` 如实保留原构建的 dirty 状态；此目录的脚本与注册表负责 MCP 启动配置。

## 独立交付与其他 MCP 服务

Harness 和 MCP 工具包是两个独立产品；本目录不读取 MCP 服务的源码、部署路径或配置文件。可以直接在注册表填写第三方标准 MCP 地址，通过协议发现与调用；MCP 服务也可被其他兼容宿主使用。连接名只是本客户端的命名空间，不是工具端必须使用的部署目录名。

执行 `./package.sh` 生成 `dist/helix-harness-minimal-0.1.0.tar.gz`。包内默认注册表为空，避免把当前环境的地址、凭据或服务选择带给接收者；接收者根据 `mcp-servers.example.json` 配置自己的连接。解压后需要 Node.js 22，无须其他工作目录、MCP工具包源码、pnpm或Helix服务。可以先运行 `./run.sh --prompt /tools` 检查工具发现，再配置模型进行自然语言调用。远程服务鉴权头可写 `"Authorization":"Bearer ${REMOTE_MCP_TOKEN}"`，在客户端环境中提供该变量。

`vendor/` 中固定纯净核心可供程序集成，`terminal.mjs` 是终端入口。这不是已部署的多用户Web聊天服务；合同项目的人工确认、自动备用等扩展在MC项目自己的入口中实现。源码来源信息中的路径仅用于追溯，不是运行依赖。
