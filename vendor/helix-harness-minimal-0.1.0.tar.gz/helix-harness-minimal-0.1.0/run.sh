#!/usr/bin/env bash
# run.sh, 2026-10-12: load the MCP registry and start a fresh Harness; usage: ./run.sh
set -euo pipefail
harness_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -v HARNESS_MCP_SERVERS ]]; then
  if [[ -v MCP_CONNECTION_FILE ]]; then
    HARNESS_MCP_SERVERS="$(cat -- "$MCP_CONNECTION_FILE")"
    export HARNESS_MCP_SERVERS
  elif [[ -v MCP_URL ]]; then
    HARNESS_MCP_SERVERS="$(node --input-type=module -e '
      const url = new URL(process.env.MCP_URL);
      if (!["http:", "https:"].includes(url.protocol)) throw new Error("MCP_URL must use HTTP or HTTPS.");
      console.log(JSON.stringify([{ name: "calculator", transport: "streamable-http", url: url.href }]));
    ')"
    export HARNESS_MCP_SERVERS
  else
    registry_file="$harness_root/mcp-servers.json"
    HARNESS_MCP_SERVERS="$(cat -- "$registry_file")"
    export HARNESS_MCP_SERVERS
  fi
fi
exec node "$harness_root/terminal.mjs" --cwd "$harness_root" --tools none "$@"
