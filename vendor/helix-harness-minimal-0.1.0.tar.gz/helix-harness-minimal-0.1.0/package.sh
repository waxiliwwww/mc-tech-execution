#!/usr/bin/env bash
# Package the independent Harness, 2026-10-13. ./package.sh does not read MCP server files.
set -euo pipefail
harness_package_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 - "$harness_package_root" <<'PY'
from pathlib import Path
import hashlib, json, shutil, sys, tarfile, tempfile
root=Path(sys.argv[1]); output=root/'dist'; output.mkdir(exist_ok=True)
name='helix-harness-minimal-0.1.0'
with tempfile.TemporaryDirectory(prefix='harness-package-') as temporary:
    stage=Path(temporary)/name; stage.mkdir()
    for f in ['run.sh','terminal.mjs','README.md','BUILD.json','SOURCE.json','package.json','package.sh']:
        shutil.copy2(root/f,stage/f)
    shutil.copytree(root/'vendor',stage/'vendor')
    # Runtime registries may contain user endpoints or secrets. A distributable starts unconfigured.
    (stage/'mcp-servers.json').write_text('[]\n')
    (stage/'mcp-servers.example.json').write_text(json.dumps([{'name':'remote','transport':'streamable-http','url':'https://tools.example.org/mcp','headers':{'Authorization':'Bearer ${REMOTE_MCP_TOKEN}'}}],indent=2)+'\n')
    files=sorted(p for p in stage.rglob('*') if p.is_file())
    (stage/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(stage)}\n' for p in files))
    archive=output/(name+'.tar.gz')
    with tarfile.open(archive,'w:gz') as tar: tar.add(stage,arcname=name)
    (output/(name+'.tar.gz.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
    print(archive)
PY
