#!/usr/bin/env bash
# package.sh, 2026-10-13: bundle an independent MCP package; usage: ./package.sh
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_root"

node --input-type=module <<'NODE'
import { readFileSync } from 'node:fs';
const manifest = JSON.parse(readFileSync('package.json', 'utf8'));
if (!/^[a-z0-9][a-z0-9._-]*$/.test(manifest.name ?? '')) {
  throw new Error('package.json name must be an unscoped, safe package name.');
}
if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z]+(?:[.-][0-9A-Za-z]+)*)?(?:\+[0-9A-Za-z]+(?:[.-][0-9A-Za-z]+)*)?$/.test(manifest.version ?? '')) {
  throw new Error('package.json version must be a safe semantic version.');
}
NODE
# Reconcile the lockfile on every build so updated dependency versions are included.
corepack pnpm@10.23.0 install --frozen-lockfile --ignore-scripts
corepack pnpm@10.23.0 build

node --input-type=module <<'NODE'
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { chmodSync, copyFileSync, existsSync, lstatSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { isAbsolute, relative, resolve, sep } from 'node:path';

const root = process.cwd();
const manifest = JSON.parse(readFileSync('package.json', 'utf8'));
const artifact = `${manifest.name}-${manifest.version}`;
const output = resolve('dist', artifact);
mkdirSync(output, { recursive: true });

const result = await build({
  absWorkingDir: root,
  entryPoints: ['lib/server.mjs'],
  outfile: resolve(output, 'server.mjs'),
  bundle: true,
  platform: 'node',
  target: 'node22',
  format: 'esm',
  legalComments: 'eof',
  metafile: true,
  banner: {
    js: 'import { createRequire as __bundleCreateRequire } from "node:module"; const require = __bundleCreateRequire(import.meta.url);'
  }
});

copyFileSync('start.sh', resolve(output, 'start.sh'));
copyFileSync('service.config.json', resolve(output, 'service.config.json'));
chmodSync(resolve(output, 'start.sh'), 0o755);
const packagedFiles = ['server.mjs', 'start.sh', 'service.config.json', 'BUILD.json'];
const inputs = new Set(['package.json', 'pnpm-lock.yaml', 'package.sh', 'start.sh', 'service.config.json', 'tsconfig.json']);
function walk(directory) {
  return readdirSync(directory).sort().flatMap(name => {
    const path = `${directory}/${name}`;
    const stat = lstatSync(path);
    if (stat.isSymbolicLink()) throw new Error(`Package assets must not contain symlinks: ${path}`);
    return stat.isDirectory() ? walk(path) : [path];
  });
}
for (const file of walk('src')) inputs.add(file);
for (const file of walk('programs')) {
  mkdirSync(resolve(output, file, '..'), { recursive: true });
  copyFileSync(file, resolve(output, file));
  chmodSync(resolve(output, file), lstatSync(file).mode & 0o777);
  inputs.add(file);
  packagedFiles.push(file);
}
if (existsSync('README.md')) {
  copyFileSync('README.md', resolve(output, 'README.md'));
  packagedFiles.push('README.md');
  inputs.add('README.md');
}

for (const input of Object.keys(result.metafile.inputs)) {
  const path = relative(root, resolve(root, input));
  if (path.split(sep).includes('node_modules')) continue;
  if (isAbsolute(path) || path === '..' || path.startsWith(`..${sep}`)) {
    throw new Error('Non-dependency build inputs must stay within the project directory.');
  }
  inputs.add(path.split(sep).join('/'));
}

const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const dependencies = Object.fromEntries(
  Object.keys({ ...manifest.dependencies, ...manifest.devDependencies }).sort().map(name => [
    name,
    JSON.parse(readFileSync(resolve('node_modules', name, 'package.json'), 'utf8')).version
  ])
);
const buildInputs = Object.fromEntries([...inputs].sort().map(path => [path, sha256(path)]));
writeFileSync(resolve(output, 'BUILD.json'), JSON.stringify({
  schemaVersion: 1,
  name: manifest.name,
  version: manifest.version,
  builtAt: new Date().toISOString(),
  node: process.version,
  dependencies,
  buildInputs,
  bundleSha256: sha256(resolve(output, 'server.mjs'))
}, null, 2) + '\n');

writeFileSync(resolve(output, 'SHA256SUMS'), packagedFiles.sort().map(file => `${sha256(resolve(output, file))}  ${file}`).join('\n') + '\n');
packagedFiles.push('SHA256SUMS');
const archive = resolve('dist', `${artifact}.tar.gz`);
execFileSync('tar', [
  '-czf', archive, '-C', resolve('dist'),
  ...packagedFiles.map(file => `${artifact}/${file}`)
]);
writeFileSync(`${archive}.sha256`, `${sha256(archive)}  ${artifact}.tar.gz\n`);
console.log(`Package: ${archive}`);
console.log('Extract and start (Node.js 22 is required):');
console.log(`tar -xzf "${archive}"\ncd "${artifact}"\n./start.sh`);
NODE
