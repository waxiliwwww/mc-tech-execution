import assert from 'node:assert/strict';
import { once } from 'node:events';
import { execFile } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { promisify } from 'node:util';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { createApp, loadServerConfig } from '../lib/server.mjs';
import { tools } from '../lib/tools.js';

const identityDefaults = { name: 'mcp-toolkit-typescript', version: '0.2.0', clientName: 'calculator', authentication: { implemented: false, type: 'none' } };
const fixtureConfig = { host: '127.0.0.1', port: 8765, path: '/mcp' };
const execFileAsync = promisify(execFile);

async function temporaryConfig(t, text) {
  const directory = await mkdtemp(join(tmpdir(), 'mcp-service-config-test-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const configFile = join(directory, 'service.config.json');
  if (text !== undefined) await writeFile(configFile, text);
  return { directory, configFile };
}

async function withServer(app, run) {
  const server = createServer(app);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  try {
    return await run(baseUrl);
  } finally {
    await new Promise((resolve, reject) => {
      server.close(error => error ? reject(error) : resolve());
      server.closeAllConnections();
    });
  }
}

async function withClient(url, run, headers = {}) {
  const client = new Client({ name: 'mcp-deployment-config-test', version: '0.1.0' });
  try {
    await client.connect(new StreamableHTTPClientTransport(new URL(url), {
      requestInit: { headers },
    }));
    return await run(client);
  } finally {
    await client.close();
  }
}

test('deployment configuration defaults to the local MCP endpoint', () => {
  assert.deepEqual(loadServerConfig({}, fixtureConfig), { ...identityDefaults, ...identityDefaults,
    host: '127.0.0.1',
    port: 8765,
    mcpPath: '/mcp',
    url: 'http://127.0.0.1:8765/mcp',
  });
});

test('local deployment hosts and decimal port boundaries produce valid URLs', () => {
  for (const [host, port, authority] of [
    ['127.0.0.1', '1', '127.0.0.1:1'],
    ['localhost', '65535', 'localhost:65535'],
    ['::1', '9001', '[::1]:9001'],
  ]) {
    assert.deepEqual(loadServerConfig({ MCP_HOST: host, MCP_PORT: port, MCP_PATH: '/v1/mcp_tools' }, fixtureConfig), { ...identityDefaults,
      host,
      port: Number(port),
      mcpPath: '/v1/mcp_tools',
      url: `http://${authority}/v1/mcp_tools`,
    });
  }
});

test('deployment configuration rejects nonlocal hosts and malformed ports', () => {
  for (const host of ['', '0.0.0.0', '::', '192.168.1.10', 'example.com', '[::1]', 'localhost ']) {
    assert.throws(() => loadServerConfig({ MCP_HOST: host }, fixtureConfig), Error, `Host must be rejected: ${host}`);
  }
  for (const port of ['', '0', '65536', '-1', '+80', '1.5', '1e3', '0x50', ' 80', '80 ', 'NaN', 'Infinity']) {
    assert.throws(() => loadServerConfig({ MCP_PORT: port }, fixtureConfig), Error, `Port must be rejected: ${port}`);
  }
  for (const port of [[8765], { value: 8765 }, true, null]) {
    assert.throws(() => loadServerConfig({}, { ...fixtureConfig, port }), Error);
  }
});

test('MCP paths accept literal segments and reject ambiguous or reserved routes', () => {
  for (const mcpPath of ['/mcp', '/v1/tools', '/agent_tools/add-v1.json', '/.well-known/mcp']) {
    assert.equal(loadServerConfig({ MCP_PATH: mcpPath }, fixtureConfig).mcpPath, mcpPath);
  }
  for (const mcpPath of [
    '', '/', 'mcp', '//mcp', '/a//b', '/mcp/', '/.', '/..', '/a/./b', '/a/../b',
    '/mcp?token=x', '/mcp#section', '/mcp*', '/mcp/:id', '/mcp/(test)', '/mcp[1]',
    '/mcp+', '/mcp%2Ffoo', '/mcp foo', '/health', '/HEALTH', '/info', '/INFO',
  ]) {
    assert.throws(() => loadServerConfig({ MCP_PATH: mcpPath }, fixtureConfig), Error, `Path must be rejected: ${mcpPath}`);
  }
});

test('an editable configuration file is read again after its port and path change', async t => {
  const { configFile } = await temporaryConfig(t, JSON.stringify(fixtureConfig));
  const env = { MCP_CONFIG_FILE: configFile };
  assert.deepEqual(loadServerConfig(env), { ...identityDefaults,
    host: '127.0.0.1', port: 8765, mcpPath: '/mcp', url: 'http://127.0.0.1:8765/mcp',
  });
  await writeFile(configFile, JSON.stringify({ host: '127.0.0.1', port: 9002, path: '/api/v2/mcp' }));
  assert.deepEqual(loadServerConfig(env), { ...identityDefaults,
    host: '127.0.0.1', port: 9002, mcpPath: '/api/v2/mcp', url: 'http://127.0.0.1:9002/api/v2/mcp',
  });
});

test('the working directory service.config.json supplies the default deployment configuration', async t => {
  const { directory } = await temporaryConfig(t, JSON.stringify({ host: 'localhost', port: 9003, path: '/cwd/mcp' }));
  const moduleUrl = new URL('../lib/server.mjs', import.meta.url).href;
  const program = `import { loadServerConfig } from ${JSON.stringify(moduleUrl)}; console.log(JSON.stringify(loadServerConfig({})));`;
  const { stdout } = await execFileAsync(process.execPath, ['--input-type=module', '-e', program], { cwd: directory });
  assert.deepEqual(JSON.parse(stdout), { ...identityDefaults,
    host: 'localhost', port: 9003, mcpPath: '/cwd/mcp', url: 'http://localhost:9003/cwd/mcp',
  });
});

test('missing files, invalid JSON, nonobjects and missing required config fields are rejected', async t => {
  const { configFile } = await temporaryConfig(t);
  assert.throws(() => loadServerConfig({ MCP_CONFIG_FILE: configFile }), Error);
  for (const text of [
    '{', 'null', '[]', '42', 'true', '"config"', '{}',
    JSON.stringify({ port: 8765, path: '/mcp' }),
    JSON.stringify({ host: '127.0.0.1', path: '/mcp' }),
    JSON.stringify({ host: '127.0.0.1', port: 8765 }),
  ]) {
    await writeFile(configFile, text);
    assert.throws(() => loadServerConfig({ MCP_CONFIG_FILE: configFile }), Error, `Invalid config must be rejected: ${text}`);
  }
});

test('explicit environment parameters override file values and injected defaults avoid file reads', async t => {
  const { configFile } = await temporaryConfig(t, JSON.stringify({ host: 'localhost', port: 9004, path: '/from/file' }));
  assert.deepEqual(loadServerConfig({
    MCP_CONFIG_FILE: configFile, MCP_HOST: '::1', MCP_PORT: '9005', MCP_PATH: '/from/env',
  }), { ...identityDefaults,
    host: '::1', port: 9005, mcpPath: '/from/env', url: 'http://[::1]:9005/from/env',
  });
  assert.deepEqual(loadServerConfig({ MCP_CONFIG_FILE: configFile, MCP_PORT: '9006' }), { ...identityDefaults,
    host: 'localhost', port: 9006, mcpPath: '/from/file', url: 'http://localhost:9006/from/file',
  });
  assert.deepEqual(loadServerConfig({ MCP_CONFIG_FILE: join(configFile, 'missing'), MCP_PORT: '9007' }, fixtureConfig), { ...identityDefaults,
    host: '127.0.0.1', port: 9007, mcpPath: '/mcp', url: 'http://127.0.0.1:9007/mcp',
  });
});

test('a configured literal MCP path supports real initialization, discovery and addition', async () => {
  const config = loadServerConfig({ MCP_PATH: '/api.v1/mcp-tools' }, fixtureConfig);
  await withServer(createApp({ config }), async baseUrl => {
    await withClient(`${baseUrl}${config.mcpPath}`, async client => {
      const listing = await client.listTools();
      assert.deepEqual(listing.tools.map(tool => tool.name), ['add', 'add_program']);
      const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
      assert.notEqual(result.isError, true);
      assert.deepEqual(result.structuredContent, { sum: 43 });
    });
    for (const path of ['/mcp', '/apiXv1/mcp-tools']) {
      const response = await fetch(`${baseUrl}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/list' }),
      });
      assert.equal(response.status, 404);
      await response.text();
    }
  });
});

test('an injected authentication hook blocks all MCP methods before business execution and leaves health public', async () => {
  const config = loadServerConfig({ MCP_PATH: '/private/mcp' }, fixtureConfig);
  const rejectedMethods = [];
  let executions = 0;
  const originalExecute = tools[0].execute;
  tools[0].execute = async args => {
    executions += 1;
    return await originalExecute(args);
  };
  const authenticate = (req, res, _next) => {
    rejectedMethods.push(req.method);
    res.status(401).json({ error: 'authentication hook rejected the request' });
  };
  try {
    await withServer(createApp({ config, authenticate }), async baseUrl => {
      for (const method of ['POST', 'GET', 'DELETE']) {
        const response = await fetch(`${baseUrl}${config.mcpPath}`, {
          method,
          ...(method === 'POST' ? {
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0', id: 1, method: 'tools/call',
              params: { name: 'add', arguments: { a: 20, b: 23 } },
            }),
          } : {}),
        });
        assert.equal(response.status, 401, `${method} must pass through the hook`);
        assert.deepEqual(await response.json(), { error: 'authentication hook rejected the request' });
      }
      const info = await fetch(`${baseUrl}/info`);
      assert.equal(info.status, 401);
      await info.text();
      const health = await fetch(`${baseUrl}/health`);
      assert.equal(health.status, 200);
      assert.equal((await health.json()).status, 'ok');
      assert.deepEqual(rejectedMethods, ['POST', 'GET', 'DELETE', 'GET']);
      assert.equal(executions, 0);
    });
  } finally {
    tools[0].execute = originalExecute;
  }
});

test('the default authentication placeholder accepts both absent and arbitrary Bearer headers without token validation', async () => {
  const config = loadServerConfig({ MCP_PATH: '/placeholder/mcp' }, fixtureConfig);
  await withServer(createApp({ config }), async baseUrl => {
    // This header is a public fixture. Acceptance confirms the hook is still a placeholder.
    for (const headers of [{}, { Authorization: 'Bearer placeholder-test-only' }]) {
      await withClient(`${baseUrl}${config.mcpPath}`, async client => {
        const listing = await client.listTools();
        assert.deepEqual(listing.tools.map(tool => tool.name), ['add', 'add_program']);
        const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
        assert.notEqual(result.isError, true);
        assert.deepEqual(result.structuredContent, { sum: 43 });
      }, headers);
    }
  });
});
