import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { once } from 'node:events';
import { copyFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, test as nodeTest } from 'node:test';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import { promisify } from 'node:util';
import { createApp, loadServerConfig } from '../lib/server.mjs';

const execFileAsync = promisify(execFile);
const harnessDirectory = process.env.HARNESS_TERMINAL_DIR ?? fileURLToPath(new URL('../../harness/', import.meta.url));
const harnessSource = existsSync(join(harnessDirectory, 'run.sh')) ? harnessDirectory : null;
const test = (name, fn) => nodeTest(name, { skip: !harnessSource }, fn);
let fixtureRoot, httpServer, url;

before(async () => {
  fixtureRoot = await mkdtemp(join(tmpdir(), 'harness-registry-'));
  const config = loadServerConfig({}, { host: '127.0.0.1', port: 8765, path: '/mcp' });
  httpServer = createServer(createApp({ config }));
  httpServer.listen(0, '127.0.0.1');
  await once(httpServer, 'listening');
  url = `http://127.0.0.1:${httpServer.address().port}/mcp`;
});

after(async () => {
  if (httpServer?.listening) await new Promise((resolve, reject) => {
    httpServer.close(error => error ? reject(error) : resolve());
    httpServer.closeAllConnections();
  });
  if (fixtureRoot) await rm(fixtureRoot, { recursive: true, force: true });
});

function registry(name = 'calculator', endpoint = url) {
  return [{ name, transport: 'streamable-http', url: endpoint }];
}

async function fixture(name, servers = registry()) {
  const root = join(fixtureRoot, name);
  await mkdir(root);
  await Promise.all(['run.sh', 'terminal.mjs'].map(file =>
    copyFile(join(harnessSource, file), join(root, file))));
  if (servers !== null) await writeFile(join(root, 'mcp-servers.json'),
    typeof servers === 'string' ? servers : JSON.stringify(servers));
  return root;
}

function isolatedEnvironment(overrides = {}) {
  const env = {};
  for (const key of Object.keys(process.env)) {
    if (!key.startsWith('HARNESS_') && !key.startsWith('MCP_')) env[key] = process.env[key];
  }
  return { ...env, ...overrides };
}

function runHarness(root, prompt = '/tools', overrides = {}) {
  return execFileAsync('bash', [join(root, 'run.sh'), '--prompt', prompt], {
    env: isolatedEnvironment(overrides), timeout: 15000,
  });
}

async function events(stdout) {
  const logPath = /事件日志：([^\n]+)/.exec(stdout)?.[1];
  assert.ok(logPath);
  return (await readFile(logPath, 'utf8')).trim().split('\n').map(JSON.parse);
}

function assertNoChat(output) {
  assert.doesNotMatch(output, /你> |添加 MCP（|MCP HTTP URL>/);
}

test('the package registry loads a real MCP tool and its call returns 43 without setup prompts', async () => {
  const root = await fixture('success');
  const listing = await runHarness(root);
  assert.match(listing.stdout, /MCP 工具 2/);
  assert.match(listing.stdout, /calculator__add —/);
  assertNoChat(listing.stdout);
  const listedEvents = await events(listing.stdout);
  const session = listedEvents.find(event => event.kind === 'session.started');
  assert.equal(session.content.mode, 'environment');
  assert.deepEqual(session.content.tools.map(tool => tool.name), ['calculator__add', 'calculator__add_program']);

  const call = await runHarness(root, '/call calculator__add {"a":20,"b":23}');
  const result = (await events(call.stdout)).find(event => event.kind === 'tool.result');
  assert.deepEqual(result.content.result.structuredContent, { sum: 43 });
  assert.equal((await events(call.stdout)).some(event => event.kind.startsWith('model.')), false);
});

test('multiple registered services are discovered and one unavailable service aborts startup', async () => {
  const successful = await fixture('multiple-success', [...registry('first'), ...registry('second')]);
  const listing = await runHarness(successful);
  const session = (await events(listing.stdout)).find(event => event.kind === 'session.started');
  assert.deepEqual(session.content.tools.map(tool => tool.name), ['first__add', 'first__add_program', 'second__add', 'second__add_program']);
  assert.match(listing.stdout, /MCP 工具 4/);

  const unused = createServer();
  unused.listen(0, '127.0.0.1');
  await once(unused, 'listening');
  const unavailableUrl = `http://127.0.0.1:${unused.address().port}/mcp`;
  await new Promise(resolve => unused.close(resolve));
  const failed = await fixture('multiple-failed', [...registry('first'), ...registry('unavailable', unavailableUrl)]);
  await assert.rejects(runHarness(failed), error => {
    assert.equal(error.code, 1);
    const output = error.stdout + error.stderr;
    assert.match(output, /启动失败|fetch failed|connect/i);
    assertNoChat(output);
    assert.doesNotMatch(output, /Harness ·|事件日志：/);
    return true;
  });
});

test('bad JSON, a non-array registry and a missing registry fail before chat', async () => {
  for (const [name, contents] of [['bad-json', '{'], ['non-array', '{}'], ['missing', null]]) {
    const root = await fixture(name, contents);
    await assert.rejects(runHarness(root), error => {
      assert.ok(error.code > 0);
      const output = error.stdout + error.stderr;
      assertNoChat(output);
      assert.doesNotMatch(output, /Harness ·|事件日志：/);
      assert.match(output, /合法 JSON|JSON 数组|No such file|不存在|数组/);
      return true;
    });
  }
});

test('explicit environment, connection file and URL override the package registry in order', async () => {
  const root = await fixture('overrides', '{');
  const connectionFile = join(root, 'custom-connection.json');
  await writeFile(connectionFile, JSON.stringify(registry('from-file')));
  for (const [expectedTool, overrides] of [
    ['from-env__add', {
      HARNESS_MCP_SERVERS: JSON.stringify(registry('from-env')),
      MCP_CONNECTION_FILE: join(root, 'missing.json'), MCP_URL: 'invalid-url',
    }],
    ['from-file__add', { MCP_CONNECTION_FILE: connectionFile, MCP_URL: 'invalid-url' }],
    ['calculator__add', { MCP_URL: url }],
  ]) {
    const listing = await runHarness(root, '/tools', overrides);
    const session = (await events(listing.stdout)).find(event => event.kind === 'session.started');
    assert.deepEqual(session.content.tools.map(tool => tool.name), [expectedTool, `${expectedTool}_program`]);
    assertNoChat(listing.stdout);
  }
});
