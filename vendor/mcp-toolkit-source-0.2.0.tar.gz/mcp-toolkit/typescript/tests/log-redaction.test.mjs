import assert from 'node:assert/strict';
import { test } from 'node:test';
import { snapshotArguments } from '../lib/server.mjs';

test('parameter snapshots keep business values and redact nested credential fields without changing input', () => {
  const input = { a: 20, b: 23, options: { apiKey: 'fixture-secret', path: 'input.xml' }, rows: [{ token: 'second-secret' }] };
  const snapshot = snapshotArguments(input);
  assert.equal(snapshot.a, 20);
  assert.equal(snapshot.options.path, 'input.xml');
  assert.equal(snapshot.options.apiKey, '[redacted]');
  assert.equal(snapshot.rows[0].token, '[redacted]');
  assert.equal(input.options.apiKey, 'fixture-secret');
  assert.doesNotMatch(JSON.stringify(snapshot), /fixture-secret|second-secret/);
});
