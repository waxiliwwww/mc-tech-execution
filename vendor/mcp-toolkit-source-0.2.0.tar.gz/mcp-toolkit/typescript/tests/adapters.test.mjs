import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createServer } from 'node:http';
import { test } from 'node:test';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { runJsonProgram, postJson } from '../lib/adapters.js';
import { createApp, loadServerConfig } from '../lib/server.mjs';
import { tools } from '../lib/tools.js';

const configDefaults = { host: '127.0.0.1', port: 8765, path: '/mcp' };
async function httpFixture(t, handler) {
  const server = createServer(handler);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(() => new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }));
  return `http://127.0.0.1:${server.address().port}`;
}
async function call(t, name, args) {
  const url = await httpFixture(t, createApp({ config: loadServerConfig({}, configDefaults) }));
  const client = new Client({ name: 'adapter-test', version: '1.0.0' });
  t.after(() => client.close());
  await client.connect(new StreamableHTTPClientTransport(new URL(`${url}/mcp`)));
  return await client.callTool({ name, arguments: args });
}
const program = (source, extra = {}) => ({ command: process.execPath, args: ['-e', source], ...extra });

test('bundled external program is actually called over MCP', async t => {
  const result = await call(t, 'add_program', { a: 20, b: 23 });
  assert.notEqual(result.isError, true);
  assert.deepEqual(result.structuredContent, { sum: 43 });
});
test('MCP rejects invalid program parameters before execution', async t => {
  let executed = false;
  const original = tools[1].execute;
  tools[1].execute = async () => { executed = true; return { sum: 99 }; };
  t.after(() => { tools[1].execute = original; });
  const result = await call(t, 'add_program', { a: '20', b: 23 });
  assert.equal(result.isError, true);
  assert.equal(executed, false);
});
test('external output is validated by the MCP output schema', async t => {
  const original = tools[1].execute;
  tools[1].execute = () => runJsonProgram(program('console.log(JSON.stringify({sum:"wrong"}))'), {});
  t.after(() => { tools[1].execute = original; });
  const result = await call(t, 'add_program', { a: 20, b: 23 });
  assert.equal(result.isError, true);
  assert.match(result.content[0].text, /output|validation/i);
});
test('program adapter bounds output, reports exit and malformed JSON, and times out', async () => {
  await assert.rejects(runJsonProgram(program('console.log("not JSON")'), {}), /one JSON object/);
  await assert.rejects(runJsonProgram(program('console.log("[]")'), {}), /JSON object/);
  await assert.rejects(runJsonProgram(program('console.error("secret-that-must-not-escape");process.exit(7)'), {}), error => {
    assert.match(error.message, /Program failed \(7\)/); assert.doesNotMatch(error.message, /secret/); return true;
  });
  await assert.rejects(runJsonProgram(program('setTimeout(()=>{},10000)', { timeoutMs: 50 }), {}), /timed out/);
  await assert.rejects(runJsonProgram(program('console.log("x".repeat(4096))', { maxOutputBytes: 128 }), {}), /maxOutputBytes/);
  await assert.rejects(runJsonProgram({ command: '/missing/program' }, {}), /ENOENT/);
});
test('program arguments and JSON input are passed literally without a shell', async () => {
  const literal = '$(touch should-not-exist); echo hello';
  const result = await runJsonProgram(program('let s="";for await(const c of process.stdin)s+=c;console.log(JSON.stringify({arg:process.argv[1],input:JSON.parse(s)}))', {
    args: ['--input-type=module', '-e', 'let s="";for await(const c of process.stdin)s+=c;console.log(JSON.stringify({arg:process.argv[1],input:JSON.parse(s)}))', literal],
  }), { literal });
  assert.deepEqual(result, { arg: literal, input: { literal } });
});
test('HTTP adapter POSTs JSON with an environment credential to a developer-selected URL', async t => {
  const tokenName = 'TOOLKIT_TEST_API_TOKEN';
  process.env[tokenName] = 'test-fixture-only';
  t.after(() => { delete process.env[tokenName]; });
  const url = await httpFixture(t, async (req, res) => {
    assert.equal(req.method, 'POST');
    assert.equal(req.headers.authorization, 'Bearer test-fixture-only');
    let input = ''; for await (const chunk of req) input += chunk;
    const { a, b } = JSON.parse(input);
    res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ sum: a + b }));
  });
  assert.deepEqual(await postJson({ url, bearerTokenEnv: tokenName }, { a: 20, b: 23 }), { sum: 43 });
});
test('HTTP adapter handles error status, malformed output, limit, timeout, missing credentials and redirects', async t => {
  const url = await httpFixture(t, (req, res) => {
    if (req.url === '/bad') return res.end('not JSON');
    if (req.url === '/large') return res.end('x'.repeat(4096));
    if (req.url === '/slow') return;
    if (req.url === '/redirect') { res.writeHead(302, { Location: '/success' }); return res.end(); }
    res.writeHead(503); res.end('secret-server-detail');
  });
  await assert.rejects(postJson({ url }, {}), error => { assert.match(error.message, /HTTP 503/); assert.doesNotMatch(error.message, /secret/); return true; });
  await assert.rejects(postJson({ url: `${url}/bad` }, {}), /one JSON object/);
  await assert.rejects(postJson({ url: `${url}/large`, maxOutputBytes: 128 }, {}), /maxOutputBytes/);
  await assert.rejects(postJson({ url: `${url}/slow`, timeoutMs: 50 }, {}), /timed out/);
  await assert.rejects(postJson({ url, bearerTokenEnv: 'DELIBERATELY_MISSING_TEST_TOKEN' }, {}), /credential/);
  await assert.rejects(postJson({ url: `${url}/redirect` }, {}));
});
