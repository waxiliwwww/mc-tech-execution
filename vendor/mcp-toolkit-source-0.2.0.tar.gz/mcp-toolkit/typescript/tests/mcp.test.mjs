import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import { createServer, request } from 'node:http';
import { once } from 'node:events';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { existsSync } from 'node:fs';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { createApp, loadServerConfig } from '../lib/server.mjs';
import { tools } from '../lib/tools.js';

const execFileAsync = promisify(execFile);
const fixtureConfig = { host: '127.0.0.1', port: 8765, path: '/mcp' };
let httpServer, url;
before(async () => {
  httpServer = createServer(createApp({ config: loadServerConfig({}, fixtureConfig) }));
  httpServer.listen(0, '127.0.0.1');
  await once(httpServer, 'listening');
  url = `http://127.0.0.1:${httpServer.address().port}/mcp`;
});
after(async () => {
  await new Promise((resolve, reject) => httpServer.close(error => error ? reject(error) : resolve()));
});

async function withClient(run) {
  const client = new Client({ name: 'mcp-add-test', version: '0.1.0' });
  try {
    await client.connect(new StreamableHTTPClientTransport(new URL(url)));
    return await run(client);
  } finally {
    await client.close();
  }
}

test('MCP handshake discovers the function and program tools with number schemas', async () => {
  await withClient(async client => {
    const { tools } = await client.listTools();
    assert.deepEqual(tools.map(tool => tool.name), ['add', 'add_program']);
    assert.deepEqual(tools[0].inputSchema.required, ['a', 'b']);
    assert.equal(tools[0].inputSchema.properties.a.type, 'number');
    assert.equal(tools[0].outputSchema.properties.sum.type, 'number');
  });
});

test('real HTTP calls return text and structured sums, including negatives and decimals', async () => {
  await withClient(async client => {
    for (const [a, b, sum] of [[20, 23, 43], [-4, 1.5, -2.5], [0, 0, 0]]) {
      const result = await client.callTool({ name: 'add', arguments: { a, b } });
      assert.notEqual(result.isError, true);
      assert.deepEqual(result.structuredContent, { sum });
      assert.deepEqual(result.content, [{ type: 'text', text: JSON.stringify({ sum }) }]);
    }
  });
});

test('invalid and missing inputs produce tool errors rather than successful sums', async () => {
  await withClient(async client => {
    for (const args of [{ a: '20', b: 23 }, { a: 20 }]) {
      const result = await client.callTool({ name: 'add', arguments: args });
      assert.equal(result.isError, true);
      assert.match(result.content[0].text, /validation|invalid/i);
    }
    const missing = await client.callTool({ name: 'missing', arguments: {} });
    assert.equal(missing.isError, true);
  });
});

test('finite inputs that overflow produce an explicit tool error', async () => {
  await withClient(async client => {
    const result = await client.callTool({ name: 'add', arguments: { a: 1e308, b: 1e308 } });
    assert.equal(result.isError, true);
    assert.match(result.content[0].text, /finite number range/);
  });
});

test('a replacement program with the wrong output type is rejected by the MCP output contract', async () => {
  const execute = tools[0].execute;
  const logged = [];
  const originalLog = console.log, originalError = console.error;
  console.log = (...values) => logged.push(values.join(' '));
  console.error = (...values) => logged.push(values.join(' '));
  tools[0].execute = async () => ({ sum: '43' });
  try {
    await withClient(async client => {
      const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
      assert.equal(result.isError, true);
      assert.match(result.content[0].text, /output|validation/i);
      assert.ok(logged.some(line => line.includes('执行 add 失败')));
      assert.equal(logged.some(line => line.includes('执行 add 完成')), false);
    });
  } finally {
    tools[0].execute = execute;
    console.log = originalLog;
    console.error = originalError;
  }
});

test('independent clients can initialize and call the stateless server concurrently', async () => {
  const sums = await Promise.all([1, 2, 3].map(a => withClient(async client => {
    const result = await client.callTool({ name: 'add', arguments: { a, b: 10 } });
    return result.structuredContent.sum;
  })));
  assert.deepEqual(sums, [11, 12, 13]);
});

test('HTTP rejects unsupported methods, invalid JSON, and an untrusted Host', async () => {
  for (const method of ['GET', 'DELETE']) {
    const response = await fetch(url, { method });
    assert.equal(response.status, 405);
    assert.equal(response.headers.get('allow'), 'POST');
    assert.equal((await response.json()).error.code, -32000);
  }
  const malformed = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' });
  assert.equal(malformed.status, 400);
  assert.equal((await malformed.json()).error.code, -32700);
  // Node's fetch rewrites Host; use a raw HTTP request to exercise the actual guard.
  const untrustedStatus = await new Promise((resolve, reject) => {
    const req = request(url, { headers: { Host: 'untrusted.invalid' } }, res => {
      res.resume();
      resolve(res.statusCode);
    });
    req.on('error', reject);
    req.end();
  });
  assert.equal(untrustedStatus, 403);
});

function harnessEnv() {
  const env = { ...process.env };
  for (const key of Object.keys(env)) if (key.startsWith('HARNESS_') || key.startsWith('MCP_')) delete env[key];
  return { ...env, MCP_URL: url };
}
const harnessDirectory = process.env.HARNESS_TERMINAL_DIR ?? fileURLToPath(new URL('../../harness/', import.meta.url));
const harnessScript = existsSync(join(harnessDirectory, 'run.sh')) ? join(harnessDirectory, 'run.sh') : null;
async function runHarness(prompt) {
  return execFileAsync('bash', [harnessScript, '--prompt', prompt], { env: harnessEnv(), timeout: 15000 });
}

test('configured Harness discovers MCP tools and records a real call', { skip: !harnessScript }, async () => {
  const listing = await runHarness('/tools');
  assert.match(listing.stdout, /MCP 工具 2/);
  assert.match(listing.stdout, /calculator__add —/);
  const call = await runHarness('/call calculator__add {"a":20,"b":23}');
  assert.match(call.stdout, /MCP 工具 2/);
  const logPath = /事件日志：([^\n]+)/.exec(call.stdout)?.[1];
  assert.ok(logPath);
  const events = (await readFile(logPath, 'utf8')).trim().split('\n').map(JSON.parse);
  const started = events.find(event => event.kind === 'session.started');
  assert.deepEqual(started.content.tools.map(tool => tool.name), ['calculator__add', 'calculator__add_program']);
  const result = events.find(event => event.kind === 'tool.result');
  assert.equal(result.content.name, 'calculator__add');
  assert.deepEqual(result.content.result.structuredContent, { sum: 43 });
  assert.equal(events.some(event => event.kind.startsWith('model.')), false);
});

test('Harness exits nonzero for an invalid input and an unavailable MCP service', { skip: !harnessScript }, async () => {
  await assert.rejects(runHarness('/call calculator__add {"a":"20","b":23}'), error => {
    assert.equal(error.code, 1);
    assert.match(error.stdout, /参数不符合 schema/);
    return true;
  });
  const unusedServer = createServer();
  unusedServer.listen(0, '127.0.0.1');
  await once(unusedServer, 'listening');
  const port = unusedServer.address().port;
  await new Promise(resolve => unusedServer.close(resolve));
  await assert.rejects(execFileAsync('bash', [harnessScript, '--prompt', '/tools'], {
    env: { ...harnessEnv(), MCP_URL: `http://127.0.0.1:${port}/mcp` }, timeout: 15000,
  }), error => {
    assert.equal(error.code, 1);
    assert.match(error.stdout + error.stderr, /失败|fetch failed|connect/i);
    return true;
  });
});
