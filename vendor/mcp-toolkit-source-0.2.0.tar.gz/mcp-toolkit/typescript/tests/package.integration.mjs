import assert from 'node:assert/strict';
import { execFile, spawn } from 'node:child_process';
import { once } from 'node:events';
import { existsSync } from 'node:fs';
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';

const exec = promisify(execFile);
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const harnessRoot = process.env.HARNESS_TERMINAL_DIR ?? fileURLToPath(new URL('../../harness/', import.meta.url));
const cleanEnv = () => Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('MCP_') && !key.startsWith('HARNESS_') && key !== 'NODE_OPTIONS'));

test('independent extracted Node22 package runs both tools and publishes credential-free metadata', async t => {
  const { name, version } = JSON.parse(await readFile(join(projectRoot, 'package.json'), 'utf8'));
  const artifact = `${name}-${version}`;
  await exec('bash', ['package.sh'], { cwd: projectRoot, timeout: 60_000 });
  await exec('sha256sum', ['-c', `${artifact}.tar.gz.sha256`], { cwd: join(projectRoot, 'dist') });
  const directory = await mkdtemp(join(tmpdir(), 'mcp-ts-package-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await exec('tar', ['-xzf', join(projectRoot, 'dist', `${artifact}.tar.gz`), '-C', directory]);
  const extracted = join(directory, artifact);
  await exec('sha256sum', ['-c', 'SHA256SUMS'], { cwd: extracted });
  assert.equal((await readdir(extracted)).includes('node_modules'), false);
  const bundle = await readFile(join(extracted, 'server.mjs'), 'utf8');
  assert.doesNotMatch(bundle, /\/home\/zhangbolun|\/mnt\/d\/workspace/);
  const reserve = createServer(); reserve.listen(0, '127.0.0.1'); await once(reserve, 'listening');
  const port = reserve.address().port; await new Promise(resolve => reserve.close(resolve));
  const token = 'independent-package-fixture';
  const config = { host: '0.0.0.0', port, path: '/custom/mcp', publicUrl: `http://127.0.0.1:${port}/custom/mcp`, name: 'standalone-test', version: '7.8.9', clientName: 'standalone' };
  await writeFile(join(extracted, 'service.config.json'), JSON.stringify(config));
  const child = spawn('bash', [join(extracted, 'start.sh')], {
    cwd: directory, env: { ...cleanEnv(), MCP_AUTH_TOKEN: token }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stdout = '', stderr = '';
  child.stdout.on('data', chunk => { stdout += chunk; }); child.stderr.on('data', chunk => { stderr += chunk; });
  const ended = once(child, 'close');
  t.after(async () => { if (child.exitCode === null) child.kill('SIGTERM'); await ended; });
  const deadline = Date.now() + 5_000;
  while (!stdout.includes('事件日志：')) {
    assert.ok(Date.now() < deadline && child.exitCode === null, `Package failed: ${stdout}\n${stderr}`);
    await new Promise(resolve => setTimeout(resolve, 20));
  }
  assert.equal(stdout.trim().split('\n').length, 3);
  assert.match(stdout, /standalone-test.*Bearer/);
  const connection = JSON.parse(await readFile(join(extracted, 'connection.json'), 'utf8'));
  assert.equal(connection[0].url, `http://127.0.0.1:${port}/custom/mcp`);
  assert.equal(connection[0].headers.Authorization, 'Bearer ${MCP_AUTH_TOKEN}');
  assert.doesNotMatch(JSON.stringify(connection), new RegExp(token));
  const url = `http://127.0.0.1:${port}`;
  assert.equal((await fetch(`${url}/info`)).status, 401);
  const info = await (await fetch(`${url}/info`, { headers: { Authorization: `Bearer ${token}` } })).json();
  assert.deepEqual(info.service, { name: 'standalone-test', version: '7.8.9' });
  assert.doesNotMatch(JSON.stringify(info), new RegExp(token));
  const client = new Client({ name: 'package-test', version: '1.0.0' });
  try {
    await client.connect(new StreamableHTTPClientTransport(new URL(connection[0].url), { requestInit: { headers: { Authorization: `Bearer ${token}` } } }));
    assert.deepEqual((await client.listTools()).tools.map(x => x.name), ['add', 'add_program']);
    for (const tool of ['add', 'add_program']) {
      const result = await client.callTool({ name: tool, arguments: { a: 20, b: 23 } });
      assert.notEqual(result.isError, true); assert.deepEqual(result.structuredContent, { sum: 43 });
    }
  } finally { await client.close(); }
  if (existsSync(join(harnessRoot, 'run.sh'))) {
    const { stdout: harnessOutput } = await exec('bash', [join(harnessRoot, 'run.sh'), '--prompt', '/call standalone__add_program {"a":20,"b":23}'], {
      cwd: directory, env: { ...cleanEnv(), MCP_AUTH_TOKEN: token, MCP_CONNECTION_FILE: join(extracted, 'connection.json') }, timeout: 15_000,
    });
    const logPath = /事件日志：([^\n]+)/.exec(harnessOutput)?.[1]; assert.ok(logPath);
    const events = (await readFile(logPath, 'utf8')).trim().split('\n').map(JSON.parse);
    assert.deepEqual(events.find(x => x.kind === 'tool.result').content.result.structuredContent, { sum: 43 });
    assert.equal(events.some(x => x.kind.startsWith('model.')), false);
  } else t.diagnostic('Harness package not present; standalone MCP package verified without Harness integration.');
  const logFile = /事件日志：([^\n]+)/.exec(stdout)?.[1];
  assert.doesNotMatch(await readFile(logFile, 'utf8'), new RegExp(token));
  assert.doesNotMatch(stdout + stderr, new RegExp(token));
});
