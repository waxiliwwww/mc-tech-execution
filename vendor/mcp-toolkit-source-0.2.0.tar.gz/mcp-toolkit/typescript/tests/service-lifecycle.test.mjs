import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { createConnection } from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';

const entry = fileURLToPath(new URL('../lib/server.mjs', import.meta.url));
const execFileAsync = promisify(execFile);
const timestamp = /\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} [+-]\d{2}:\d{2}\]/;

function cleanEnv() {
  const env = { ...process.env };
  for (const key of Object.keys(env)) {
    if (key.startsWith('MCP_') || key.startsWith('HARNESS_') || key === 'NODE_OPTIONS') delete env[key];
  }
  return env;
}

async function freePort() {
  const server = createServer();
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  await new Promise(resolve => server.close(resolve));
  return port;
}

async function waitFor(predicate, description) {
  const deadline = Date.now() + 5000;
  while (!await predicate()) {
    assert.ok(Date.now() < deadline, `Timed out waiting for ${description}`);
    await new Promise(resolve => setTimeout(resolve, 10));
  }
}

async function fixture(t, { port, config, connectionFile, blockLogs = false, runtimeError = false } = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'mcp-service-lifecycle-'));
  const actualPort = port ?? await freePort();
  const configFile = join(directory, 'service.config.json');
  const traceFile = join(directory, 'timer-trace.jsonl');
  const preload = join(directory, 'clock.mjs');
  await writeFile(configFile, JSON.stringify(config ?? { host: '127.0.0.1', port: actualPort, path: '/api/mcp' }));
  // Test-only instrumentation observes the real default delay, then accelerates it.
  // Production has no heartbeat override or additional entry point.
  await writeFile(preload, `
import { appendFileSync } from 'node:fs';
import http from 'node:http';
import { syncBuiltinESMExports } from 'node:module';
const traceFile = ${JSON.stringify(traceFile)};
const trace = value => appendFileSync(traceFile, JSON.stringify(value) + '\\n');
const originalInterval = globalThis.setInterval;
const originalClear = globalThis.clearInterval;
const heartbeatTimers = new Set();
globalThis.setInterval = (callback, delay, ...args) => {
  trace({ kind: 'interval', delay });
  const timer = originalInterval(callback, delay === 300000 ? 50 : delay, ...args);
  if (delay === 300000) {
    heartbeatTimers.add(timer);
    const originalUnref = timer.unref.bind(timer);
    timer.unref = () => { trace({ kind: 'unref' }); return originalUnref(); };
  }
  return timer;
};
globalThis.clearInterval = timer => {
  if (heartbeatTimers.delete(timer)) trace({ kind: 'clear' });
  return originalClear(timer);
};
${runtimeError ? `
const originalServer = http.createServer;
http.createServer = (...args) => {
  const server = originalServer(...args);
  server.once('listening', () => setTimeout(() => {
    server.emit('error', Object.assign(new Error('simulated runtime error'), { code: 'TEST_RUNTIME_ERROR' }));
  }, 25));
  return server;
};
syncBuiltinESMExports();` : ''}
`);
  if (blockLogs) await writeFile(join(directory, 'logs'), 'blocked by a regular file');
  if (connectionFile === 'directory') await mkdir(join(directory, 'connection.json'));
  const env = { ...cleanEnv(), MCP_CONFIG_FILE: configFile };
  if (connectionFile) env.MCP_CONNECTION_FILE = join(directory, 'connection.json');
  const child = spawn(process.execPath, ['--import', preload, entry], { cwd: directory, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.setEncoding('utf8').on('data', chunk => { stdout += chunk; });
  child.stderr.setEncoding('utf8').on('data', chunk => { stderr += chunk; });
  const exited = new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => resolve({ code, signal }));
  });
  const runtime = {
    directory, port: actualPort, configFile, traceFile, child, exited,
    get stdout() { return stdout; }, get stderr() { return stderr; },
    get logFile() { return /^事件日志：(.+)$/m.exec(stdout)?.[1]; },
    async events() {
      const file = runtime.logFile ?? join(directory, 'logs', (await readdir(join(directory, 'logs')))[0]);
      const content = await readFile(file, 'utf8');
      return content.trim() ? content.trim().split('\n').map(JSON.parse) : [];
    },
    async trace() {
      try { return (await readFile(traceFile, 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse); }
      catch (error) { if (error.code === 'ENOENT') return []; throw error; }
    },
    async ready() {
      await waitFor(() => runtime.logFile || child.exitCode !== null, 'service startup');
      assert.ok(runtime.logFile, `Service did not start: ${stderr}`);
    },
    async stop(signal = 'SIGTERM') {
      if (child.exitCode === null && child.signalCode === null) child.kill(signal);
      await waitFor(() => child.exitCode !== null || child.signalCode !== null, 'service exit');
      return await exited;
    },
  };
  t.after(async () => {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
    await exited;
    await rm(directory, { recursive: true, force: true });
  });
  return runtime;
}

async function withClient(runtime, run) {
  const client = new Client({ name: 'service-lifecycle-test', version: '0.1.0' });
  try {
    await client.connect(new StreamableHTTPClientTransport(new URL(`http://127.0.0.1:${runtime.port}/api/mcp`)));
    return await run(client);
  } finally {
    await client.close();
  }
}

test('CLI uses one three-line summary and records metadata plus real execution events in JSONL', async t => {
  const runtime = await fixture(t, { connectionFile: 'file' });
  await runtime.ready();
  const lines = runtime.stdout.trim().split('\n');
  assert.deepEqual(lines.slice(0, 2), [
    'MCP 已启动 · mcp-toolkit-typescript · streamable-http · 鉴权未启用',
    `地址：http://127.0.0.1:${runtime.port}/api/mcp · 工具：add, add_program`,
  ]);
  assert.equal(lines[2], `事件日志：${runtime.logFile}`);
  assert.doesNotMatch(runtime.stdout, /server\.started|HARNESS_MCP_SERVERS|服务配置：|监听地址：|连接名称：/);
  const started = (await runtime.events()).find(event => event.event === 'server.started');
  assert.equal(started.level, 'INFO');
  assert.ok(Number.isFinite(Date.parse(started.time)));
  assert.deepEqual(started.listen, { host: '127.0.0.1', port: runtime.port });
  assert.equal(started.url, `http://127.0.0.1:${runtime.port}/api/mcp`);
  assert.equal(started.configFile, runtime.configFile);
  assert.equal(started.eventLogFile, runtime.logFile);
  assert.equal(started.heartbeatIntervalMs, 300_000);
  assert.equal(started.transport, 'streamable-http');
  assert.deepEqual(started.authentication, { implemented: false, type: 'none' });
  assert.deepEqual(started.connection, [{ name: 'calculator', transport: 'streamable-http', url: started.url }]);
  assert.deepEqual(JSON.parse(await readFile(started.connectionFile, 'utf8')), started.connection);
  await withClient(runtime, async client => {
    assert.deepEqual((await client.listTools()).tools.map(tool => tool.name), ['add', 'add_program']);
    const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
    assert.notEqual(result.isError, true);
    assert.deepEqual(result.structuredContent, { sum: 43 });
    const failed = await client.callTool({ name: 'add', arguments: { a: 1e308, b: 1e308 } });
    assert.equal(failed.isError, true);
    assert.match(failed.content[0].text, /finite number range/);
  });
  assert.match(runtime.stdout, new RegExp(`${timestamp.source} 执行 add 完成`));
  assert.match(runtime.stderr, new RegExp(`${timestamp.source} 执行 add 失败`));
  assert.match(runtime.stdout, /参数：\{"a":20,"b":23\}/);
  assert.match(runtime.stderr, /参数：\{"a":1e\+308,"b":1e\+308\}/);
  const events = await runtime.events();
  for (const event of ['tool.executed', 'tool.failed']) {
    const record = events.find(record => record.event === event);
    assert.equal(record.name, 'add');
    assert.deepEqual(record.arguments, event === 'tool.executed' ? { a: 20, b: 23 } : { a: 1e308, b: 1e308 });
    assert.deepEqual(Object.keys(record).sort(), ['arguments', 'event', 'level', 'name', 'time']);
  }
  assert.deepEqual(await runtime.stop(), { code: 0, signal: null });
});

test('the actual 300000ms heartbeat is unrefed, timestamped and cleared on SIGTERM', async t => {
  const runtime = await fixture(t);
  await runtime.ready();
  await waitFor(() => runtime.stdout.includes('已运行'), 'accelerated heartbeat');
  assert.match(runtime.stdout, new RegExp(`${timestamp.source} 已运行 \\d{2,}:\\d{2}:\\d{2}`));
  assert.doesNotMatch(runtime.stdout, /心跳/);
  const heartbeat = (await runtime.events()).find(event => event.event === 'server.heartbeat');
  assert.equal(heartbeat.intervalMs, 300_000);
  assert.ok(heartbeat.uptimeMs >= 0);
  assert.equal((await runtime.events()).find(event => event.event === 'server.started').connectionFile, join(runtime.directory, 'connection.json'));
  assert.equal((await readdir(runtime.directory)).includes('connection.json'), true);
  assert.deepEqual(await runtime.stop(), { code: 0, signal: null });
  const events = await runtime.events();
  assert.equal(events.at(-1).event, 'server.stopped');
  assert.equal(events.at(-1).signal, 'SIGTERM');
  assert.deepEqual(await runtime.trace(), [{ kind: 'interval', delay: 300_000 }, { kind: 'unref' }, { kind: 'clear' }]);
});

test('runtime log failure warns once while real calls and heartbeat continue', async t => {
  const runtime = await fixture(t);
  await runtime.ready();
  // Move the directory atomically so append cannot recreate a removed file between awaits.
  await rename(join(runtime.directory, 'logs'), join(runtime.directory, 'logs-before-failure'));
  await writeFile(join(runtime.directory, 'logs'), 'blocked by a regular file');
  const beforeFailure = (runtime.stdout.match(/已运行/g) ?? []).length;
  await withClient(runtime, async client => {
    const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
    assert.notEqual(result.isError, true);
    assert.deepEqual(result.structuredContent, { sum: 43 });
    const failed = await client.callTool({ name: 'add', arguments: { a: 1e308, b: 1e308 } });
    assert.equal(failed.isError, true);
    assert.match(failed.content[0].text, /finite number range/);
  });
  await waitFor(() => (runtime.stdout.match(/已运行/g) ?? []).length > beforeFailure, 'heartbeat after logging failure');
  assert.equal((await fetch(`http://127.0.0.1:${runtime.port}/health`)).status, 200);
  assert.deepEqual(await runtime.stop(), { code: 0, signal: null });
  assert.equal((runtime.stderr.match(/事件日志写入失败/g) ?? []).length, 1);
  assert.equal((runtime.stdout.match(/执行 add 完成/g) ?? []).length, 1);
  assert.equal((runtime.stderr.match(/执行 add 失败/g) ?? []).length, 1);
  assert.doesNotMatch(runtime.stderr, /MCP 请求失败|服务启动或运行失败/);
});

test('SIGTERM followed by SIGINT drains an unfinished request and stops exactly once', async t => {
  const runtime = await fixture(t);
  await runtime.ready();
  const socket = createConnection({ host: '127.0.0.1', port: runtime.port });
  socket.on('error', () => {});
  t.after(() => socket.destroy());
  await once(socket, 'connect');
  socket.write(`POST /api/mcp HTTP/1.1\r\nHost: 127.0.0.1:${runtime.port}\r\nContent-Type: application/json\r\nContent-Length: 1000\r\n\r\n{`);
  await new Promise(resolve => setTimeout(resolve, 30));
  runtime.child.kill('SIGTERM');
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.equal(runtime.child.exitCode, null, 'unfinished request should be draining');
  runtime.child.kill('SIGINT');
  await waitFor(() => runtime.child.exitCode !== null, 'forced drain completion');
  assert.deepEqual(await runtime.exited, { code: 0, signal: null });
  const events = await runtime.events();
  assert.equal(events.filter(event => event.event === 'server.stopped').length, 1);
  const stoppedIndex = events.findIndex(event => event.event === 'server.stopped');
  assert.equal(events[stoppedIndex].signal, 'SIGTERM');
  // Aborting a partial request may still log its close error after the server close event.
  assert.equal(events.slice(stoppedIndex + 1).some(event => event.event === 'server.heartbeat'), false);
  assert.equal((await runtime.trace()).filter(event => event.kind === 'clear').length, 1);
});

test('a simulated HTTP server error clears the heartbeat and exits nonzero', async t => {
  const runtime = await fixture(t, { runtimeError: true });
  await waitFor(() => runtime.child.exitCode !== null, 'runtime error exit');
  assert.deepEqual(await runtime.exited, { code: 1, signal: null });
  assert.match(runtime.stderr, /服务启动或运行失败：TEST_RUNTIME_ERROR/);
  const events = await runtime.events();
  assert.equal(events.filter(event => event.event === 'server.started').length, 1);
  assert.equal(events.find(event => event.event === 'server.failed').code, 'TEST_RUNTIME_ERROR');
  assert.equal(events.at(-1).event, 'server.stopped');
  assert.deepEqual(await runtime.trace(), [{ kind: 'interval', delay: 300_000 }, { kind: 'unref' }, { kind: 'clear' }]);
});

test('failed starts never report success or create heartbeat timers', async t => {
  const occupied = createServer();
  occupied.listen(0, '127.0.0.1');
  await once(occupied, 'listening');
  t.after(() => new Promise(resolve => occupied.close(resolve)));
  const cases = [
    { name: 'invalid configuration', options: { config: { host: '127.0.0.1', port: [], path: '/mcp' } }, code: 2, error: /port must be/, event: null },
    { name: 'occupied port', options: { port: occupied.address().port }, code: 1, error: /EADDRINUSE/, event: 'server.failed' },
    { name: 'connection file failure', options: { connectionFile: 'directory' }, code: 1, error: /保存连接配置失败/, event: 'connection.write_failed' },
    { name: 'log initialization failure', options: { blockLogs: true }, code: 1, error: /事件日志初始化失败/, event: null },
  ];
  for (const scenario of cases) await t.test(scenario.name, async subtest => {
    const runtime = await fixture(subtest, scenario.options);
    await waitFor(() => runtime.child.exitCode !== null, 'failed startup exit');
    assert.deepEqual(await runtime.exited, { code: scenario.code, signal: null });
    assert.match(runtime.stderr, scenario.error);
    assert.doesNotMatch(runtime.stdout, /MCP 已启动|事件日志：|已运行/);
    assert.deepEqual(await runtime.trace(), []);
    if (scenario.event) {
      const events = await runtime.events();
      assert.equal(events.some(event => event.event === scenario.event), true);
      assert.equal(events.some(event => ['server.started', 'server.heartbeat'].includes(event.event)), false);
    }
  });
});

test('importing the existing public module creates no log file or heartbeat', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'mcp-service-import-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const result = await execFileAsync(process.execPath, ['--input-type=module', '-e',
    `await import(${JSON.stringify(new URL('../lib/server.mjs', import.meta.url).href)}); console.log('imported');`],
  { cwd: directory, env: cleanEnv(), timeout: 5000 });
  assert.equal(result.stdout, 'imported\n');
  assert.equal(result.stderr, '');
  assert.deepEqual(await readdir(directory), []);
});
