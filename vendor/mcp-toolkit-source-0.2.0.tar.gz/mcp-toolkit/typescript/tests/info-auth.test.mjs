import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createServer } from 'node:http';
import { test } from 'node:test';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { connectionInfo, createApp, loadServerConfig } from '../lib/server.mjs';

const defaults = { host: '127.0.0.1', port: 8765, path: '/mcp' };
async function fixture(t, config) {
  const server = createServer(createApp({ config }));
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(() => new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }));
  return `http://127.0.0.1:${server.address().port}`;
}

test('info reports the same schemas and annotations as official MCP tools/list', async t => {
  const config = loadServerConfig({}, { ...defaults, name: 'sample-service', version: '2.3.4', clientName: 'sample' });
  const url = await fixture(t, config);
  const info = await (await fetch(`${url}/info`)).json();
  assert.equal(info.schemaVersion, 1);
  assert.deepEqual(info.service, { name: 'sample-service', version: '2.3.4' });
  assert.equal(info.url, config.url);
  assert.deepEqual(info.authentication, { implemented: false, type: 'none' });
  assert.deepEqual(info.connection, [{ name: 'sample', transport: 'streamable-http', url: config.url }]);
  const client = new Client({ name: 'info-test', version: '1.0.0' }); t.after(() => client.close());
  await client.connect(new StreamableHTTPClientTransport(new URL(`${url}/mcp`)));
  const listing = (await client.listTools()).tools;
  assert.deepEqual(info.tools, listing.map(({ name, description, inputSchema, outputSchema, annotations }) => ({ name, description, inputSchema, outputSchema, annotations })));
});
test('Bearer auth protects info and every MCP method, metadata contains only an env placeholder', async t => {
  const token = 'unique-fixture-token';
  const config = loadServerConfig({ MCP_AUTH_TOKEN: token }, defaults);
  assert.doesNotMatch(JSON.stringify(config), new RegExp(token));
  const url = await fixture(t, config);
  for (const route of ['/info', '/mcp']) for (const method of ['GET', 'POST', 'DELETE']) {
    for (const headers of [{}, { Authorization: 'Bearer wrong' }]) {
      const response = await fetch(`${url}${route}`, { method, headers });
      assert.equal(response.status, 401); await response.text();
    }
  }
  assert.equal((await fetch(`${url}/health`)).status, 200);
  const headers = { Authorization: `Bearer ${token}` };
  const info = await (await fetch(`${url}/info`, { headers })).json();
  assert.deepEqual(info.authentication, { implemented: true, type: 'bearer', tokenEnv: 'MCP_AUTH_TOKEN' });
  assert.equal(info.connection[0].headers.Authorization, 'Bearer ${MCP_AUTH_TOKEN}');
  assert.doesNotMatch(JSON.stringify(info), new RegExp(token));
  const client = new Client({ name: 'auth-test', version: '1.0.0' }); t.after(() => client.close());
  await client.connect(new StreamableHTTPClientTransport(new URL(`${url}/mcp`), { requestInit: { headers } }));
  const result = await client.callTool({ name: 'add', arguments: { a: 20, b: 23 } });
  assert.deepEqual(result.structuredContent, { sum: 43 });
});
test('remote listening requires an advertised URL and token, and never publishes wildcard addresses', () => {
  for (const host of ['0.0.0.0', '::', '192.168.1.10']) {
    assert.throws(() => loadServerConfig({}, { ...defaults, host }), /publicUrl/);
    assert.throws(() => loadServerConfig({}, { ...defaults, host, publicUrl: 'https://tools.example/api/mcp' }), /MCP_AUTH_TOKEN/);
    const config = loadServerConfig({ MCP_AUTH_TOKEN: 'fixture' }, { ...defaults, host, publicUrl: 'https://tools.example/api/mcp' });
    assert.equal(config.url, 'https://tools.example/api/mcp');
    assert.equal(connectionInfo(config)[0].url, config.url);
  }
  for (const publicUrl of ['http://0.0.0.0/mcp', 'http://[::]/mcp', 'https://u:p@tools.example/mcp', 'https://tools.example/mcp?token=secret', 'ftp://tools.example/mcp', 'https://tools.example/']) {
    assert.throws(() => loadServerConfig({ MCP_AUTH_TOKEN: 'fixture' }, { ...defaults, host: '0.0.0.0', publicUrl }));
  }
  for (const token of ['', ' ', 'line\nbreak', 'with space']) assert.throws(() => loadServerConfig({ MCP_AUTH_TOKEN: token }, defaults), /MCP_AUTH_TOKEN/);
});
