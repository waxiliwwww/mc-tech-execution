// Bearer authentication and one middleware extension point for /info and MCP.
import { timingSafeEqual } from 'node:crypto';

export function createAuthenticateRequest(token) {
  const expected = token ? Buffer.from(`Bearer ${token}`) : null;
  return (request, response, next) => {
    if (!expected) return next();
    const actual = Buffer.from(request.headers.authorization ?? '');
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
      response.set('WWW-Authenticate', 'Bearer').status(401).json({ error: 'Authentication required.' });
      return;
    }
    next();
  };
}
