// Business functions are independent of MCP. Edit this file for direct TS functions.
export function add(a: number, b: number): number {
  if (![a, b].every(value => typeof value === 'number' && Number.isFinite(value))) {
    throw new TypeError('a and b must be finite numbers.');
  }
  const sum = a + b;
  if (!Number.isFinite(sum)) throw new RangeError('The sum is outside the finite number range.');
  return sum;
}
