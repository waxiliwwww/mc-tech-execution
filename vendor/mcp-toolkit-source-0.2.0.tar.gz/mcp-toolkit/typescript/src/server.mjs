#!/usr/bin/env node
// Generic MCP tool host, 2026-10-12. Run: ./start.sh; customize src/tools.ts.
import { createServer } from 'node:http';
import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { createMcpExpressApp } from '@modelcontextprotocol/sdk/server/express.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import manifest from '../package.json' with { type: 'json' };
import { tools } from './tools.js';
import { createAuthenticateRequest } from './auth.mjs';
import { isIP } from 'node:net';
import { z } from 'zod';

// Keep credentials in closures; they never become config/metadata/log fields.
const authenticationByConfig = new WeakMap();

const HEARTBEAT_INTERVAL_MS = 300_000;
let eventLogFile;
let logWriteWarningShown = false;

export function snapshotArguments(value) {
  // Preserve useful business parameters while avoiding common credential fields.
  return JSON.parse(JSON.stringify(value, (key, item) =>
    /^(password|passwd|secret|token|access_token|refresh_token|api[_-]?key|authorization|credentials?)$/i.test(key)
      ? '[redacted]' : item));
}

function localTimestamp(date) {
  const pad = value => String(value).padStart(2, '0');
  const offset = -date.getTimezoneOffset();
  const zone = `${offset >= 0 ? '+' : '-'}${pad(Math.floor(Math.abs(offset) / 60))}:${pad(Math.abs(offset) % 60)}`;
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())} ${zone}`;
}

function runningTime(milliseconds) {
  const seconds = Math.floor(milliseconds / 1000);
  return [Math.floor(seconds / 3600), Math.floor(seconds % 3600 / 60), seconds % 60].map(value => String(value).padStart(2, '0')).join(':');
}

function log(level, event, fields = {}) {
  const now = new Date();
  if (eventLogFile) {
    try {
      appendFileSync(eventLogFile, JSON.stringify({ time: now.toISOString(), level, event, ...fields }) + '\n');
    } catch (error) {
      // Observability failures must not change a tool result or throw from a timer.
      if (!logWriteWarningShown) {
        logWriteWarningShown = true;
        console.error(`[${localTimestamp(now)}] 事件日志写入失败：${error.message}`);
      }
    }
  }
  const prefix = `[${localTimestamp(now)}]`;
  if (event === 'tool.executed') console.log(`${prefix} 执行 ${fields.name} 完成 · 参数：${JSON.stringify(fields.arguments)}`);
  else if (event === 'tool.failed') console.error(`${prefix} 执行 ${fields.name} 失败 · 参数：${JSON.stringify(fields.arguments)}`);
  else if (event === 'server.heartbeat') console.log(`${prefix} 已运行 ${runningTime(fields.uptimeMs)}`);
  else if (event === 'server.stopped') console.log(`${prefix} MCP 已停止`);
  else if (level === 'ERROR') {
    const labels = {
      'server.failed': '服务启动或运行失败',
      'connection.write_failed': '保存连接配置失败',
      'mcp.close_failed': '关闭 MCP 请求失败',
      'mcp.request_failed': 'MCP 请求失败',
      'http.request_failed': 'HTTP 请求失败',
    };
    console.error(`${prefix} ${labels[event] ?? event}：${fields.code ? `${fields.code} · ` : ''}${fields.message ?? ''}`);
  }
}

export function loadServerConfig(env = process.env, defaults) {
  if (defaults === undefined) {
    const configFile = resolve(env.MCP_CONFIG_FILE ?? 'service.config.json');
    try {
      defaults = JSON.parse(readFileSync(configFile, 'utf8'));
    } catch (error) {
      throw new Error(`Cannot read service configuration ${configFile}: ${error.message}`);
    }
  }
  if (!defaults || typeof defaults !== 'object' || Array.isArray(defaults)
    || !['host', 'port', 'path'].every(key => Object.hasOwn(defaults, key))) {
    throw new Error('Service configuration must be a JSON object containing host, port, and path.');
  }
  const host = env.MCP_HOST ?? defaults.host;
  if (typeof host !== 'string' || (host !== 'localhost' && !isIP(host))) {
    throw new Error('MCP_HOST must be localhost or an IPv4/IPv6 address.');
  }
  const loopback = host === 'localhost' || host === '::1' || (isIP(host) === 4 && host.startsWith('127.'));
  const rawPort = env.MCP_PORT ?? defaults.port;
  if (!['number', 'string'].includes(typeof rawPort)) {
    throw new Error('Service port must be a number or decimal string.');
  }
  const portText = String(rawPort);
  const port = Number(portText);
  if (!/^\d+$/.test(portText) || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('MCP_PORT must be a decimal integer between 1 and 65535.');
  }
  const mcpPath = env.MCP_PATH ?? defaults.path;
  if (typeof mcpPath !== 'string' || !/^\/[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)*$/.test(mcpPath)
    || mcpPath.split('/').some(segment => segment === '.' || segment === '..')
    || ['/health', '/info'].includes(mcpPath.toLowerCase())) {
    throw new Error('MCP_PATH must be a literal absolute path such as /mcp or /api/mcp, excluding /health, /info and dot segments.');
  }
  const urlHost = isIP(host) === 6 ? `[${host}]` : host;
  const publicUrl = env.MCP_PUBLIC_URL ?? defaults.publicUrl;
  if (!loopback && !publicUrl) throw new Error('Non-loopback listening requires an explicit publicUrl (or MCP_PUBLIC_URL).');
  let url = `http://${urlHost}:${port}${mcpPath}`;
  if (publicUrl !== undefined) {
    let parsed;
    try { parsed = new URL(publicUrl); } catch { throw new Error('publicUrl must be a complete HTTP(S) MCP URL.'); }
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash
      || ['0.0.0.0', '[::]'].includes(parsed.hostname) || parsed.pathname === '/') {
      throw new Error('publicUrl must include the MCP path and a reachable host, without credentials, query or fragment.');
    }
    url = parsed.href;
  }
  const token = env.MCP_AUTH_TOKEN;
  if (token !== undefined && (typeof token !== 'string' || !token.trim() || /[\s\r\n]/.test(token))) {
    throw new Error('MCP_AUTH_TOKEN must be nonempty and contain no whitespace.');
  }
  if (!loopback && !token) throw new Error('Non-loopback listening requires MCP_AUTH_TOKEN.');
  const identity = {};
  for (const [key, fallback] of Object.entries({ name: manifest.name, version: manifest.version, clientName: manifest.mcp?.clientName ?? 'calculator' })) {
    const value = defaults[key] ?? fallback;
    if (typeof value !== 'string' || !value.trim() || /[\r\n]/.test(value) || value.length > 120
      || (key === 'clientName' && !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(value))) {
      throw new Error(`Service ${key} must be a nonempty single-line string (clientName: letters, digits, dot, underscore, hyphen).`);
    }
    identity[key] = value;
  }
  const config = { host, port, mcpPath, url, ...identity,
    authentication: token ? { implemented: true, type: 'bearer', tokenEnv: 'MCP_AUTH_TOKEN' } : { implemented: false, type: 'none' },
  };
  authenticationByConfig.set(config, createAuthenticateRequest(token));
  return config;
}

function createMcpServer(config) {
  const server = new McpServer({ name: config.name, version: config.version });
  for (const { name, execute, ...definition } of tools) server.registerTool(name, definition, async (args) => {
    // Snapshot submitted business parameters before an implementation can mutate them.
    let parameters;
    try { parameters = snapshotArguments(args); }
    catch { parameters = '[无法序列化]'; }
    try {
      const output = await execute(args);
      // Validate before reporting success; SDK validation happens after this callback.
      if (definition.outputSchema) {
        const checked = z.object(definition.outputSchema).safeParse(output);
        if (!checked.success) throw new Error(`Output schema validation failed: ${checked.error.message}`);
      }
      const text = JSON.stringify(output);
      // Log only business parameters; authentication headers and environment stay outside args.
      // A business return with an invalid output schema is a failed tool call.
      log('INFO', 'tool.executed', { name, arguments: parameters });
      return { content: [{ type: 'text', text }], structuredContent: output };
    } catch (error) {
      log('WARNING', 'tool.failed', { name, arguments: parameters });
      return { isError: true, content: [{ type: 'text', text: error.message }] };
    }
  });
  return server;
}

export function connectionInfo(config) {
  return [{ name: config.clientName, transport: 'streamable-http', url: config.url,
    ...(config.authentication.implemented ? { headers: { Authorization: 'Bearer ${MCP_AUTH_TOKEN}' } } : {}),
  }];
}

export function serviceInfo(config) {
  return {
    schemaVersion: 1, service: { name: config.name, version: config.version },
    transport: 'streamable-http', url: config.url,
    authentication: config.authentication, connection: connectionInfo(config),
    tools: tools.map(({ name, description, inputSchema, outputSchema, annotations }) => ({
      name, description,
      inputSchema: z.toJSONSchema(z.object(inputSchema), { target: 'draft-7', io: 'input' }),
      outputSchema: z.toJSONSchema(z.object(outputSchema), { target: 'draft-7', io: 'output' }),
      ...(annotations ? { annotations } : {}),
    })),
  };
}

export function createApp({ config = loadServerConfig(), authenticate } = {}) {
  const auth = authenticate ?? authenticationByConfig.get(config);
  if (!auth) throw new Error('Create config with loadServerConfig or supply an explicit authentication middleware.');
  const hostnames = ['127.0.0.1', 'localhost', '[::1]', new URL(config.url).hostname];
  if (!['0.0.0.0', '::'].includes(config.host)) hostnames.push(isIP(config.host) === 6 ? `[${config.host}]` : config.host);
  const app = createMcpExpressApp({ host: config.host, allowedHosts: [...new Set(hostnames)] });
  app.get('/health', (_req, res) => res.json({ status: 'ok', service: config.name, version: config.version }));
  // The same extension point protects metadata and every MCP method.
  app.use('/info', auth);
  app.get('/info', (_req, res) => res.json(serviceInfo(config)));
  app.use(config.mcpPath, auth);
  app.post(config.mcpPath, async (req, res) => {
    // Stateless transports handle exactly one request; each POST needs its own pair.
    const server = createMcpServer(config);
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    res.on('close', () => {
      server.close().catch(error => log('ERROR', 'mcp.close_failed', { message: error.message }));
    });
    try {
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (error) {
      log('ERROR', 'mcp.request_failed', { message: error.message });
      if (!res.headersSent) res.status(500).json({ jsonrpc: '2.0', error: { code: -32603, message: 'Internal server error' }, id: null });
      else if (!res.writableEnded) res.end();
    }
  });
  // A stateless service has no GET notification stream or DELETE session.
  app.all(config.mcpPath, (_req, res) => res.status(405).set('Allow', 'POST').json({
    jsonrpc: '2.0', error: { code: -32000, message: 'Method not allowed' }, id: null,
  }));
  app.use((error, _req, res, _next) => {
    const status = error.type === 'entity.too.large' ? 413 : error.type === 'entity.parse.failed' ? 400 : 500;
    if (status === 500) log('ERROR', 'http.request_failed', { message: error.message });
    res.status(status).json({ jsonrpc: '2.0', error: {
      code: status === 500 ? -32603 : -32700,
      message: status === 500 ? 'Internal server error' : 'Invalid JSON request body',
    }, id: null });
  });
  return app;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  let config;
  try {
    config = loadServerConfig();
  } catch (error) {
    console.error(error.message);
    process.exit(2);
  }
  try {
    const directory = resolve('logs');
    mkdirSync(directory, { recursive: true, mode: 0o700 });
    eventLogFile = resolve(directory, `server-${new Date().toISOString().replace(/[:.]/g, '-')}-${process.pid}.jsonl`);
    writeFileSync(eventLogFile, '', { flag: 'wx', mode: 0o600 });
  } catch (error) {
    console.error(`事件日志初始化失败：${error.message}`);
    process.exit(1);
  }
  const httpServer = createServer(createApp({ config }));
  let heartbeatTimer, shutdownTimer;
  let started = false, stopping = false, stoppingSignal = null;
  const clearHeartbeat = () => {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = undefined;
  };
  const stop = signal => {
    if (stopping) return;
    stopping = true;
    stoppingSignal = signal ?? null;
    clearHeartbeat();
    httpServer.close();
    httpServer.closeIdleConnections();
    shutdownTimer = setTimeout(() => httpServer.closeAllConnections(), 3000);
    shutdownTimer.unref();
  };
  httpServer.once('close', () => {
    clearHeartbeat();
    clearTimeout(shutdownTimer);
    if (started) log('INFO', 'server.stopped', { signal: stoppingSignal });
  });
  httpServer.on('error', error => {
    clearHeartbeat();
    log('ERROR', 'server.failed', { code: error.code, message: error.message });
    process.exitCode = 1;
    stop();
  });
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => stop(signal));
  httpServer.listen(config.port, config.host, () => {
    if (stopping) return;
    const { url } = config;
    const connection = connectionInfo(config);
    const connectionFile = resolve(process.env.MCP_CONNECTION_FILE ?? 'connection.json');
    try {
      writeFileSync(connectionFile, JSON.stringify(connection, null, 2) + '\n', { mode: 0o600 });
    } catch (error) {
      log('ERROR', 'connection.write_failed', { message: error.message });
      process.exitCode = 1;
      stop();
      return;
    }
    started = true;
    const runningSince = performance.now();
    log('INFO', 'server.started', {
      listen: { host: config.host, port: config.port }, url,
      configFile: resolve(process.env.MCP_CONFIG_FILE ?? 'service.config.json'),
      transport: 'streamable-http', authentication: config.authentication,
      connectionFile, connection,
      eventLogFile, heartbeatIntervalMs: HEARTBEAT_INTERVAL_MS,
    });
    console.log(`MCP 已启动 · ${config.name} · streamable-http · ${config.authentication.implemented ? 'Bearer 鉴权已启用' : '鉴权未启用'}`);
    console.log(`地址：${url} · 工具：${tools.map(tool => tool.name).join(', ')}`);
    console.log(`事件日志：${eventLogFile}`);
    heartbeatTimer = setInterval(() => log('INFO', 'server.heartbeat', {
      uptimeMs: Math.round(performance.now() - runningSince), intervalMs: HEARTBEAT_INTERVAL_MS,
    }), HEARTBEAT_INTERVAL_MS);
    heartbeatTimer.unref();
  });
}
