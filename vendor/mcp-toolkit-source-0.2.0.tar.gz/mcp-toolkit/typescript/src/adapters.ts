// Thin adapters for a developer-selected executable or HTTP JSON API; no shell.
import { execFile } from 'node:child_process';

export interface JsonProgramOptions {
  command: string;
  args?: string[];
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  timeoutMs?: number;
  maxOutputBytes?: number;
}

function positiveLimit(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 1) throw new TypeError(`${name} must be a positive integer.`);
  return value;
}

function jsonObject(text: string): Record<string, unknown> {
  let result: unknown;
  try { result = JSON.parse(text); }
  catch { throw new Error('Program/API output must be one JSON object (no stdout progress messages).'); }
  if (result === null || typeof result !== 'object' || Array.isArray(result)) {
    throw new Error('Program/API output must be a JSON object.');
  }
  return result as Record<string, unknown>;
}

export async function runJsonProgram(options: JsonProgramOptions, input: unknown): Promise<Record<string, unknown>> {
  const timeout = positiveLimit(options.timeoutMs ?? 30_000, 'timeoutMs');
  const maxBuffer = positiveLimit(options.maxOutputBytes ?? 1_048_576, 'maxOutputBytes');
  const payload = JSON.stringify(input);
  if (payload === undefined) throw new TypeError('Program input must be JSON serializable.');
  return await new Promise((resolve, reject) => {
    const child = execFile(options.command, options.args ?? [], {
      cwd: options.cwd, env: options.env, timeout, maxBuffer,
      encoding: 'utf8', shell: false, killSignal: 'SIGKILL', windowsHide: true,
    }, (error, stdout) => {
      if (error) {
        if (error.code === 'ERR_CHILD_PROCESS_STDIO_MAXBUFFER') return reject(new Error('Program output exceeded maxOutputBytes.'));
        if (error.killed) return reject(new Error('Program timed out or was terminated.'));
        // Do not copy stderr/command into errors: external programs can print credentials.
        return reject(new Error(`Program failed (${error.code ?? error.signal ?? 'execution error'}).`));
      }
      try { resolve(jsonObject(stdout)); } catch (error) { reject(error); }
    });
    // A process may exit before it reads stdin; its exit status is handled above.
    child.stdin?.on('error', () => {});
    child.stdin?.end(payload + '\n');
  });
}

export interface JsonHttpOptions {
  url: string;
  timeoutMs?: number;
  maxOutputBytes?: number;
  bearerTokenEnv?: string;
}

export async function postJson(options: JsonHttpOptions, input: unknown): Promise<Record<string, unknown>> {
  const url = new URL(options.url);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.hash) {
    throw new Error('API URL must be HTTP(S), without embedded credentials or fragment.');
  }
  const timeoutMs = positiveLimit(options.timeoutMs ?? 30_000, 'timeoutMs');
  const maxOutputBytes = positiveLimit(options.maxOutputBytes ?? 1_048_576, 'maxOutputBytes');
  const headers: Record<string, string> = { 'Content-Type': 'application/json', Accept: 'application/json' };
  if (options.bearerTokenEnv) {
    const token = process.env[options.bearerTokenEnv];
    if (!token) throw new Error('Required API credential environment variable is missing.');
    headers.Authorization = `Bearer ${token}`;
  }
  try {
    const response = await fetch(url, {
      method: 'POST', headers, body: JSON.stringify(input),
      signal: AbortSignal.timeout(timeoutMs), redirect: 'error',
    });
    if (!response.ok) {
      await response.body?.cancel();
      throw new Error(`API returned HTTP ${response.status}.`);
    }
    const reader = response.body?.getReader();
    if (!reader) throw new Error('API response body is empty.');
    const chunks: Uint8Array[] = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > maxOutputBytes) {
          await reader.cancel();
          throw new Error('API output exceeded maxOutputBytes.');
        }
        chunks.push(value);
      }
    } finally { reader.releaseLock(); }
    return jsonObject(Buffer.concat(chunks).toString('utf8'));
  } catch (error) {
    if (error instanceof Error && ['TimeoutError', 'AbortError'].includes(error.name)) throw new Error('API timed out.');
    throw error;
  }
}
