// Edit tool schemas/registration here; business logic lives in business.ts or programs/.
import { resolve } from 'node:path';
import { z } from 'zod';
import { add } from './business.js';
import { runJsonProgram } from './adapters.js';

// This helper only preserves parameter/result type inference; the official SDK serves MCP.
export function defineTool<I extends z.ZodRawShape, O extends z.ZodRawShape>(definition: {
  name: string; title?: string; description: string; inputSchema: I; outputSchema: O;
  annotations?: { readOnlyHint?: boolean; destructiveHint?: boolean; idempotentHint?: boolean; openWorldHint?: boolean };
  execute: (input: z.output<z.ZodObject<I>>) => Promise<z.input<z.ZodObject<O>>>;
}) { return definition; }

const inputSchema = { a: z.number(), b: z.number() };
const outputSchema = { sum: z.number() };
const annotations = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false };

export const tools = [
  defineTool({
    name: 'add', title: '加法（TypeScript 函数）',
    description: '计算两个有限数值 a 和 b 的和，无文件或外部系统副作用。',
    inputSchema, outputSchema, annotations,
    execute: async ({ a, b }) => ({ sum: add(a, b) }),
  }),
  defineTool({
    name: 'add_program', title: '加法（外部程序）',
    description: '通过随包程序演示 JSON 标准输入输出适配，计算两个有限数值之和。',
    inputSchema, outputSchema, annotations,
    execute: async input => z.object(outputSchema).parse(await runJsonProgram({
      // start.sh sets cwd to the package root, both in source and extracted packages.
      command: process.execPath, args: [resolve('programs/add.mjs')], timeoutMs: 5_000,
    }, input)),
  }),
];

// Ordinary HTTP API example (enable after replacing the URL and reviewing annotations):
// import { postJson } from './adapters.js';
// tools.push(defineTool({ name: 'add_api', description: 'Call the configured addition API.',
//   inputSchema, outputSchema,
//   annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
//   execute: async input => z.object(outputSchema).parse(await postJson({
//     url: 'https://your-api.example/add', bearerTokenEnv: 'BUSINESS_API_TOKEN', timeoutMs: 5_000,
//   }, input)),
// }));
