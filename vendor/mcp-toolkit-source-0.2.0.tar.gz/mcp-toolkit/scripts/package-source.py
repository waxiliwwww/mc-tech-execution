#!/usr/bin/env python3
"""Collect independently usable MCP packages and portable source. No Harness dependency."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'dist'
OUT.mkdir(exist_ok=True)
ts=json.loads((ROOT/'typescript/package.json').read_text())
for source in [ROOT/'typescript/dist'/f'{ts["name"]}-{ts["version"]}.tar.gz',ROOT/'python/dist/mcp-toolkit-python.tar.gz']:
    shutil.copy2(source,OUT/source.name)

excluded={'node_modules','.venv','__pycache__','dist','logs','work','.git','lib'}
excluded_names={'connection.json','.env','model.local.json'}
allowed_roots={'README.md','.gitignore','CHANGELOG.md','package.sh','typescript','python','docs','scripts','tests'}
files=[]
for path in sorted(ROOT.rglob('*')):
    rel=path.relative_to(ROOT)
    if rel.parts[0] not in allowed_roots or any(p in excluded for p in rel.parts) or path.name in excluded_names or path.name.startswith('.env') or path.name.endswith(('.local.json','.pyc')):
        continue
    if path.is_symlink():
        raise RuntimeError(f'Source package must not contain symlinks: {rel}')
    if path.is_file(): files.append(path)
archive=OUT/'mcp-toolkit-source-0.2.0.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in files: tar.add(path,arcname=str(Path('mcp-toolkit')/path.relative_to(ROOT)),recursive=False)
checks={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('*.tar.gz'))}
(OUT/'SHA256SUMS').write_text(''.join(f'{digest}  {name}\n' for name,digest in checks.items()))
(OUT/'MANIFEST.json').write_text(json.dumps({'version':'0.2.0','artifacts':checks,'sourceFiles':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},ensure_ascii=False,indent=2)+'\n')
print('\n'.join(str(OUT/name) for name in checks))
