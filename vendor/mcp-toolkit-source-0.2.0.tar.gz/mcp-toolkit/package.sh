#!/usr/bin/env bash
# Build independent MCP packages, 2026-10-13. Harness is not required.
set -euo pipefail
mcp_package_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bash "$mcp_package_root/typescript/package.sh"
bash "$mcp_package_root/python/package.sh"
python3 "$mcp_package_root/scripts/package-source.py"
