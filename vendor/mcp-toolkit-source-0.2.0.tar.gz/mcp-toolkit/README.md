# MCP 快速接入工具包

把已有函数、命令行程序或 HTTP JSON 接口接成独立 MCP 服务，再让本机或另一台机器上的 Harness 使用。目录原名 `mcp-add-demo`，现已按语言分类；加法只是可验证的示例。原有运行进程不会因为目录改名自动重启，下次启动使用本目录中的新路径。

| 目录 | 用途 | 开始位置 |
| --- | --- | --- |
| `typescript/` | 官方 TypeScript SDK，TS 函数、外部程序、HTTP API 适配 | `README.md`、`src/tools.ts`、`service.config.json` |
| `python/` | 官方 Python `mcp` SDK，同样三种适配方式 | `README.md`、`tools.py`、`service.config.json` |
| `docs/` | 跨机器部署、接入边界与迁移说明 | `部署与接入.md` |
| `dist/` | 可交给他人解压运行的两种服务包及完整工具包源码 | 执行 `./package.sh` 生成 |

## 先跑一个真实调用

使用两个终端。服务端任选一种：

```bash
cd typescript
./start.sh
# 或进入 python/ 后执行 ./start.sh（默认端口 8766）
```

客户端可以使用任意兼容 MCP 的宿主。以另行交付的 `helix-harness` 为例，进入它自己的目录，将 `mcp-servers.json` 中 URL 改成刚启动的服务地址，执行：

```bash
./run.sh --prompt /tools
./run.sh
```

`/tools` 是实际 MCP 握手和工具发现，不需要模型；进入聊天后输入“请调用加法工具计算20加23”。模型配置沿用 `HARNESS_MODEL_URL`、`HARNESS_MODEL`、`HARNESS_MODEL_API_KEY`，也可以使用该终端支持的 JSON 配置。这里的最小 Harness 没有 MC 项目的人工确认和主备模型扩展。

服务启动成功会生成 `connection.json`。也可以读取受相同鉴权保护的 `/info` 获取服务名称、访问地址、连接配置、工具说明和输入输出 schema。正式调用时，Harness 通过 MCP `listTools` 自动发现工具定义；无需手动抄参数。连接名区分不同服务，函数名标识该服务里的具体工具。例如 `calculator__add` 的原始工具名是 `add`。

## 接自己的程序，主要改三处

1. **工具定义**：TS 编辑 `src/tools.ts`，Python 编辑 `tools.py`。填写名称、用途、参数、输出和适配方式。模型依赖这些描述选择工具，不能只填一个函数名。
2. **业务实现**：直接导入函数；或把程序放入随包部署的程序目录，使用固定 argv、JSON stdin/stdout 适配器；或配置已有 HTTP JSON POST API。程序所需系统运行时、数据文件和第三方依赖也要交付。
3. **服务配置**：编辑 `service.config.json`，设置名称、连接名、监听地址、端口、路径；远程部署还设置 `publicUrl`，凭据通过环境变量提供。

通用协议处理、日志、发现和启动不用为每个业务重写。外部程序的现有 CLI 如果不是 JSON 输入输出，只需写一个小适配函数完成参数和结果转换。“任意程序”指能以函数、命令行或 HTTP 方式调用的程序，不代表可以无需适配就操纵任意 GUI 软件，也不自动生成业务语义、物理校核或作业调度。

详细示例和错误处理见各语言目录的 README。业务程序使用固定可执行文件和参数数组，不让模型提供任意 shell 命令。服务端会验证输入、输出，子进程与 HTTP 调用有超时和输出大小限制。

## 部署给其他人

执行 `./package.sh` 生成两种最小 MCP 服务包和工具包源码包。Harness 在自己的目录运行 `./package.sh` 单独打包，不是本工具包的依赖。TS 包需要 Node.js 22；Python 包需要受支持的 Python、独立虚拟环境及 requirements 依赖，首次安装需要包源或事先准备离线依赖；Harness 包需要 Node.js 22。依赖系统程序的工具还需安装其运行时。

MCP 服务可由 Cursor、CodeBuddy 等兼容 MCP 的宿主使用，Harness 可连接第三方 MCP；这属于协议兼容目标，具体宿主仍需实际验证。服务和 Harness 可以在不同机器，不依赖共享磁盘。远程监听必须配置 `publicUrl` 和 `MCP_AUTH_TOKEN`；公开互联网用 HTTPS 入口，TLS 可由现有反向代理终止。具体步骤和第三方地址接入见 [部署与接入](docs/部署与接入.md)。本次不会自动设置他人服务器的防火墙、DNS 或证书。

## MC 项目如何复用

MC 技术执行项目保存自己的模板快照、业务定义、配置、合同材料和验收记录；其正式 MCP 路线采用 Python，以对应规格书。通用工具包负责接入与部署，MC 项目增加确认修复、模型备用及后续专业业务。更新工具包时明确更新版本并重跑项目集成测试，不通过绝对路径或符号链接跟随本目录的开发变动。

实现依据为 [官方 Python SDK](https://github.com/modelcontextprotocol/python-sdk) 与 [官方 TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk)；实际版本以语言目录的依赖锁及打包清单为准。当前选择 SDK 上的薄适配模板，复用已有独立进程和 Harness，不引入工具管理平台或额外数据库。
