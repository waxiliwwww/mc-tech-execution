#!/usr/bin/env bash
# MCP Python source deployment package, 2026-10-13. Run ./package.sh [output.tar.gz].
set -euo pipefail
MCP_TOOLKIT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MCP_ARCHIVE="${1:-$MCP_TOOLKIT_DIR/dist/mcp-toolkit-python.tar.gz}"
mkdir -p "$(dirname -- "$MCP_ARCHIVE")"
# Explicit allowlist excludes .venv, runtime connection files, logs, local secrets and configs.
tar -czf "$MCP_ARCHIVE" -C "$MCP_TOOLKIT_DIR" \
  --exclude='__pycache__' --exclude='*.pyc' --exclude='.env*' \
  README.md requirements.txt service.config.json start.sh package.sh server.py adapters.py tools.py business.py programs tests
printf '%s\n' "$MCP_ARCHIVE"
