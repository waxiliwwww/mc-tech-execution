"""Only this registry and business code change when adding a tool.

All input/output schemas below are exposed by both MCP tools/list and GET /info.
A program receives one JSON value on stdin and must emit one JSON object on stdout.
"""
import sys
from pathlib import Path
from business import add

ROOT = Path(__file__).resolve().parent
INPUT = {
    "type": "object",
    "properties": {
        "a": {"type": "number", "minimum": -1e100, "maximum": 1e100, "description": "First finite number."},
        "b": {"type": "number", "minimum": -1e100, "maximum": 1e100, "description": "Second finite number."},
    },
    "required": ["a", "b"],
    "additionalProperties": False,
}
OUTPUT = {
    "type": "object",
    "properties": {"result": {"type": "number", "description": "Sum of a and b."}},
    "required": ["result"],
    "additionalProperties": False,
}
ANNOTATIONS = {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False}
TOOLS = [
    {
        "name": "add",
        "description": "Add two finite numbers using a Python business function.",
        "inputSchema": INPUT,
        "outputSchema": OUTPUT,
        "annotations": ANNOTATIONS,
        "function": add,
    },
    {
        "name": "add_program",
        "description": "Add two finite numbers using a separate JSON stdin/stdout program.",
        "inputSchema": INPUT,
        "outputSchema": OUTPUT,
        "annotations": ANNOTATIONS,
        "program": {
            "argv": [sys.executable, str(ROOT / "programs" / "add_json.py")],
            "cwd": str(ROOT),
            "timeoutSeconds": 5,
            "maxOutputBytes": 65536,
        },
    },
]
# An HTTP JSON API can be declared similarly (URL is developer-controlled):
# {"name": "remote_add", "description": "...", "inputSchema": INPUT,
#  "outputSchema": OUTPUT, "http": {"url": "https://api.example.com/add",
#  "tokenEnv": "UPSTREAM_API_TOKEN", "timeoutSeconds": 10,
#  "maxOutputBytes": 65536}}
