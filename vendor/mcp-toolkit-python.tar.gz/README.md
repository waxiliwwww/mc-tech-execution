# Python MCP 快速封装模板

把 Python 函数、独立命令行程序或普通 HTTP JSON API 注册为 MCP 工具；通用服务负责发现、校验和执行。使用官方 `mcp==1.30.0` SDK（1.x 维护版本），没有第三方 `fastmcp` 依赖。Python 3.10+，已在 Python 3.14.4 / Linux 验证。

## 启动与接入

```bash
./start.sh
```

默认 `http://127.0.0.1:8766/mcp`，提供 `add`、`add_program` 两个示例。脚本会在当前模板内部创建 `.venv` 并按锁定的 `requirements.txt` 安装依赖；可从其他工作目录调用脚本。首次安装需要网络，或先准备适合目标系统和 Python 版本的 wheelhouse，再运行 `WHEELHOUSE=/path/to/wheels ./start.sh`。目标机需有 Python、venv/pip、Bash；程序示例按 Linux/macOS 命令行环境设计。虚拟环境不能跨目录或系统搬运。

启动成功只输出三行摘要，工具调用有完成/失败记录及调用参数，运行期间每 5 分钟只输出时间戳与运行时长。结构化事件及调用参数写入 `logs/*.jsonl`，业务结果、原始 stderr 和鉴权头不写入服务日志。按 Ctrl+C / SIGTERM 停止；进程适配器在超时、取消或输出超限时清理进程。已生成的 `connection.json` 是连接配置，停止后保留，不能用它判断在线状态；用 `/health` 检查。

服务启动后自动写 `connection.json` 数组，可直接作为支持该格式的 Harness 工具注册文件；MCP 标准发现通过 `initialize` / `tools/list`，`GET /info` 则返回同一工具说明及输入/输出 JSON Schema。`MCP_CONNECTION_FILE` 可指定另一个文件，父目录应已存在。协议为 Streamable HTTP，连接路径不要加结尾斜线。

## 增加自己的工具

仅修改 `tools.py` 和业务代码：

```python
from business import my_function
TOOLS = [{
    "name": "my_tool", "description": "说明用途和边界",
    "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}},
                    "required": ["text"], "additionalProperties": False},
    "outputSchema": {"type": "object", "properties": {"result": {"type": "string"}},
                     "required": ["result"], "additionalProperties": False},
    "function": my_function,
}]
```

函数接收 `my_function(text=...)` 形式的参数，返回 JSON 对象；支持同步和 async 函数。输入、输出均经过声明的 Schema 校验。同步函数在线程执行，不支持强制终止；长时或可能挂死的任务用子进程适配器。可选 `annotations` 是 MCP 客户端提示，不代替实际权限控制。工具定义和业务代码是可信开发代码，服务不是执行不可信代码的沙箱。

独立程序把 `function` 换成：

```python
"program": {
    "argv": ["/path/to/runtime", "/path/to/program"],
    "cwd": "/path/to/workdir", "timeoutSeconds": 30, "maxOutputBytes": 1048576
}
```

程序通过 stdin 接收一个 JSON 对象，stdout 只输出一个 JSON 对象，诊断写 stderr。支持已有可执行文件，以及 Python、Node、Java 等命令行程序（相应运行时须安装）。`argv` 分项传入，服务不启用 shell；不要让调用方提供任意命令或 URL。stdout/stderr 合并计入上限；非零退出、超时、JSON 错误和 schema 错误均返回 MCP `isError=true`。Linux/macOS 超时会终止本次进程组。已有软件若只认参数/文件，先写少量适配代码完成 JSON 与参数/文件转换；GUI 软件不能无适配直接封装。程序依赖和外部数据需要自己随业务交付。

普通 HTTP JSON API 把执行部分换成：

```python
"http": {"url": "https://api.example.com/calculate", "tokenEnv": "UPSTREAM_API_TOKEN",
         "timeoutSeconds": 10, "maxOutputBytes": 1048576}
```

固定 URL 接受 POST JSON 并返回 JSON 对象，凭据由指定环境变量注入 Bearer 头；不跟随重定向，限制总耗时和响应大小。参数或返回格式不符时，在业务函数中适配。不要把上游凭据放在 URL 或工具参数里。已有真正的 MCP 服务可直接注册其 MCP URL，无需再次封装。

## 配置与跨服务器访问

`service.config.json` 集中管理 `host/port/path/name/version/clientName`；`MCP_CONFIG_FILE` 可选另一份配置。`MCP_HOST`、`MCP_PORT`、`MCP_PATH`、`MCP_PUBLIC_URL` 可覆盖对应设置。

跨服务器部署示例：

```json
{
  "host": "0.0.0.0", "port": 8766, "path": "/mcp",
  "name": "mcp-toolkit-python", "version": "1.0.0", "clientName": "calculator_python",
  "publicUrl": "https://mcp.example.org/mcp"
}
```

在服务端通过环境配置设置 `MCP_AUTH_TOKEN` 后启动；非本地回环监听必须同时有 token 和显式 `publicUrl`。客户端地址须是真实服务器 IP 或域名，不能是 `0.0.0.0`、`::`、`localhost`；`publicUrl` 路径需与 `path` 一致。`https` 由你部署的 TLS 反向代理终止，模板本身监听 HTTP，不自动改防火墙或代理。代理需保留客户端公共 Host 和 Authorization 头。可信内网直接使用 `http://实际IP:8766/mcp` 也可，但 Bearer 在 HTTP 上不加密；跨不可信网络使用 HTTPS。

`/info` 和所有 MCP 方法都要求 `Authorization: Bearer ...`；`/health` 只返回健康状态与服务名/版本，可以公开。`connection.json` 仅含 `Bearer ${MCP_AUTH_TOKEN}` 占位符，不含真实 token；支持环境占位符的 Harness 在客户端配置同名变量即可。其他 MCP 客户端需要自行配置其认证头。模板保留官方 Host/Origin 检查：允许公共 URL 与本地后端地址，阻止不匹配 Host/Origin。当前没有跨站浏览器 CORS 支持，适合服务端 Harness；若有浏览器前端应按实际来源单独配置，不放开任意来源。

## 打包和验证

```bash
./package.sh
# 输出 dist/mcp-toolkit-python.tar.gz；在另一目录解压后 ./start.sh
.venv/bin/python -m unittest discover -s tests -v
```

打包是源码部署包，包含模板、锁定依赖和 `programs/`，不含 `.venv`、日志、运行连接文件和 `.env`。新增业务模块需加入 `package.sh` 的显式文件清单；勿将凭据写入业务源码或配置。首次部署下载依赖，已有安装且锁文件未改变时不重复安装。

测试覆盖官方 SDK 客户端的真实握手、工具发现、函数/程序调用、schema 错误、CLI 超时/退出码/输出限制与取消、HTTP JSON 适配、Bearer/Host/Origin、端口冲突、写连接文件失败、心跳逻辑及搬到新目录重建虚拟环境后的调用。心跳测试缩短定时器验证逻辑，不声称已连续运行 5 分钟或做过生产负载测试。

官方依据：[SDK 1.30.0](https://github.com/modelcontextprotocol/python-sdk/tree/v1.30.0)、[Stateless Streamable HTTP 示例](https://github.com/modelcontextprotocol/python-sdk/blob/v1.30.0/examples/servers/simple-streamablehttp-stateless/mcp_simple_streamablehttp_stateless/server.py)、[Host/Origin 与请求体保护](https://github.com/modelcontextprotocol/python-sdk/blob/v1.30.0/src/mcp/server/transport_security.py)。仅调用 MCP 协议和示例业务，不调用大模型。
