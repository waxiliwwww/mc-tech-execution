#!/usr/bin/env python3
"""JSON CLI example, 2026-10-13. echo '{"a":2,"b":3}' | python add_json.py"""
import json
import sys

try:
    args = json.load(sys.stdin)
    print(json.dumps({"result": args["a"] + args["b"]}, allow_nan=False))
except Exception:
    print("Expected one JSON object containing numeric a and b.", file=sys.stderr)
    raise SystemExit(2)
