"""Console parameters, logging isolation and timer regressions; no listening service."""
import asyncio
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime
import io
import json
from pathlib import Path
import sys
import time
import unittest

from mcp.types import CallToolRequest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import EventLog, create_app, heartbeat, load_config, snapshot_arguments


def memory_log(writer=None):
    log = EventLog.__new__(EventLog)
    log.file = writer if writer is not None else io.StringIO()
    log.warned = False
    return log


def request_handler(log, tools=None):
    config = load_config({}, {
        "host": "127.0.0.1", "port": 8766, "path": "/mcp",
        "name": "console-test", "version": "0.1.0", "clientName": "console-test",
    })
    app = create_app(config, log, tools)
    closure = dict(zip(app.__code__.co_freevars, (cell.cell_contents for cell in app.__closure__)))
    return closure["manager"].app.request_handlers[CallToolRequest]


async def call(handler, name="add", arguments=None):
    request = CallToolRequest(method="tools/call", params={
        "name": name, "arguments": arguments if arguments is not None else {"a": 20, "b": 23},
    })
    return (await handler(request)).root


class ConsoleOutputTests(unittest.TestCase):
    def test_success_and_failure_print_compact_unicode_json_on_one_line(self):
        for event, level, status, destination in (
            ("tool.executed", "INFO", "完成", "stdout"),
            ("tool.failed", "WARNING", "失败", "stderr"),
        ):
            with self.subTest(event=event):
                log = memory_log()
                arguments = {"a": 20, "b": 23, "说明": "第一行\n第二行"}
                output, error = io.StringIO(), io.StringIO()
                with redirect_stdout(output), redirect_stderr(error):
                    log.emit(level, event, name="add", arguments=arguments)
                text = (output if destination == "stdout" else error).getvalue()
                self.assertEqual(len(text.splitlines()), 1)
                self.assertRegex(text, r"^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} [+-]\d{4}\] ")
                self.assertIn(f"执行 add {status} · 参数：", text)
                payload = text.partition(" · 参数：")[2].rstrip("\n")
                self.assertEqual(payload, '{"a":20,"b":23,"说明":"第一行\\n第二行"}')
                self.assertEqual(json.loads(payload), arguments)
                self.assertEqual(json.loads(log.file.getvalue())["arguments"], arguments)
                self.assertEqual((error if destination == "stdout" else output).getvalue(), "")

    def test_periodic_line_keeps_timestamp_and_duration_without_heartbeat_label(self):
        log = memory_log()
        output = io.StringIO()
        with redirect_stdout(output):
            log.emit("INFO", "server.heartbeat", uptimeMs=300000, intervalMs=300000)
        self.assertRegex(output.getvalue(), r"^\[[^\n]+\] 已运行 00:05:00\n$")
        self.assertNotIn("心跳", output.getvalue())
        event = json.loads(log.file.getvalue())
        self.assertEqual(event["event"], "server.heartbeat")
        self.assertEqual(event["uptimeMs"], 300000)

    def test_nonjson_snapshot_is_explicit_and_finite(self):
        for arguments in ({"value": float("nan")}, {"value": float("inf")}, {"value": datetime(2026, 10, 13)}):
            with self.subTest(arguments=arguments):
                snapshot = snapshot_arguments(arguments)
                self.assertEqual(snapshot, {"_loggingError": "Parameters are not finite JSON data."})
                json.dumps(snapshot, allow_nan=False)


class CallbackLoggingTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_handler_logs_success_schema_failure_and_unknown_tool_arguments(self):
        log = memory_log()
        handler = request_handler(log)
        output, error = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(error):
            success = await call(handler)
            failure = await call(handler, arguments={"a": "20", "b": 23})
            unknown = await call(handler, name="unsupported", arguments={"a": 20, "b": 23})
        self.assertFalse(success.isError)
        self.assertEqual(success.structuredContent, {"result": 43})
        self.assertTrue(failure.isError)
        self.assertIn("Input schema validation failed", failure.content[0].text)
        self.assertTrue(unknown.isError)
        records = [json.loads(line) for line in log.file.getvalue().splitlines()]
        self.assertEqual([entry["event"] for entry in records], ["tool.executed", "tool.failed", "tool.failed"])
        self.assertEqual([entry["arguments"] for entry in records], [
            {"a": 20, "b": 23}, {"a": "20", "b": 23}, {"a": 20, "b": 23},
        ])
        self.assertEqual(records[-1]["name"], "unknown")
        self.assertIn('执行 add 完成 · 参数：{"a":20,"b":23}', output.getvalue())
        self.assertIn('执行 add 失败 · 参数：{"a":"20","b":23}', error.getvalue())

    async def test_snapshot_precedes_business_mutation(self):
        async def mutate(payload):
            payload["说明"] = "已修改"
            return {"result": 43}

        tool = {
            "name": "mutate", "description": "Test mutable arguments.",
            "inputSchema": {"type": "object", "properties": {"payload": {"type": "object"}}, "required": ["payload"]},
            "outputSchema": {"type": "object", "properties": {"result": {"type": "number"}}, "required": ["result"]},
            "function": mutate,
        }
        log = memory_log()
        with redirect_stdout(io.StringIO()):
            result = await call(request_handler(log, [tool]), "mutate", {"payload": {"说明": "原参数"}})
        self.assertFalse(result.isError)
        self.assertEqual(json.loads(log.file.getvalue())["arguments"], {"payload": {"说明": "原参数"}})

    async def test_event_sink_failure_does_not_change_success_or_safe_business_error(self):
        class BrokenLog:
            def emit(self, *_args, **_fields):
                raise ValueError("Synthetic formatting/sink failure")

        handler = request_handler(BrokenLog())
        result = await call(handler)
        self.assertFalse(result.isError)
        self.assertEqual(result.structuredContent, {"result": 43})
        failed = await call(handler, arguments={"a": "20", "b": 23})
        self.assertTrue(failed.isError)
        self.assertIn("Input schema validation failed", failed.content[0].text)
        self.assertNotIn("sink failure", failed.content[0].text)

    async def test_file_io_failure_keeps_console_parameters_and_successful_receipt(self):
        class BrokenFile:
            def write(self, _text):
                raise OSError("Synthetic file failure")

        log = memory_log(BrokenFile())
        output, error = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(error):
            result = await call(request_handler(log))
        self.assertFalse(result.isError)
        self.assertEqual(result.structuredContent, {"result": 43})
        self.assertIn('执行 add 完成 · 参数：{"a":20,"b":23}', output.getvalue())
        self.assertIn("事件日志写入失败", error.getvalue())

    async def test_timer_cancellation_stops_further_periodic_events(self):
        events = []
        emitted = asyncio.Event()

        class Log:
            def emit(self, *args, **fields):
                events.append((args, fields))
                emitted.set()

        task = asyncio.create_task(heartbeat(Log(), time.monotonic(), interval=0.005))
        try:
            await asyncio.wait_for(emitted.wait(), 1)
        finally:
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        count = len(events)
        await asyncio.sleep(0.02)
        self.assertEqual(len(events), count)
        self.assertEqual(events[0][0], ("INFO", "server.heartbeat"))


if __name__ == "__main__":
    unittest.main()
