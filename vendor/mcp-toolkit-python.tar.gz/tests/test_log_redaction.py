import io
import json
from contextlib import redirect_stdout
import unittest
from server import EventLog


class RedactionTests(unittest.TestCase):
    def test_console_and_file_mask_credentials_but_keep_parameters(self):
        log = EventLog.__new__(EventLog)
        log.file, log.warned = io.StringIO(), False
        args = {"a": 20, "settings": {"apiKey": "fixture-secret", "path": "input.xml"}}
        output = io.StringIO()
        with redirect_stdout(output):
            log.emit("INFO", "tool.executed", name="example", arguments=args)
        self.assertNotIn("fixture-secret", output.getvalue() + log.file.getvalue())
        saved = json.loads(log.file.getvalue())["arguments"]
        self.assertEqual(saved["a"], 20)
        self.assertEqual(saved["settings"]["path"], "input.xml")
        self.assertEqual(args["settings"]["apiKey"], "fixture-secret")
