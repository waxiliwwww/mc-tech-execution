"""Real MCP protocol and adapter regressions. Run .venv/bin/python -m unittest discover -s tests -v."""
import asyncio
from contextlib import contextmanager
import io
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from adapters import ToolExecutionError, execute_tool, run_program, post_json, validate_registry
from server import load_config, heartbeat
from tools import TOOLS, INPUT, OUTPUT

WORK = ROOT / "work"
WORK.mkdir(exist_ok=True)
DEFAULTS = json.loads((ROOT / "service.config.json").read_text())


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@contextmanager
def running(root=ROOT, remote=False, launcher=False):
    with tempfile.TemporaryDirectory(dir=WORK) as directory:
        port = free_port()
        target = Path(directory)
        cfg = {**DEFAULTS, "port": port}
        if remote:
            cfg.update(host="0.0.0.0", publicUrl=f"http://example.internal:{port}/mcp")
        (target / "config.json").write_text(json.dumps(cfg))
        env = {key: value for key, value in os.environ.items() if not key.startswith("MCP_")}
        env.update(MCP_CONFIG_FILE=str(target / "config.json"), MCP_CONNECTION_FILE=str(target / "connection.json"))
        if remote:
            env["MCP_AUTH_TOKEN"] = "test-token-not-for-deployment"
        command = [str(root / "start.sh")] if launcher else [sys.executable, str(root / "server.py")]
        # Deliberately launch from a different working directory.
        process = subprocess.Popen(command, cwd=target, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        base = f"http://127.0.0.1:{port}"
        try:
            deadline = time.monotonic() + 60
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise AssertionError(f"Server exited: {process.communicate()}")
                try:
                    response = httpx.get(base + "/health", timeout=0.2)
                    if response.status_code == 200 and (target / "connection.json").exists():
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(0.03)
            else:
                raise AssertionError("Server did not start")
            yield base, target, process, env
        finally:
            if process.poll() is None:
                process.send_signal(signal.SIGTERM)
            try:
                out, err = process.communicate(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                out, err = process.communicate()
                raise AssertionError("Server did not stop cleanly")
            process.captured = (out, err)


class ConfigTests(unittest.TestCase):
    def test_defaults_and_path(self):
        config = load_config({}, DEFAULTS)
        self.assertEqual(config.url, "http://127.0.0.1:8766/mcp")
        self.assertEqual(config.connection_file, ROOT / "connection.json")

    def test_reject_invalid_config(self):
        for change in ({"port": True}, {"port": 0}, {"port": "1.0"}, {"path": "/info"}, {"path": "/../mcp"},
                       {"host": "0.0.0.0"}, {"host": "example.com"}, {"name": ""}, {"publicUrl": "http://0.0.0.0:8/mcp"}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                load_config({}, {**DEFAULTS, **change})

    def test_remote_config_and_secret_placeholder(self):
        cfg = {**DEFAULTS, "host": "::", "publicUrl": "https://mcp.example.org/mcp"}
        config = load_config({"MCP_AUTH_TOKEN": "private-token"}, cfg)
        self.assertEqual(config.url, cfg["publicUrl"])
        self.assertEqual(config.connection[0]["headers"]["Authorization"], "Bearer ${MCP_AUTH_TOKEN}")
        self.assertNotIn("private-token", repr(config))
        for url in ("http://127.0.0.1:8/mcp", "http://x/mcp?token=secret", "http://user:secret@x/mcp", "http://x/other"):
            with self.assertRaises(ValueError):
                load_config({"MCP_AUTH_TOKEN": "secret"}, {**cfg, "publicUrl": url})

    def test_registry_unique_and_schema(self):
        validate_registry(TOOLS)
        with self.assertRaises(ValueError):
            validate_registry([TOOLS[0], TOOLS[0]])


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_function_and_program(self):
        for tool in TOOLS:
            self.assertEqual(await execute_tool(tool, {"a": 2, "b": 3.5}), {"result": 5.5})

    async def test_input_and_output_schema(self):
        for value in ({"a": "2", "b": 1}, {"a": True, "b": 1}, {"a": float("nan"), "b": 1}, {"a": 1, "b": 2, "secret": 3}):
            with self.assertRaises(ToolExecutionError):
                await execute_tool(TOOLS[0], value)
        with self.assertRaises(ToolExecutionError):
            await execute_tool({**TOOLS[0], "function": lambda **_: {"wrong": 1}}, {"a": 1, "b": 2})

    async def test_program_failures(self):
        cases = [
            ("import sys; sys.exit(7)", "code 7", 2, 100),
            ("print('not json')", "invalid JSON", 2, 100),
            ("print('[]')", "JSON object", 2, 100),
            ("print('x'*10000)", "exceeds", 2, 100),
            ("import sys; sys.stderr.write('x'*10000)", "exceeds", 2, 100),
            ("import time; time.sleep(2)", "timed out", 0.08, 100),
        ]
        for code, error, timeout, cap in cases:
            with self.subTest(error=error), self.assertRaisesRegex(ToolExecutionError, error):
                await run_program({"argv": [sys.executable, "-c", code], "timeoutSeconds": timeout, "maxOutputBytes": cap}, {})
        with self.assertRaisesRegex(ToolExecutionError, "could not start"):
            await run_program({"argv": ["/nonexistent/mcp-test-binary"]}, {})

    async def test_no_shell_and_cancellation(self):
        code = "import json,sys; print(json.dumps({'value':sys.argv[1]}))"
        self.assertEqual(await run_program({"argv": [sys.executable, "-c", code, "$(touch do-not-create);abc"]}, {}),
                         {"value": "$(touch do-not-create);abc"})
        with tempfile.TemporaryDirectory(dir=WORK) as directory:
            pid_file = Path(directory) / "pid"
            code = f"import os,time; open({str(pid_file)!r},'w').write(str(os.getpid())); time.sleep(10)"
            task = asyncio.create_task(run_program({"argv": [sys.executable, "-c", code]}, {}))
            for _ in range(100):
                if pid_file.exists():
                    break
                await asyncio.sleep(0.01)
            self.assertTrue(pid_file.exists())
            pid = int(pid_file.read_text())
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            with self.assertRaises(ProcessLookupError):
                os.kill(pid, 0)

    async def test_http_json_adapter(self):
        received = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def do_POST(self):
                data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                received.append(self.headers.get("Authorization"))
                if self.path == "/slow":
                    time.sleep(0.3)
                self.send_response(503 if self.path == "/error" else 200)
                self.end_headers()
                body = b"invalid" if self.path == "/invalid" else json.dumps({"result": data["a"] + data["b"]}).encode()
                try:
                    self.wfile.write(body)
                except BrokenPipeError:
                    pass
        http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=http.serve_forever, daemon=True)
        thread.start()
        try:
            base = f"http://127.0.0.1:{http.server_port}"
            tool = {key: value for key, value in TOOLS[0].items() if key != "function"}
            tool["http"] = {"url": base + "/add", "tokenEnv": "UPSTREAM_TEST_TOKEN"}
            with patch.dict(os.environ, {"UPSTREAM_TEST_TOKEN": "upstream-secret"}):
                self.assertEqual(await execute_tool(tool, {"a": 4, "b": 8}), {"result": 12})
            self.assertEqual(received[-1], "Bearer upstream-secret")
            for path, spec, text in [("/error", {}, "503"), ("/invalid", {}, "invalid JSON"),
                                     ("/slow", {"timeoutSeconds": .03}, "timed out"), ("/add", {"maxOutputBytes": 1}, "exceeds")]:
                with self.assertRaisesRegex(ToolExecutionError, text):
                    await post_json({"url": base + path, **spec}, {"a": 1, "b": 2})
        finally:
            await asyncio.to_thread(http.shutdown)
            http.server_close()

    async def test_heartbeat_format_event(self):
        events = []
        class Log:
            def emit(self, *args, **kwargs):
                events.append((args, kwargs))
        task = asyncio.create_task(heartbeat(Log(), time.monotonic(), interval=.01))
        await asyncio.sleep(.025)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertGreaterEqual(len(events), 1)
        self.assertEqual(events[0][0], ("INFO", "server.heartbeat"))


class ProtocolTests(unittest.TestCase):
    def test_protocol_discovery_calls_and_shutdown(self):
        with running() as (base, target, process, env):
            info = httpx.get(base + "/info").json()
            self.assertEqual(info["schemaVersion"], 1)
            self.assertEqual(info["authentication"]["implemented"], False)
            self.assertEqual(json.loads((target / "connection.json").read_text()), info["connection"])
            async def exercise():
                async with streamablehttp_client(base + "/mcp") as (read, write, _):
                    async with ClientSession(read, write) as session:
                        initialized = await session.initialize()
                        self.assertEqual(initialized.serverInfo.name, "mcp-toolkit-python")
                        listing = await session.list_tools()
                        self.assertEqual([t.name for t in listing.tools], ["add", "add_program"])
                        self.assertEqual(listing.tools[0].outputSchema, info["tools"][0]["outputSchema"])
                        for name in ("add", "add_program"):
                            result = await session.call_tool(name, {"a": 7, "b": 9})
                            self.assertFalse(result.isError)
                            self.assertEqual(result.structuredContent, {"result": 16})
                        for name, args in [("add", {"a": "x", "b": 1}), ("add", {"a": 1}), ("not_a_tool", {})]:
                            result = await session.call_tool(name, args)
                            self.assertTrue(result.isError)
            asyncio.run(exercise())
            self.assertEqual(httpx.post(base + "/mcp", content="{", headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}).status_code, 400)
        out, err = process.captured
        self.assertEqual(out.splitlines()[0].split(" · ")[0], "MCP 已启动")
        self.assertTrue(out.splitlines()[1].startswith("地址："))
        self.assertTrue(out.splitlines()[2].startswith("事件日志："))
        self.assertIn("MCP 已停止", out)
        failed_lines = err.splitlines()
        self.assertEqual(len(failed_lines), 3)
        for line, name, arguments in zip(failed_lines, ("add", "add", "unknown"), ({"a": "x", "b": 1}, {"a": 1}, {})):
            self.assertIn(f"执行 {name} 失败 · 参数：", line)
            self.assertEqual(json.loads(line.split("参数：", 1)[1]), arguments)
        log = Path(out.splitlines()[2].removeprefix("事件日志："))
        events = [json.loads(line) for line in log.read_text().splitlines()]
        self.assertEqual(events[0]["event"], "server.started")
        self.assertEqual(events[-1]["event"], "server.stopped")
        self.assertTrue(any(e["event"] == "tool.failed" for e in events))

    def test_remote_bearer_and_host_origin(self):
        with running(remote=True) as (base, target, process, env):
            for path in ("/info", "/mcp"):
                for method in ("GET", "POST", "DELETE"):
                    self.assertEqual(httpx.request(method, base + path).status_code, 401)
            headers = {"Authorization": "Bearer " + env["MCP_AUTH_TOKEN"]}
            info = httpx.get(base + "/info", headers=headers).json()
            public = info["url"]
            authority = public.split('/')[2]
            self.assertEqual(httpx.get(base + "/info", headers={**headers, "Host": authority, "Origin": "http://" + authority}).status_code, 200)
            self.assertEqual(httpx.get(base + "/info", headers={**headers, "Host": "evil.invalid"}).status_code, 421)
            self.assertEqual(httpx.get(base + "/info", headers={**headers, "Origin": "https://evil.invalid"}).status_code, 403)
            self.assertNotIn(env["MCP_AUTH_TOKEN"], json.dumps(info))
            async def exercise():
                async with streamablehttp_client(base + "/mcp", headers={**headers, "Host": authority}) as (read, write, _):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        result = await session.call_tool("add", {"a": 3, "b": 5})
                        self.assertEqual(result.structuredContent, {"result": 8})
            asyncio.run(exercise())
        out, err = process.captured
        log = Path(out.splitlines()[2].removeprefix("事件日志："))
        self.assertNotIn(env["MCP_AUTH_TOKEN"], out + err + log.read_text())

    def test_port_in_use_and_connection_failure(self):
        with running() as (base, target, _, env):
            failed = subprocess.run([sys.executable, str(ROOT / "server.py")], env=env, capture_output=True, text=True, timeout=10)
            self.assertNotEqual(failed.returncode, 0)
            self.assertNotIn("MCP 已启动", failed.stdout)
        with tempfile.TemporaryDirectory(dir=WORK) as d:
            cfg = Path(d) / "config.json"
            cfg.write_text(json.dumps({**DEFAULTS, "port": free_port()}))
            badenv = {**os.environ, "MCP_CONFIG_FILE": str(cfg), "MCP_CONNECTION_FILE": str(Path(d) / "missing" / "connection.json")}
            failed = subprocess.run([sys.executable, str(ROOT / "server.py")], env=badenv, capture_output=True, text=True, timeout=10)
            self.assertNotEqual(failed.returncode, 0)
            self.assertNotIn("MCP 已启动", failed.stdout)

    def test_package_relocation_and_fresh_venv(self):
        with tempfile.TemporaryDirectory(dir=WORK) as d:
            target = Path(d)
            archive = target / "toolkit.tar.gz"
            subprocess.run([str(ROOT / "package.sh"), str(archive)], check=True, capture_output=True)
            deploy = target / "moved toolkit"
            deploy.mkdir()
            with tarfile.open(archive) as source:
                names = source.getnames()
                self.assertFalse(any(name.startswith((".venv", "logs", "connection.json")) for name in names))
                source.extractall(deploy, filter="data")
            with running(deploy, launcher=True) as (base, _, process, _):
                self.assertEqual(httpx.get(base + "/info").json()["tools"][1]["name"], "add_program")
                async def exercise():
                    async with streamablehttp_client(base + "/mcp") as (read, write, _):
                        async with ClientSession(read, write) as session:
                            await session.initialize()
                            result = await session.call_tool("add_program", {"a": 5, "b": 6})
                            self.assertEqual(result.structuredContent, {"result": 11})
                asyncio.run(exercise())
            self.assertTrue((deploy / ".venv" / ".requirements.sha256").is_file())
            self.assertIn("MCP 已停止", process.captured[0])


if __name__ == "__main__":
    unittest.main()
