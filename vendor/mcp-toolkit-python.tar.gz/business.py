"""Replace or extend these ordinary business functions; no MCP imports needed."""


def add(a: float, b: float) -> dict:
    """Return a JSON object; the tool declaration defines its public contract."""
    return {"result": a + b}
